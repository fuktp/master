# CAIO 2.0.0.dev5 — referência técnica

## O que esta revisão altera

A dev4 falhava antes de construir o formulário WinForms: `Read-NativeJson` enviava `locales.json` a `ConvertFrom-Json`, que recusa propriedades iguais sem distinguir maiúsculas de minúsculas. O catálogo continha `Desabilitada` e `desabilitada`, ambas com as mesmas traduções.

A dev5 mantém somente a chave canônica `Desabilitada`. A consulta Python passa a ignorar a caixa, assim como a consulta de propriedades usada pelo wizard. Português conserva o texto original; inglês e espanhol continuam traduzindo ambas as formas. Não foram adicionadas dependências, novos formatos de catálogo ou requisitos de PowerShell 7. A correção não usa `-AsHashtable`, indisponível no Windows PowerShell 5.1 que o iniciador chama.

O teste Python verifica a unicidade de todas as chaves do catálogo e as duas traduções do estado. O teste PowerShell agora lê o arquivo real com a mesma função do wizard e verifica suas traduções: antes, ele só analisava a sintaxe dos PS1 e um JSON sintético. Esse ponto cego permitiu a falha da dev4 apesar da suíte anterior aprovada. A reprodução e o resultado anterior à correção estão em `evidencias/dev5-reproduction.json` e `evidencias/dev5-regression-before.txt`.

Referência do comportamento do parser: [Microsoft — ConvertFrom-Json](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/convertfrom-json?view=powershell-7.4). A prova desta correção é a execução do leitor real, não apenas a documentação.

## Documentação consolidada

Os 15 Markdown de projeto foram lidos integralmente. A árvore ativa agora tem três:

| Documento vigente | Finalidade |
|---|---|
| `README.md` | Operação e instalação; copiado para `00 - Read Me.md` no ZIP do usuário |
| `docs/TECNICO.md` | Esta referência: código, build, compatibilidade e manutenção |
| `docs/VALIDACAO.md` | Matriz única de requisitos, resultados e limites |

Foram retirados `README_DESKTOP.md`, `README_TESTE.md`, `README_SCRIPTS.md`, os três `REGISTRO_*.md`, os três `MATRIZ_*.md` da raiz, `docs/COMANDOS.md`, `docs/COMANDOS_DESKTOP.md`, `docs/INSPECAO_E_BLOQUEIOS.md`, `docs/MIGRACAO_DESKTOP.md` e `docs/MATRIZ_ACEITE_DESKTOP.md`. O README legado foi substituído pelo guia atual. As informações úteis foram incorporadas aos três documentos vigentes; evidências antigas e capturas redundantes saíram da árvore ativa. O inventário está em `evidencias/dev5-doc-review.json`.

As versões anteriores continuam recuperáveis no snapshot imutável da dev4. Não se apagaram extratores, dados de produção, testes, licenças de dependências ou componentes de runtime. Esta limpeza afeta a documentação do projeto, não os avisos legais das bibliotecas.

Contradições resolvidas: entrega exclusiva de EXE, instalação manual de Python, uso de Git, caminhos pessoais, horários obrigatoriamente globais, autorização repetida por hash e consulta automática ao feed HTTPS não descrevem a edição atual. Textos antigos que afirmavam aplicativo ainda não implementado ou ATMS ausente também não são orientação vigente.

## Código e persistência

| Caminho | Responsabilidade |
|---|---|
| `native/Instalar.vbs`, `Instalar.bat`, `wizard.ps1`, `Native.Routines.ps1` | Iniciadores e wizard WinForms; formulários de rotinas |
| `native/Native.Common.ps1`, `Abrir.ps1`, `Update.ps1` | Ponte oculta, leitura JSON, abertura e espera do processo anterior |
| `orquestrador_app/native_bridge.py`, `native_install.py`, `native_updates.py` | Protocolo JSON, implantação transacional, integridade e ZIP local |
| `gui.py`, `ui.py`, `i18n.py`, `locales.json`, `dev_gui.py` | Interface Qt, tema, idiomas, controles e diagnóstico |
| `config.py`, `paths.py`, `sandbox.py`, `versioning.py` | Configuração, identificação, isolamento de teste e manifestos internos |
| `schedule.py`, `engine.py`, `worker.py`, `store.py` | Frequências, dependências, retries, extratores e SQLite |
| `files.py`, `io.py`, `script_versions.py`, `exporting.py` | Publicação, backup, locks, snapshots e exportações sanitizadas |
| `driver.py`, `connectivity.py`, `processes.py`, `runtime.py` | Driver, evidências de rede, processos próprios e console oculto |
| `agent.py`, `tasks.py`, `notifications.py` | Monitor, tarefa interativa e notificações |
| `scripts/`, `pipefy_orchestrator.py`, `automation_schedule.py` | Extratores e compatibilidade legada preservados |
| `desktop_tests/`, `tests/`, `tools/`, `build_inputs/` | Testes novos/legados, build e entradas fixadas |

A distribuição contém runtime privado Windows x64, PySide6 e dependências fixadas; não depende de Python global. O desenvolvimento usa venv. O monitor inicia pelo lançador do mesmo produto com `--agent`, usa tarefa própria com `InteractiveToken`, e serializa os trabalhos. Fechar a GUI não é desligar o monitor.

`same_chain` exige sucesso na mesma cadeia; `fresh_success` exige uma janela explícita. Falha, cancelamento, código 20 e bloqueio não registram sucesso. Os retries contam a primeira tentativa e respeitam orçamento por categoria e timeout total. Arquivo bloqueado reaproveita o staging para republicar. Não há retries externos de VPN/autenticação nem multiplicação de tentativas para código 20.

Os locks do sistema operacional protegem execução, perfil e publicação. Pausa é cooperativa em checkpoints; o timeout inclui a pausa. Cancelamento aguarda cooperação e encerra apenas processos próprios. Windows Job Object está implementado, mas não foi exercitado no host Linux. Temporários de falhas ficam disponíveis para diagnóstico; não há ação específica de limpeza na interface nem limite individual de tamanho para a captura stdout por execução.

## Build e testes reproduzíveis

Execute na raiz técnica, em ambiente de desenvolvimento. Estes comandos não são passos do usuário final. Use `uv sync --frozen` para criar o venv com o lock. Em Linux, defina `QT_QPA_PLATFORM=offscreen` ao testar sem monitor; em Windows, use a sessão gráfica autorizada.

```text
uv sync --frozen
uv run --frozen ruff check .
uv run --frozen ruff format --check .
uv run --frozen mypy --platform win32
uv run --frozen python -m pytest -q --junitxml=docs/evidencias/dev5-tests.xml
uv run --frozen python -m orquestrador_app --health-check --health-output docs/evidencias/dev5-health.json
uv run --frozen pip-audit --disable-pip --no-deps -r docs/evidencias/native-audit-windows-inputs.txt --format json -o docs/evidencias/dev5-dependency-audit.json
```

O teste PowerShell deve passar **antes de empacotar**. No Windows, execute com o host realmente usado pelo VBS:

```text
powershell.exe -NoProfile -File tools/test_native_powershell.ps1
```

Em desenvolvimento Linux, `pwsh -NoProfile -File tools/test_native_powershell.ps1` verifica o parser JSON e os auxiliares portáveis; não substitui o teste acima nem abre WinForms.

O manifesto `build_inputs/windows-x64.json` fixa CPython Windows e wheels por URL/hash. Para preparar um runtime do zero e gerar o ZIP:

```text
uv run --frozen python tools/prepare_windows_payload.py --output build/runtime-windows --cache build/downloads
uv run --frozen python tools/build_native_zip.py --runtime build/runtime-windows --output build/release-dev5
uv run --frozen python tools/verify_native_artifact.py --archive build/release-dev5/CAIO_2.0.0.dev5.zip --scratch build/validation-dev5 --output docs/evidencias/dev5-artifact.json
```

Use uma área de saída nova: o builder não sobrescreve builds anteriores. O resultado tem apenas `00 - Read Me.md`, `01 - Instalar.vbs`, `01 - Instalar(alt).bat` e `payload` no primeiro nível. `release.json` registra versão e hashes; o verificador extrai o ZIP e compara código, catálogo, iniciadores, logo, manifesto e PE gráfico x64. SHA-256 comprova integridade, não identidade do editor.

Nesta revisão foi reutilizado o runtime da dev4 verificada, sem baixar novos binários ou mudar dependências. A poda mantém o conjunto de DLLs Qt necessário e licenças. `pefile` é dependência de build, não do usuário. Ferramentas PyInstaller de versões anteriores permanecem no código para compatibilidade; não são a rota de distribuição atual.

## CLI e compatibilidade

O usuário opera pela GUI. Para desenvolvimento, depois de configurar uma instalação isolada, `python -m orquestrador_app --data-root <pasta> ...` aceita `list-jobs`, `run`, `login`, `doctor`, `configure-schedules`, `--job`, `--force`, `--dry-run`, `--repair`, `--agent`, `--scheduled` e `--health-check`. Veja `--help` para a posição dos argumentos. `configure-schedules` abre a interface do produto.

O legado `pipefy_orchestrator.py --config <JSON> ...` e os CMD/PowerShell antigos continuam preservados no pacote técnico. Usam configuração, estado e modelo de disparos antigos; não são o caminho de instalação/execução da edição CAIO. A CLI nova não promete equivalência de todos os argumentos antigos, como `--config` e `--delay-seconds`.

O wizard nativo atual abre instalações de teste existentes e cria novas. Não oferece importação direta da instalação de produção v1.3.0. O importador legado existe na camada Qt/técnica: redireciona os caminhos ao ambiente de teste, não transfere sucessos nem tarefas de produção e deixa extras importados desabilitados. Não execute os antigos instaladores de tarefas junto do monitor novo.

## Backup, restauração e recuperação

Antes da ativação, a instalação guarda versão anterior, configuração, SQLite consistente, scripts adicionais, ponteiro de instalação, tarefa e atalhos próprios. Prepara a versão separadamente e valida hashes e saúde local. Falhas de cópia, migração, ativação ou health check acionam rollback; uma recuperação incompleta é erro visível. Atualização não depende de VPN ou extração corporativa.

O atualizador externo espera o PID e seu instante de criação para não confundir processos reutilizados. Não encerra processos alheios e não sobrescreve runtime em uso. A manutenção bloqueia execução ativa. Cancelamento durante cópia é cooperativo; interrupção abrupta é tratada pelo journal na próxima abertura.

Restauração de relatório adquire lock, verifica hash e guarda a versão atual antes da troca. Retenção por quantidade/idade/espaço preserva pelo menos o backup mais recente, mesmo se ele exceder sozinho o orçamento. Alteração do backup impede limpeza silenciosa. Eventos rejeita chaves vazias/ausentes e não publica novamente quando não há linhas novas. Separador e codificação precisam corresponder ao histórico existente.

Para recuperar configuração/estado, selecione um backup de **aplicativo** no fluxo de reversão; um backup de relatório não serve. Não edite manualmente ponteiros ou journals. A desinstalação remove ativação, tarefa e atalhos próprios e preserva dados; não equivale a purgar todo o diretório de versões/backups.

## Proveniência, versões e limites

Versionamento exclusivamente interno, sem novo branch/commit/tag. Antes da edição foram conferidos os 181 arquivos do snapshot da dev4. A entrega anterior tinha SHA-256 `a12c74e1e815b522ab9bc65f69a9b2b0c17f3d35c7f34c802e7c3b276e254935`; o código técnico, `481476e201ab231183521122022637e8c708728c1756a0ad7a3f71f5832914b5`. Manifestos desta revisão registram arquivos criados, alterados e removidos. Os cinco extratores são comparados byte a byte; não foram feitas extrações ou mudanças em produção.

O ensaio anterior de dev3/dev4 foi conservado em `evidencias/dev4-benchmark-comparison.json`: três processos por versão, CPython 3.12.14, Linux x64, Qt offscreen, timer de 10 ms por quatro segundos. Mediana de abertura aproximada: 0,189/0,299 s; RSS: 78,6/85,1 MiB; máximo de intervalo do timer: 26/16 ms. A dev4 aumentou abertura e RAM no ensaio, embora reduzisse redesenhos e pacote. **A dev5 não recebeu novo benchmark** e não há números de desempenho Windows.

Limites de validação permanecem em `VALIDACAO.md`. Não se afirma liberação por antivírus, assinatura própria, teste Windows sem Python ou homologação corporativa. A aprovação automática anterior de sintaxe não cobria o carregamento do catálogo; esta regressão agora tem verificação executável específica.

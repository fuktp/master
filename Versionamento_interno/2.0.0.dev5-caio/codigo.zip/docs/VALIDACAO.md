# CAIO 2.0.0.dev5 — matriz e evidências

Revisão de 22/10/2026. **Correção de software verificada; homologação completa em Windows pendente.** “Passou” abaixo indica o teste efetivamente executado em Linux, Qt offscreen ou PowerShell 7.4.13/Linux. Simulações de Windows não são testes nativos.

## Resultado desta revisão

| Verificação | Resultado | Evidência em `docs/evidencias` |
|---|---|---|
| Falha relatada no catálogo da dev4 | Reproduzida no leitor real do PowerShell | `dev5-reproduction.json` |
| Regressão antes da correção | Teste recusou 345 entradas com 344 chaves únicas | `dev5-regression-before.txt` |
| Suíte após a correção | 168 testes e 7 subtestes passaram | `dev5-tests.txt`, `dev5-tests.xml` |
| Leitura do catálogo, sintaxe PS1 e auxiliares | 11 verificações passaram | `dev5-powershell.json` |
| Catálogo do ZIP entregue | 344 entradas lidas pelo PowerShell após extrair o ZIP; ambas as formas do estado traduzidas | `dev5-packaged-json.json` |
| Lint, formatação e tipos | Passaram; 51 arquivos formatados, 33 analisados por mypy | `dev5-lint.txt`, `dev5-format.txt`, `dev5-types.txt` |
| Saúde do código | Cinco extratores, seis abas e oito páginas Qt; sem rede | `dev5-health.json` |
| Documentação | 15 documentos revisados, consolidados em três vigentes | `dev5-doc-review.json` |
| Preservação | Snapshot dev4 verificado antes da edição; cinco extratores comparados sem alterações | `dev5-preservation.json` |
| Dependências | 41 entradas fixadas auditadas; nenhuma vulnerabilidade conhecida encontrada; lock válido | `dev5-dependency-audit.json`, `dev5-lock.txt` |
| Pacote | 4.096 arquivos de payload verificados; código e README correspondem aos fontes | `dev5-build.json`, `dev5-artifact.json` |

O teste PowerShell agora carrega o catálogo real; a versão anterior testava apenas a sintaxe dos scripts e JSON sintético. `health_check()` constrói a interface Qt e o wizard Qt de compatibilidade, não a janela WinForms. A distinção é necessária para não repetir a conclusão indevida de que esses testes comprovam a abertura do instalador Windows.

## Matriz consolidada

Os números 1–23 correspondem aos critérios originais, com as alterações posteriores do usuário: ZIP/VBS substitui EXE próprio; versionamento interno substitui Git; instalação de teste não substitui produção.

| Requisito | Implementação | Teste executado | Resultado / limitação |
|---|---|---|---|
| 1. Preservação e isolamento | Snapshot dev4, hashes, sandbox de caminhos, pasta escolhida | Manifesto; `test_test_edition.py` | Passou; sem dados/estado corporativos reais |
| 2. Horário próprio fora dos globais | `schedule.eligible`, monitor por rotina | `test_own_time_outside_global_schedule` | Passou para 18:07; Agendador real pendente |
| 3. Daily e every_run | Períodos e ocorrências persistidos | `test_daily_multiple_opportunities_and_force_disabled`, `test_every_run_catch_up_collapses_and_persists_occurrences` | Passou; sem extração corporativa |
| 4. Semanal, reinício, atraso e fuso | Semana ISO, janela de recuperação, identidade da hora local | `test_schedule.py` | Passou com relógios controlados; mudança real de fuso Windows pendente |
| 5. Migração e GUI fechada | Tarefa própria e agente; teste não adota tarefas de produção | `test_real_background_agent_processes_queue_with_main_interface_closed`, XML de tarefa | Passou em subprocesso Linux; migração de produção não executada |
| 6. Dependências e ciclos | Grafo, same_chain/fresh_success, validade explícita, bloqueio propagado | `test_engine.py` | Passou; independentes continuam conforme política |
| 7. Conectividade inconclusiva | Evidências de DNS/TCP/HTTP/VPN | `test_connectivity_requires_multiple_signals`, teste de servidor indisponível | Passou com evidências simuladas; sem VPN corporativa |
| 8. KWMS 2 tentativas/30 s/código 20 | Adaptador mantém fluxo interno; sem retry externo | `test_kwms_schedule.py`, `test_new_kwms_adapter_two_attempts_30_seconds_then_pending` | Passou; espera solicitada de 30 s verificada por mock, sem sinalização Windows real |
| 9. Retries por categoria | Limite/backoff/timeout; bloqueio republica staging | `test_category_retry_limit_and_auth_no_loop`, teste de republicação | Passou com falhas simuladas |
| 10. SSO/MFA e login separado | Sessão interativa, teste de login não consome frequência | Teste de estado e inspeção do adaptador | Parcial; login corporativo real não executado |
| 11. Downloads inválidos/Excel | Validação antes de publicar, preservação do anterior | `test_files.py`, testes KWMS | Passou com arquivos sintéticos e PermissionError; Excel real pendente |
| 12. Backup, retenção e restauração | Catálogo com hashes, backup obrigatório, locks | `test_files.py` | Passou com arquivos reais sintéticos; OneDrive/compartilhamento Windows pendente |
| 13. Eventos e publicação local | Merge idempotente e validadores dos extratores | `test_events_idempotent_missing_keys_and_backup`, workers locais | Passou sem navegador e sem dados corporativos |
| 14. Concorrência e processos | Locks OS e encerramento de processos próprios | `test_processes_gui.py`, lock no engine | Passou Linux; Job Object/concorrência Windows pendentes |
| 15. Pausa, retomada, cancelamento | Checkpoints, revalidação e timeout cooperativo | `test_checkpoint_cancel_does_not_publish`, processos e cancelamento do instalador | Parcial; navegador real em pausa não exercitado |
| 16. Painel, avisos e monitor | Qt/QThread, fila deduplicada, atraso e agente | Testes GUI/timer e monitor em subprocesso | Passou local; notificação nativa e clique Windows pendentes |
| 17. OneDrive e outros usuários | Descoberta de contas, seleção explícita, caminhos isolados | Testes de contas múltiplas e espaços/acentos | Passou com entradas simuladas; registro Windows real pendente |
| 18. ATMS e extras | Cinco scripts preservados, cadastro e versões | Hashes; worker ATMS local; script adicional real | Passou; scripts desconhecidos/dependências futuras não homologados |
| 19. Windows sem Python/sem console | Runtime privado, pythonw PE GUI, VBS, subprocessos ocultos | Verificação estrutural do PE e flags | Parcial; execução completa em Windows limpo não feita |
| 20. Atualização e rollback | Journal, staging, backup e health sem rede | `test_install.py`, `test_native_distribution.py` com falhas induzidas | Passou com runtime/atalhos/tarefas de fixture; rollback Windows real pendente |
| 21. Agendador real | `schtasks`, sessão interativa e tarefa própria | XML, backend fake e diferenças | Não executado em Windows |
| 22. Wizard e pacote único | ZIP com VBS/BAT numerados, WinForms e aplicação Qt | Integridade do ZIP, leitura JSON real, parser PS | Pacote gerado/verificado; primeiro uso WinForms ainda não homologado |
| 23. Produto e atalho únicos | Um produto; atalhos na Área de Trabalho/Menu Iniciar; tarefa usa o mesmo lançador | XML/atalhos em backend de teste | Sem atalhos por extrator; COM Windows real pendente |
| Erro Desabilitada/desabilitada | Chave única; Python consulta sem distinguir caixa | Três novos casos Python + leitor real PowerShell | Passou; não exige instalar PowerShell 7 |
| Três idiomas | Catálogo compartilhado, seleção na interface | Teste Qt parametrizado PT-BR/EN/ES; duas formas de estado EN/ES | Passou; textos de scripts/logs externos não são traduzidos |
| Tema, logo e contraste | QPalette explícita, cores KPMG Claro, ICO | Asserções de paleta e presença/hash do ícone | Passou Qt/estrutura; DPI e renderização WinForms pendentes |
| Seletores de dias/horários/ordem | Botões com tooltip, vários horários, dropdown reposiciona ordem | `test_translated_visible_controls_selection_and_new_script_path` | Passou Qt; editor WinForms somente parser/revisão de código |
| Frequência weekdays e previsão inicial | Dias úteis e preview nativo ativo; pausa existente preservada | Testes weekdays e preview | Passou; monitor precisa ser instalado explicitamente |
| Fila de 30 s entre rotinas | `queue_delay_seconds`, espera após término anterior | `test_queue_delay_is_after_previous_finish_and_cancellable` | Início 0/35 s com rotina de 5 s em relógio simulado; sem benchmark real |
| Driver encontrado/reparado | Busca limitada, assinatura/versão, resolução oficial | Testes de candidatos/reparo e regressão legada | Passou com doubles; Authenticode/Edge reais pendentes |
| Conectividade usa regra KWMS | Sonda e is_empty_response, navegador temporário somente leitura | `test_kwms_diagnostic_uses_real_empty_response_rule_and_preserves_inconclusive` | Passou com navegador falso, sem consumir frequência |
| Troca e versionamento de scripts | Cadastro, snapshots e restauração em cópia gerenciada | Versões, remoção e worker real sem autorização por hash | Passou; auxiliares do script não são copiados automaticamente |
| Exclusão de rotina | Confirmação; cadastro apenas ou purga de cópias gerenciadas | Teste de remoção/reinclusão | Passou; original externo/relatórios/histórico preservados |
| Exportação/importação de preferências | Whitelist portátil, prévia e validação | `test_portable_round_trip_includes_language_delay_and_excludes_script_versions` | Passou; parâmetros de máquina não transportados |
| Histórico/Dev JSON e XLSX | Sanitização e neutralização de fórmulas | `test_json_xlsx_sanitization_and_formula_cells` | Passou com leitura real do XLSX |
| Tarefas sem null e relatório de diferenças | Retornos install/remove e comparação do XML | Testes de tarefas em `test_caio_revision.py` | Passou backend fake; falhas de consulta reais ainda exigem validação |
| Atualização sem feed HTTPS | Interface sem consulta ao feed; ZIP local verificado | Testes de ZIP, integridade e transação | Passou local; reinício Windows real pendente |
| Logs/progresso e painel Dev | Atualização por mudança, estados, leitura em thread e horário em segundos | Testes GUI/Dev/timer; inspeção dos callbacks | Passou Qt; nenhum percentual fictício e nenhuma evidência Windows inferida |
| Documentos vigentes sem conflito | README operacional + técnico + matriz única; builder usa README atual | Inventário dos 15 documentos e conferência do README empacotado | Consolidado; histórico anterior apenas nos snapshots |

## O que não foi executado

Windows PowerShell 5.1, WinForms real, duplo clique VBS/BAT, atalhos COM, Agendador real, instalação em Windows sem Python global, ciclo completo instalar/atualizar/reparar/cancelar/reverter, assinatura Authenticode real, SSO/MFA, VPN, download corporativo interrompido e bloqueio pelo Excel. Não há certificado próprio, liberação comprovada por SmartScreen/Defender nem benchmark Windows.

O teste padrão bloqueia rede corporativa e usa diretórios temporários. Não foram alterados agendamentos, perfis ou arquivos de produção. Os exemplos/falhas induzidas utilizam fixtures explícitas. Auditoria consulta vulnerabilidades conhecidas e não garante ausência de falhas.

Antes de aprovar produção, execute o teste PowerShell pelo host do iniciador e percorra o wizard/atualização em Windows autorizado e isolado. Confirme sessão, notificações, processos, tarefas e os casos corporativos acima. A versão entregue permite esse teste; a evidência local não o substitui.

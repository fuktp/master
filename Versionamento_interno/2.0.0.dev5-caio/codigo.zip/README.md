# CAIO — versão de teste 2.0.0.dev5

Aplicativo Windows de automação, com interface em português, inglês e espanhol. Esta versão corrige a falha de instalação causada pelas chaves duplicadas `Desabilitada` e `desabilitada` no catálogo de idiomas.

## Instalar ou atualizar

1. Extraia **todo o ZIP novo em uma pasta separada**. Não misture seu conteúdo com o ZIP anterior.
2. Abra **01 - Instalar.vbs**. A alternativa **01 - Instalar(alt).bat** pode mostrar brevemente uma janela de CMD.
3. Escolha o idioma e a ação. **Instalar / atualizar** cria uma instalação ou atualiza uma instalação de teste reconhecida; **Reparar instalação** repõe os componentes do pacote; **Abrir versão instalada** apenas inicia o aplicativo existente.
4. Escolha uma pasta vazia exclusiva do teste ou a pasta de uma instalação de teste existente. Não escolha a pasta de produção nem a pasta onde extraiu o ZIP.
5. Confira identificação, e-mail, destinos e rotinas. Edite frequência, dias, horários e ordem. Selecione o monitor somente se quiser execuções automáticas com a janela principal fechada.
6. Aguarde a validação automática, acompanhe o log central, revise as alterações e confirme a instalação. Ao terminar, abra o aplicativo pelos atalhos do produto.

Se a dev4 exibiu **“instalação não iniciada”** com o erro de chaves duplicadas, abra o VBS deste novo ZIP. Não é necessário editar JSON, apagar configurações ou desinstalar. Se já havia uma instalação reconhecida, escolha sua mesma pasta no wizard; seus dados entram no backup da atualização.

Python 3.13.16 e as bibliotecas estão incluídos em um runtime privado. O usuário não precisa instalar Python, pip ou executar comandos. A entrada é o VBS, não um EXE próprio; executáveis internos do Python e da automação continuam necessários. Mantenha a pasta `payload` junto dos iniciadores e não execute seus arquivos manualmente.

Requer Windows x64, sessão de usuário compatível e Edge para as rotinas de navegador. Scripts e pacote não têm certificado próprio. O iniciador não altera políticas persistentes nem desativa proteções: se a organização bloquear VBS/PowerShell/runtime, a TI precisa avaliar a execução. Trocar EXE por scripts não garante liberação pelo SmartScreen ou Defender.

## Onde ficam os arquivos

| Dentro da pasta escolhida | Conteúdo |
|---|---|
| `app/versions` e `launch` | Versões instaladas, runtime privado e lançadores |
| `config.json` e `state` | Configuração, histórico SQLite, frequência e locks |
| `profiles/Edge-Teste`, `downloads`, `cache` | Perfil dedicado, temporários e driver gerenciado |
| `relatorios` e `logs` | Destinos de teste e registros de execução |
| `backups` | Versões anteriores dos relatórios; `backups/app` guarda o aplicativo |
| `extras` e `versionamento` | Scripts adicionais, snapshots e manifestos internos |

Os destinos, perfil, logs e driver gerenciados ficam dentro do ambiente de teste. OneDrive é detectado para identificação; gravar localmente não comprova sincronização. Os extratores Clientes, Eventos, Procedimentos, KWMS e ATMS foram preservados. Scripts adicionais são código local confiável, não executam em uma sandbox de segurança do Windows.

## Usar o aplicativo

- **Painel:** executar, forçar, simular, testar login e acompanhar estado/log. Uma rotina selecionada mostra ações individuais; várias mostram ações para o lote selecionado. Sem seleção, “Executar todas” fica separado. A barra aparece durante operações.
- **Rotinas e agendamentos:** habilitar, editar, cadastrar e excluir rotinas; definir horários próprios, dias, sequência, dependências, retries e timeout. Campos avançados usam JSON validado, com explicações na interface.
- **Configurações:** idioma, e-mail, perfil, navegador visível/headless, destinos, retenção, notificações, histórico de Eventos e preferências portáveis. Exportação/importação mostra prévia e não transporta segredos nem caminhos de outra máquina.
- **Histórico e logs / Dev • Internos:** resultados e eventos correlacionados, estado interno, versões e autoteste local. Exportações sanitizadas em JSON e XLSX.
- **Diagnóstico e manutenção:** conectividade, EdgeDriver, tarefas, backup e restauração. A tabela de backups só tem entradas depois de substituir um relatório válido.

Fechar a janela minimiza a interface; **Sair da interface** encerra-a. Uma execução em andamento requer manter o processo ou cancelar de forma controlada. Pausar agendamento impede novos disparos. Pausar execução espera um checkpoint seguro; não interrompe uma publicação no meio. Cancelar preserva o arquivo anterior e não registra sucesso.

### Frequências e monitor

| Frequência | Resultado esperado |
|---|---|
| Diária | Um sucesso por data local; horários seguintes recuperam pendências |
| Somente dias úteis / weekdays only | Diária de segunda a sexta, sem excluir feriados |
| Semanal | Um sucesso por semana de segunda a domingo; dia inicial e demais dias selecionados controlam elegibilidade e recuperação |
| Todos os horários / every_run | Uma execução por ocorrência própria, inclusive após sucesso no mesmo dia |

Use os botões dos dias e adicione um ou mais horários. O tooltip mostra o dia completo. Alterar a ordem reposiciona as demais rotinas; dependências prevalecem sobre a sequência visual. Origem desabilitada ou sem o sucesso exigido bloqueia sua dependente. Sucesso anterior só vale com janela de validade explícita.

Uma instalação nova calcula as próximas execuções com agendamento ativo, mas **o monitor é opcional**. Sem instalar o monitor, a previsão não significa que exista uma tarefa automática. Instale-o no wizard ou em manutenção. Ele usa uma tarefa própria, verifica a fila e os avisos de atraso com a interface fechada e exige usuário conectado; não é serviço Windows. Uma atualização preserva pausas anteriores.

Horários simultâneos entram em fila, sem concorrência no perfil. O intervalo padrão é **30 segundos após terminar a rotina anterior**, configurável; não se aplica ao lote manual. O fuso vem do Windows. Horários perdidos são agrupados na ocorrência elegível mais recente da janela de recuperação, padrão 24 horas; não há repetição de todo o atraso. Uma ocorrência já tentada aguarda a próxima oportunidade.

**Forçar** ignora a frequência só naquela execução e não habilita uma rotina desativada. Login, diagnóstico, publicação local e restauração não contam como nova extração bem-sucedida.

### Scripts e versões

**Cadastrar script** seleciona um `.py`, inicialmente desabilitado. Revise subcomando, argumentos, ambiente, navegador, pasta de trabalho e saída antes de habilitar. Deixe o subcomando vazio para scripts sem CLI. As bibliotecas utilizadas precisam existir no runtime; não há instalação automática de dependências de scripts futuros.

Alterar o arquivo ou seu caminho não pede nova autorização por hash. Os hashes identificam snapshots e verificam integridade. **Versões do script** permite listar e restaurar cópias; a restauração cria uma cópia gerenciada sem sobrescrever o arquivo externo original. O snapshot de um script não inclui automaticamente arquivos auxiliares.

**Excluir rotina** pede confirmação. Por padrão retira apenas o cadastro, preservando histórico e versões. A opção adicional remove somente cópias gerenciadas; não apaga o script externo nem relatórios. Remova dependências que apontem para a rotina antes de excluí-la.

Substituir um extrator conhecido exige preservar seu contrato. Um script com funcionamento diferente deve ser cadastrado como adicional. As opções de URL substituem o endereço utilizado pelo adaptador quando este oferece suporte; não criam seletores ou um fluxo de login novo.

### Driver, conectividade e relatórios

O EdgeDriver é verificado antes das extrações. A reparação procura caminhos configurados, PATH, caches Selenium e pastas comuns do usuário; `driver_options.search_paths` permite acrescentar raízes. A busca é limitada, não varre todo o disco. Sem candidato compatível, utiliza a resolução/download oficial existente e verifica versão e assinatura antes de usar a cópia gerenciada.

O diagnóstico KWMS combina sinais de conectividade e do destino; quando necessário, verifica a resposta com navegador temporário próprio. Uma resposta vazia isolada permanece inconclusiva. No fluxo KWMS correspondente, mantém aviso, espera de 30 segundos e segunda tentativa; código 20 deixa a rotina pendente e continua o lote sem retries externos adicionais. SSO/MFA continua exigindo interação autorizada.

**Publicar arquivo local** valida um arquivo já baixado sem abrir navegador. Clientes, Procedimentos e ATMS usam seus validadores; Eventos mescla o histórico e deduplica pela chave configurada. Arquivo inválido, incompleto ou bloqueado não substitui o anterior. A publicação cria backup obrigatório antes da troca. Restaurar relatório preserva a versão atual e não registra uma nova extração.

## Backup, reparo e atualização

Use **Configurações > Atualização… > Atualizar por ZIP local…** ou abra o iniciador do pacote novo. O feed HTTPS fica indisponível nesta edição; não há consulta automática a servidor.

A atualização exige execução encerrada, cria backup de configuração, estado, scripts, versão, atalhos e tarefa própria, prepara outra pasta e faz verificações locais. Falhas internas acionam rollback. Falhas externas de VPN/servidor não são critério de atualização. Interrupções transacionais são tratadas pelo journal na abertura seguinte; uma recuperação incompleta permanece sinalizada como erro.

Para reparo, abra o wizard e escolha **Reparar instalação**. Para reversão, use **Reverter atualização** e selecione um backup gerenciado do aplicativo. Backups de relatório e de aplicativo são diferentes. A retenção dos relatórios limpa só itens gerenciados e preserva a versão mais recente; não apaga backups do aplicativo. A desinstalação preserva dados por padrão.

## Validação e documentação técnica

Esta é uma versão de teste. A correção foi reproduzida e verificada com o leitor JSON do PowerShell disponível no ambiente de desenvolvimento. **O fluxo completo em Windows real não foi homologado**: WinForms, atalhos, Agendador, login corporativo, VPN, Excel e ausência visual de console continuam pendentes.

O pacote técnico contém somente três documentos vigentes: este `README.md`, `docs/TECNICO.md` (build, compatibilidade, manutenção e histórico da revisão) e `docs/VALIDACAO.md` (matriz e evidências). Documentos antigos ficam apenas no snapshot anterior do versionamento interno. Não são instruções de instalação desta versão.

# CAIO — versão de teste 2.0.0.dev7

Aplicativo Windows de automação, com interface em português, inglês e espanhol. Esta revisão corrige a consulta COM que bloqueava o backup da instalação quando a tarefa do monitor ainda não existia, os botões de rotinas da tela de destinos e o editor de horários. As melhorias do aplicativo da dev6 foram preservadas.

## Instalar ou atualizar

1. Extraia **todo o ZIP novo em uma pasta separada**. Não misture seu conteúdo com o ZIP anterior.
2. Abra **01 - Instalar.vbs**. A alternativa **01 - Instalar(alt).bat** pode mostrar brevemente uma janela de CMD.
3. Escolha o idioma e a ação. **Instalar / atualizar** cria uma instalação ou atualiza uma instalação de teste reconhecida; **Reparar instalação** repõe os componentes do pacote; **Abrir versão instalada** apenas inicia o aplicativo existente.
4. Escolha uma pasta vazia exclusiva do teste ou a pasta de uma instalação de teste existente. Não escolha a pasta de produção nem a pasta onde extraiu o ZIP.
5. Confira identificação, e-mail, destinos e rotinas. O e-mail é obrigatório: Avançar só fica disponível com um endereço válido. Edite frequência, dias, horários e ordem. Selecione o monitor somente se quiser execuções automáticas com a janela principal fechada.
6. Aguarde a validação automática, acompanhe o log central, revise as alterações e confirme a instalação. Ao terminar, abra o aplicativo pelos atalhos do produto.

Se a tentativa anterior parou no backup da tarefa, abra o iniciador deste ZIP e selecione novamente a mesma pasta de teste reconhecida. Não apague configurações nem backups para repetir a instalação.

Depois de atualizar, confirme **CAIO • Teste 2.0.0.dev7** no título da janela. O atalho existente abre a versão apontada pela instalação. Se um ícone fixado manualmente na barra de tarefas ainda apontar para um lançador antigo do Python/WSH, desafixe-o e fixe a janela CAIO atual; a atualização não altera itens externos fixados pelo usuário.

Janelas, bandeja, atalhos e mensagens usam o mesmo ICO CAIO. Os atalhos passam a ter identidade própria do Windows e nome de arquivo de ícone baseado no conteúdo, evitando reutilizar o caminho do ícone antigo em cache. Abrir o atalho novamente solicita o foco da janela já aberta, inclusive para detalhes de notificações.

Python 3.13.16 e as bibliotecas estão incluídos em um runtime privado. O usuário não precisa instalar Python, pip ou executar comandos. A entrada é o VBS, não um EXE próprio; executáveis internos do Python e da automação continuam necessários. Mantenha a pasta `payload` junto dos iniciadores e não execute seus arquivos manualmente.

Requer Windows x64, sessão de usuário compatível e Edge para as rotinas de navegador. Scripts e pacote não têm certificado próprio. O iniciador não altera políticas persistentes nem desativa proteções: se a organização bloquear VBS/PowerShell/runtime, a TI precisa avaliar a execução. Trocar EXE por scripts não garante liberação pelo SmartScreen ou Defender.

## Onde ficam os arquivos

| Dentro da pasta escolhida | Conteúdo |
|---|---|
| `app/versions` e `launch` | Versões instaladas, runtime privado e lançadores |
| `config.json` e `state` | Configuração, histórico SQLite, frequência e locks |
| `profiles/Edge-Teste`, `downloads`, `cache` | Perfil dedicado, temporários e driver gerenciado |
| `relatorios` e `logs` | Destinos de teste e registros de execução |
| `backups` | Versões anteriores dos relatórios; `backups/app` guarda o aplicativo |
| `extras` e `versionamento` | Scripts adicionais, snapshots e manifestos internos |

Os destinos, perfil, logs e driver gerenciados ficam dentro do ambiente de teste. OneDrive é detectado para identificação; gravar localmente não comprova sincronização. Os extratores Clientes, Eventos, Procedimentos, KWMS e ATMS foram preservados. Scripts adicionais são código local confiável, não executam em uma sandbox de segurança do Windows.

## Usar o aplicativo

- **Painel:** executar, forçar, simular, testar login e acompanhar estado/log. Uma rotina selecionada mostra ações individuais; várias mostram ações para o lote selecionado. Sem seleção, “Executar todas” fica separado. A barra aparece durante operações.
- **Rotinas e agendamentos:** habilitar, editar, cadastrar e excluir rotinas; definir horários próprios, dias, sequência, dependências, retries e timeout. Campos avançados usam JSON validado, com explicações na interface.
- **Configurações:** idioma, e-mail, perfil, navegador visível/headless, destinos, retenção, notificações, histórico de Eventos e preferências portáveis. Exportação/importação mostra prévia e não transporta segredos nem caminhos de outra máquina.
- **Histórico e logs / Dev • Internos:** resultados e eventos correlacionados, estado interno, versões e autoteste local. Exportações sanitizadas em JSON e XLSX.
- **Diagnóstico e manutenção:** conectividade, EdgeDriver, tarefas, backup e restauração. A comparação de tarefas mostra campos efetivos/esperados e sinaliza diferenças. A tabela separada de backups só tem entradas depois de substituir um relatório válido.

O painel de atividade central permanece visível em todas as abas e mostra andamento, avisos e resultado. As mensagens de inelegibilidade explicam quando nenhuma rotina rodou. Fechar a janela minimiza a interface; **Sair da interface** encerra-a. Uma execução em andamento requer manter o processo ou cancelar de forma controlada. Pausar agendamento impede novos disparos automáticos; a execução manual continua disponível e respeita frequência/dias, salvo Forçar. Uma rotina desabilitada continua bloqueada. Pausar execução espera um checkpoint seguro; não interrompe uma publicação no meio. Cancelar preserva o arquivo anterior e não registra sucesso.

### Frequências e monitor

| Frequência | Resultado esperado |
|---|---|
| Diária | Um sucesso por data local; horários seguintes recuperam pendências |
| Somente dias úteis / weekdays only | Diária de segunda a sexta, sem excluir feriados |
| Semanal | Um sucesso por semana de segunda a domingo; dia inicial e demais dias selecionados controlam elegibilidade e recuperação |
| Todos os horários / every_run | Uma execução por ocorrência própria, inclusive após sucesso no mesmo dia |

Em uma instalação nova pelo wizard, Diária e Todos os horários começam com os sete dias; Somente dias úteis começa de segunda a sexta; Semanal começa no dia inicial, segunda-feira por padrão. Para oferecer recuperação semanal em outros dias, selecione também esses dias. Configurações existentes conservam seus dias e pausas.

Use os botões dos dias e adicione um ou mais horários. O campo **Calendário** identifica **Padrão da frequência** ou **Personalizado** automaticamente. Personalizado descreve os dias e mantém a regra de sucesso escolhida em Frequência. Para voltar ao conjunto padrão, selecione Padrão da frequência. A política Somente dias úteis continua excluindo sábado e domingo. O tooltip mostra o dia completo. O editor usa campos com altura mínima calculada pela fonte, layout automático e rolagem, em vez de coordenadas sobrepostas. Alterar a ordem reposiciona as demais rotinas; dependências prevalecem sobre a sequência visual. Origem desabilitada ou sem o sucesso exigido bloqueia sua dependente. Sucesso anterior só vale com janela de validade explícita.

Uma instalação nova calcula as próximas execuções com agendamento ativo, mas **o monitor é opcional**. Sem instalar o monitor, a previsão não significa que exista uma tarefa automática. Instale-o no wizard ou em manutenção. Ele usa uma tarefa própria, verifica a fila e os avisos de atraso com a interface fechada e exige usuário conectado; não é serviço Windows. Uma atualização preserva pausas anteriores.

Horários simultâneos entram em fila, sem concorrência no perfil. O intervalo padrão é **30 segundos após terminar a rotina anterior**, configurável; não se aplica ao lote manual. O fuso vem do Windows. Horários perdidos são agrupados na ocorrência elegível mais recente da janela de recuperação, padrão 24 horas; não há repetição de todo o atraso. Uma ocorrência já tentada aguarda a próxima oportunidade.

**Forçar** ignora a frequência só naquela execução e não habilita uma rotina desativada. Login, diagnóstico, publicação local e restauração não contam como nova extração bem-sucedida.

### Scripts e versões

**Cadastrar script** seleciona um `.py`, inicialmente desabilitado. Nomes com espaços ou acentos mantêm o rótulo e recebem identificador interno compatível; o arquivo original é preservado. Revise subcomando, argumentos, ambiente, navegador, pasta de trabalho e saída antes de habilitar. Deixe o subcomando vazio para scripts sem CLI. As bibliotecas utilizadas precisam existir no runtime; não há instalação automática de dependências de scripts futuros.

Alterar o arquivo ou seu caminho não pede nova autorização por hash. Os hashes identificam snapshots e verificam integridade. **Versões do script** permite listar e restaurar cópias; a restauração cria uma cópia gerenciada sem sobrescrever o arquivo externo original. O snapshot de um script não inclui automaticamente arquivos auxiliares.

**Excluir rotina** pede confirmação. Por padrão retira apenas o cadastro, preservando histórico e versões. A opção adicional remove somente cópias gerenciadas; não apaga o script externo nem relatórios. Remova dependências que apontem para a rotina antes de excluí-la.

Substituir um extrator conhecido exige preservar seu contrato. Um script com funcionamento diferente deve ser cadastrado como adicional. As opções de URL substituem o endereço utilizado pelo adaptador quando este oferece suporte; não criam seletores ou um fluxo de login novo.

### Driver, conectividade e relatórios

O EdgeDriver é verificado antes das extrações. A preparação automática acontece ao abrir uma instalação nativa e antes das extrações, em segundo plano. A reparação procura caminhos configurados, PATH, caches Selenium, pastas comuns do usuário e caminhos literais de driver nos scripts registrados, sem importá-los; `driver_options.search_paths` permite acrescentar raízes. A busca é limitada por raiz e profundidade, prioriza locais configurados e não varre todo o disco. Selecionar um driver externo nas configurações preserva seu arquivo, registra-o como candidato e valida/copia para o cache da instalação. Sem candidato compatível, utiliza a resolução/download oficial existente e verifica versão e assinatura antes de usar a cópia gerenciada.

Em manutenção, escolha explicitamente o destino do teste de conectividade/VPN; KWMS é a seleção inicial quando disponível. O diagnóstico KWMS combina sinais de conectividade e do destino; quando necessário, verifica a resposta com navegador temporário próprio. Uma resposta vazia isolada permanece inconclusiva. No fluxo KWMS correspondente, mantém aviso, espera de 30 segundos e segunda tentativa; código 20 deixa a rotina pendente e continua o lote sem retries externos adicionais. SSO/MFA continua exigindo interação autorizada.

**Publicar arquivo local** valida um arquivo já baixado sem abrir navegador. Clientes, Procedimentos e ATMS usam seus validadores; Eventos mescla o histórico e deduplica pela chave configurada. Arquivo inválido, incompleto ou bloqueado não substitui o anterior. A publicação cria backup obrigatório antes da troca. Restaurar relatório preserva a versão atual e não registra uma nova extração.

## Backup, reparo e atualização

Use **Configurações > Atualização… > Atualizar por ZIP local…** ou abra o iniciador do pacote novo. O feed HTTPS fica indisponível e explicado nesta edição; não há consulta automática a servidor nem checkbox de verificação sem função. Salvar preferências de atualização oferece um seletor de destino JSON.

A atualização exige execução encerrada, cria backup de configuração, estado, scripts, versão, atalhos e tarefa própria, prepara outra pasta e faz verificações locais. Falhas internas acionam rollback. Falhas externas de VPN/servidor não são critério de atualização. Interrupções transacionais são tratadas pelo journal na abertura seguinte; uma recuperação incompleta permanece sinalizada como erro.

Para reparo, abra o wizard e escolha **Reparar instalação**. Para reversão, use **Reverter atualização** e selecione um backup gerenciado do aplicativo. Backups de relatório e de aplicativo são diferentes. A retenção dos relatórios limpa só itens gerenciados e preserva a versão mais recente; não apaga backups do aplicativo. A desinstalação preserva dados por padrão.

## Validação e documentação técnica

Esta é uma versão de teste. O erro COM foi reproduzido com a mesma exceção informada e um backend simulado; a correção foi verificada também no backup de instalação em diretório temporário. Os handlers das páginas 3, 4 e 5 foram exercitados no PowerShell com diálogos substituídos por objetos de teste. **O fluxo completo em Windows real não foi homologado**: WinForms, atalhos, Agendador, login corporativo, VPN, Excel e ausência visual de console continuam pendentes.

O tema completo fornecido pelo usuário está em `assets/dashboard-theme.json` e é carregado pela interface. A regra de reutilização em próximos lançamentos está registrada em `AGENTS.md`, junto das convenções do projeto.

O pacote técnico contém três guias vigentes: este `README.md`, `docs/TECNICO.md` (build, compatibilidade, manutenção e histórico da revisão) e `docs/VALIDACAO.md` (matriz e evidências). Documentos antigos ficam apenas no snapshot anterior do versionamento interno. Não são instruções de instalação desta versão.

from __future__ import annotations

import copy
import dataclasses
import datetime as dt
import importlib.metadata
import json
import logging
import sys
import threading
from pathlib import Path
from typing import Any, Callable

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QAction, QCloseEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QSystemTrayIcon,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QWizard,
    QWizardPage,
)

from . import VERSION
from .clock import local_now
from .config import (
    KNOWN,
    Config,
    Routine,
    Schedule,
    discover,
    from_dict,
    import_preview,
    load,
    migrate,
    portable,
    preset_days,
    save,
    script_identifier,
    to_dict,
    validate,
)
from .connectivity import as_dict, classify, probe
from .driver import diagnose
from .engine import Engine
from .files import Publisher
from .i18n import install_translation, tr, translate_tree
from .install import Installer
from .io import BusyError, Lock, atomic_json, digest, read_json
from .paths import Paths, check_directory, identity, onedrives
from .processes import spawn
from .resources import script_path, source_root
from .sandbox import check_location, confined, mark, prepare_config, remember
from .store import Store
from .tasks import WindowsTasks, current_user
from .ui import DAYS, DaysPicker, TimesPicker, apply_theme, configure_table, explain, icon, set_cell
from .worker import module_for, public_pipefy

STATUS = {
    "running": "Em execução",
    "success": "Concluída",
    "failed": "Falhou",
    "skipped": "Ignorada; pendente",
    "cancelled": "Cancelada",
    "not_eligible": "Não elegível",
    "ignored": "Desabilitada",
    "blocked_dependency": "Bloqueada por dependência",
}


class Task(QThread):
    done = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, callback: Callable[[], Any], parent: Any = None):
        super().__init__(parent)
        self.callback = callback

    def run(self) -> None:
        owner = threading.get_ident()
        signal = self.progress

        class Output(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                if record.thread == owner:
                    signal.emit(record.getMessage())

        output = Output()
        logger = logging.getLogger()
        logger.addHandler(output)
        try:
            self.done.emit(self.callback())
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            logger.removeHandler(output)


class VpnNotice(QDialog):
    def __init__(self, store: Store, run: str, message: str, parent: QWidget | None = None):
        super().__init__(parent)
        self.store, self.run_id = store, run
        self.setWindowTitle("KWMS • Verifique a VPN")
        layout = QVBoxLayout(self)
        label = QLabel(message)
        label.setWordWrap(True)
        layout.addWidget(label)
        self.countdown = QLabel("Aguardando o próximo registro da execução…")
        layout.addWidget(self.countdown)
        self.clock = QTimer(self)
        self.clock.timeout.connect(self.update_countdown)
        self.clock.start(1000)
        self.update_countdown()
        self.show()
        QApplication.alert(self, 15000)

    def update_countdown(self) -> None:
        with self.store.connect() as db:
            row = db.execute("SELECT status,stage FROM runs WHERE id=?", (self.run_id,)).fetchone()
        if not row or row["status"] != "running":
            self.clock.stop()
            self.close()
            return
        self.countdown.setText(row["stage"])


def button(text: str, callback: Callable[..., Any], layout: Any) -> QPushButton:
    result = QPushButton(tr(text))
    result.clicked.connect(callback)
    layout.addWidget(result)
    return result


def path_field(value: str, *, file: bool = False) -> tuple[QWidget, QLineEdit]:
    widget = QWidget()
    layout = QHBoxLayout(widget)
    layout.setContentsMargins(0, 0, 0, 0)
    field = QLineEdit(value)
    layout.addWidget(field)

    def browse() -> None:
        result = (
            QFileDialog.getOpenFileName(widget, "Selecionar arquivo", field.text())[0]
            if file
            else QFileDialog.getExistingDirectory(widget, "Selecionar pasta", field.text())
        )
        if result:
            field.setText(result)

    choose = button("Escolher…", browse, layout)
    layout.setStretch(0, 1)
    layout.setStretch(1, 1)
    choose.setMinimumHeight(field.sizeHint().height())
    return widget, field


def json_view(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


def show_detail(parent: QWidget, title: str, value: Any) -> None:
    dialog = QDialog(parent)
    dialog.setWindowTitle(title)
    dialog.resize(900, 600)
    layout = QVBoxLayout(dialog)
    content = QPlainTextEdit(value if isinstance(value, str) else json_view(value))
    content.setReadOnly(True)
    layout.addWidget(content)
    button("Fechar", dialog.accept, layout)
    dialog.exec()


class RoutineDialog(QDialog):
    def __init__(self, config: Config, job: Routine, parent: QWidget | None = None):
        super().__init__(parent)
        self.config, self.job = config, job
        self.updated = job
        self.setWindowTitle(f"Rotina • {job.label}")
        self.resize(750, 700)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)
        general = QWidget()
        form = QFormLayout(general)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.enabled = QCheckBox("Habilitar esta rotina")
        self.enabled.setChecked(job.enabled)
        form.addRow(self.enabled)
        form.addRow("Origem", QLabel(job.origin))
        script, self.script = path_field(job.script, file=True)
        form.addRow("Extrator", script)
        self.version = QLineEdit(job.script_version)
        self.version.setPlaceholderText("Ex.: 1.4.0; vazio usa a identificação automática")
        form.addRow("Versão do script", self.version)
        form.addRow(
            explain(
                "Salvar registra a nova versão automaticamente. O arquivo original não será sobrescrito. Scripts cadastrados são código local confiável; não há aprovação repetida por hash."
            )
        )
        self.browser = QCheckBox("Este script utiliza o navegador Edge")
        self.browser.setChecked(job.requires_browser)
        form.addRow(self.browser)
        self.command = QLineEdit(job.command)
        self.command.setPlaceholderText("Vazio para scripts sem subcomando")
        form.addRow("Subcomando do script", self.command)
        self.frequency = QComboBox()
        for label, value in (
            ("Diária: um sucesso por data", "daily"),
            ("Somente dias úteis: um sucesso por dia de segunda a sexta", "weekdays"),
            ("Semanal: um sucesso por semana", "weekly"),
            ("Todos os horários: um sucesso por ocorrência", "every_run"),
        ):
            self.frequency.addItem(label, value)
        self.frequency.setCurrentIndex(max(0, self.frequency.findData(job.schedule.frequency)))
        form.addRow("Frequência", self.frequency)
        self.times = TimesPicker(job.schedule.times)
        form.addRow("Horários próprios", self.times)
        self.days_picker = DaysPicker(job.schedule.days)
        form.addRow("Dias da semana", self.days_picker)
        self.day_pattern = QComboBox()
        self.day_pattern.addItem(tr("Padrão da frequência"))
        self.day_pattern.addItem(tr("Personalizado"))
        form.addRow("Calendário", self.day_pattern)
        form.addRow(
            explain(
                "Selecione os dias pelos botões. Passe o mouse para ver o nome completo. Semanal começa no primeiro dia selecionado; os demais recuperam pendências. Feriados não são excluídos."
            )
        )

        def refresh_day_pattern() -> None:
            days = self.days_picker.values()
            weekday = days[0] if len(days) == 1 else job.schedule.weekday
            standard = days == preset_days(self.frequency.currentData(), weekday)
            self.day_pattern.setCurrentIndex(0 if standard else 1)

        def frequency_changed() -> None:
            self.days_picker.set_days(
                preset_days(self.frequency.currentData(), job.schedule.weekday)
            )
            refresh_day_pattern()

        self.frequency.currentIndexChanged.connect(frequency_changed)
        self.day_pattern.activated.connect(
            lambda index: frequency_changed() if index == 0 else None
        )
        for day in self.days_picker.buttons:
            day.toggled.connect(refresh_day_pattern)
        refresh_day_pattern()
        form.addRow(
            explain(
                "Personalizado preserva os dias escolhidos sem mudar a regra de sucesso da frequência."
            )
        )
        self.paused = QCheckBox("Pausar o agendamento desta rotina")
        self.paused.setChecked(job.schedule.paused)
        form.addRow(self.paused)
        self.order = QComboBox()
        ordered_jobs = sorted(config.routines, key=lambda j: (j.order, j.id))
        self.order.addItems([str(i + 1) for i in range(len(ordered_jobs))])
        self.order.setCurrentIndex(next(i for i, j in enumerate(ordered_jobs) if j.id == job.id))
        form.addRow("Ordem/prioridade na fila", self.order)
        self.headless = QCheckBox("Ocultar janela do navegador (headless)")
        self.headless.setChecked(job.headless)
        form.addRow(self.headless)
        destination, self.destination = path_field(
            str(Path(job.target).parent) if job.target else ""
        )
        form.addRow("Pasta de publicação local", destination)
        self.output_name = QLineEdit(Path(job.target).name if job.target else "")
        self.output_name.setReadOnly(job.id in KNOWN)
        form.addRow("Nome do arquivo final (opcional)", self.output_name)
        if job.id not in KNOWN:
            form.addRow(
                explain(
                    "Sem publicação gerenciada: deixe pasta e nome vazios. Para publicar, informe ambos e configure staged_output nas opções avançadas."
                )
            )
        self.url = QLineEdit(job.url)
        self.url.setPlaceholderText("Vazio preserva a URL confirmada no extrator")
        form.addRow("URL configurável", self.url)
        form.addRow(
            explain(
                "Endereço da página usada pela rotina. Deixe vazio para usar a URL do extrator. Alterar este campo não troca seletores nem credenciais."
            )
        )
        self.browser.setToolTip(
            tr(
                "Ative para preparar EdgeDriver, proteger o perfil e verificar conectividade antes de executar."
            )
        )
        self.paused.setAccessibleName(tr("Pausar o agendamento desta rotina"))
        for widget in (self.headless, self.url):
            widget.setEnabled(self.browser.isChecked())
            self.browser.toggled.connect(widget.setEnabled)
        self.enabled.setToolTip(
            tr("Desabilitada: impede novos disparos manuais e agendados, preservando o histórico.")
        )
        self.paused.setToolTip(
            tr("Pausa apenas o agendamento. Executar/Forçar manualmente continua disponível.")
        )
        self.headless.setToolTip(
            tr(
                "Oculta somente o navegador. SSO e MFA podem exigir Testar login com janela visível."
            )
        )
        note = QLabel(
            "Diária: horários extras recuperam pendências. Todos os horários permite atualizar novamente após um sucesso. Recuperação reúne horários perdidos em uma oportunidade; não reexecuta toda a fila antiga."
        )
        note.setWordWrap(True)
        form.addRow(note)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(general)
        tabs.addTab(scroll, "Rotina e horários")
        advanced = QWidget()
        advanced_form = QFormLayout(advanced)
        data = dataclasses.asdict(job)
        for key in (
            "id",
            "label",
            "script",
            "origin",
            "enabled",
            "order",
            "schedule",
            "trusted_sha256",
            "script_version",
            "requires_browser",
            "command",
            "target",
            "headless",
            "url",
        ):
            data.pop(key)
        data["catch_up_hours"] = job.schedule.catch_up_hours
        self.advanced = QPlainTextEdit(json_view(data))
        advanced_form.addRow(
            QLabel(
                "Dependências: same_chain ou fresh_success + max_age_minutes.\nArgumentos: lista JSON, sem shell. Variáveis não podem conter segredos.\nPrazo esperado: horas em dias habilitados; tolerância em grace_hours.\nTentativas por categoria incluem a tentativa inicial; VPN interna = 2 × 30 s."
            )
        )
        advanced_form.addRow(self.advanced)
        tabs.addTab(advanced, "Dependências, retries e opções")
        controls = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        controls.button(QDialogButtonBox.StandardButton.Save).setText(tr("Salvar"))
        controls.button(QDialogButtonBox.StandardButton.Cancel).setText(tr("Cancelar"))
        controls.accepted.connect(self.accept_values)
        controls.rejected.connect(self.reject)
        layout.addWidget(controls)

    def accept_values(self) -> None:
        try:
            value = dataclasses.asdict(self.job)
            extra = json.loads(self.advanced.toPlainText())
            catchup = extra.pop("catch_up_hours", 24)
            value.update(extra)
            value.update(
                enabled=self.enabled.isChecked(),
                script=self.script.text(),
                order=self.order.currentIndex(),
                script_version=self.version.text().strip(),
                requires_browser=self.browser.isChecked(),
                command=self.command.text().strip(),
                headless=self.headless.isChecked(),
                url=self.url.text().strip(),
            )
            value["schedule"] = dataclasses.asdict(
                Schedule(
                    frequency=self.frequency.currentData(),
                    times=self.times.values(),
                    days=self.days_picker.values(),
                    weekday=min(self.days_picker.values(), default=0),
                    paused=self.paused.isChecked(),
                    catch_up_hours=int(catchup),
                )
            )
            folder = self.destination.text().strip()
            if folder:
                filename = (
                    KNOWN[self.job.id][2]
                    if self.job.id in KNOWN
                    else self.output_name.text().strip()
                )
                if Path(filename).name != filename or "/" in filename or "\\" in filename:
                    raise ValueError("Informe somente o nome do arquivo, sem pastas.")
                if not filename:
                    raise ValueError(
                        "Extrator adicional exige um contrato de destino explícito em Configuração completa."
                    )
                value["target"] = str(Path(folder) / filename)
            source = script_path(value["script"])
            if not source.is_file() or source.suffix.casefold() != ".py":
                raise ValueError("Selecione um arquivo Python existente.")
            value["trusted_sha256"] = digest(source)
            candidate = to_dict(self.config)
            candidate["routines"] = [
                value if j["id"] == self.job.id else j for j in candidate["routines"]
            ]
            rows = sorted(candidate["routines"], key=lambda j: (j["order"], j["id"]))
            edited = next(j for j in rows if j["id"] == self.job.id)
            rows.remove(edited)
            rows.insert(self.order.currentIndex(), edited)
            for i, routine in enumerate(rows):
                routine["order"] = i
            self.result_config = from_dict(candidate)
            self.updated = self.result_config.job(self.job.id)
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "Configuração inválida", str(exc))


class InstallPage(QWizardPage):
    def __init__(self, title: str, validator: Callable[[], bool] | None = None):
        super().__init__()
        self.setTitle(title)
        self.validator = validator

    def validatePage(self) -> bool:
        return self.validator() if self.validator else True


class InstallWizard(QWizard):
    def __init__(
        self,
        paths: Paths,
        config: Config | None = None,
        parent: QWidget | None = None,
        installer: Installer | None = None,
    ):
        super().__init__(parent)
        self.paths = paths
        self.config = (
            copy.deepcopy(config) if config and config.test_mode else prepare_config(paths, config)
        )
        self.installer = installer or Installer(paths)
        self.installed = False
        self.install_task: Task | None = None
        self.changes: list[str] = []
        self.setWindowTitle("Orquestrador • Instalação de teste e atualização")
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        self.setButtonText(QWizard.WizardButton.NextButton, "Avançar")
        self.setButtonText(QWizard.WizardButton.BackButton, "Voltar")
        self.setButtonText(QWizard.WizardButton.CancelButton, "Cancelar")
        self.setButtonText(QWizard.WizardButton.FinishButton, "Abrir aplicativo")
        self.resize(900, 690)
        diagnostic = InstallPage("1. Diagnóstico prévio", self.initial_decision)
        layout = QVBoxLayout(diagnostic)
        current = read_json(self.installer.pointer) if self.installer.pointer.is_file() else {}
        text = f"Versão atual de teste: {current.get('version', 'não instalada')}\nNova versão: {VERSION}\nSistema: {sys.platform}\nRuntime: {'privado no executável' if getattr(sys, 'frozen', False) else 'modo de desenvolvimento'}\n\nEDIÇÃO DE TESTE ISOLADA\nEscolha uma pasta vazia. Aplicativo, perfil do Edge, relatórios, configurações e logs serão mantidos nessa pasta. A instalação original e suas tarefas permanecem preservadas. O versionamento usa snapshots e hashes internos. Falhas internas acionam reversão automática. Login e VPN são testes operacionais separados."
        label = QLabel(text)
        label.setWordWrap(True)
        layout.addWidget(label)
        self.operation = QComboBox()
        self.operation.addItems(
            ["Instalar/atualizar", "Reparar a instalação", "Abrir versão instalada"]
            if current
            else ["Instalar"]
        )
        layout.addWidget(self.operation)
        button("Copiar preferências da v1.3.0 para o teste…", self.import_legacy, layout)
        layout.addStretch()
        self.addPage(diagnostic)
        location = InstallPage("2. Pasta exclusiva da versão de teste", self.select_location)
        form = QFormLayout(location)
        suggestion = (
            paths.root
            if (paths.root / "instalacao-teste.json").is_file()
            else paths.root.parent / "Ambiente"
        )
        widget, self.install_root = path_field(str(suggestion))
        form.addRow("Pasta de teste", widget)
        form.addRow(
            QLabel(
                "Use uma pasta vazia ou uma instalação de teste reconhecida. Nenhum arquivo existente de outra instalação será substituído. É possível voltar ou cancelar antes de aplicar."
            )
        )
        self.addPage(location)
        who = InstallPage("3. Usuário, computador e OneDrive")
        form = QFormLayout(who)
        self.who = QLabel(json_view(identity()))
        self.who.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        form.addRow(self.who)
        self.email = QLineEdit(self.config.email)
        form.addRow("E-mail corporativo", self.email)
        self.accounts = QComboBox()
        self.accounts.addItem("Selecione explicitamente um destino ou use o seletor de pastas", "")
        for account in onedrives():
            self.accounts.addItem(
                f"{account['kind']} • {account['account']} • {account['path']}", account["path"]
            )
        form.addRow("Contas detectadas", self.accounts)
        form.addRow(
            QLabel(
                "Contas exibidas para identificação. Os destinos desta edição permanecem na pasta de teste."
            )
        )
        self.addPage(who)
        destinations = InstallPage("4. Destinos dos arquivos", self.validate_destinations)
        self.destination_form = QFormLayout(destinations)
        self.destination_fields: dict[str, QLineEdit] = {}
        self.build_destinations()
        self.addPage(destinations)
        routines = InstallPage("5. Rotinas, dependências e horários próprios")
        layout = QVBoxLayout(routines)
        layout.addWidget(
            QLabel(
                "Selecione uma rotina para editar frequência, dias, horários, ordem, dependências e retries."
            )
        )
        self.routine_table = QTableWidget(0, 4)
        self.routine_table.setHorizontalHeaderLabels(
            ["Rotina", "Habilitada", "Frequência", "Horários próprios"]
        )
        self.routine_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.routine_table.cellDoubleClicked.connect(lambda row, _: self.edit_job(row))
        layout.addWidget(self.routine_table)
        button(
            "Editar rotina selecionada",
            lambda: self.edit_job(self.routine_table.currentRow()),
            layout,
        )
        self.refresh_routines()
        self.schedule_install = QCheckBox(
            "Instalar monitor de teste no Agendador (agendamento inicialmente pausado)"
        )
        self.schedule_install.setChecked(self.config.install_schedules)
        layout.addWidget(self.schedule_install)
        self.addPage(routines)
        dependencies = InstallPage("6. Validação de dependências")
        layout = QVBoxLayout(dependencies)
        self.dependency_text = QPlainTextEdit()
        self.dependency_text.setReadOnly(True)
        layout.addWidget(self.dependency_text)
        self.dependency_text.setPlainText(
            json_view(
                {
                    name: importlib.metadata.version(name)
                    for name in ("PySide6", "selenium", "pandas", "openpyxl", "requests")
                }
            )
        )
        layout.addWidget(
            QLabel(
                "O health check de instalação valida somente recursos internos. Antes da primeira extração, use Diagnóstico para verificar Edge/assinatura e Testar login para renovar SSO/MFA."
            )
        )
        self.addPage(dependencies)
        review = InstallPage("7. Revisão das alterações", self.review_valid)
        layout = QVBoxLayout(review)
        self.review_text = QPlainTextEdit()
        self.review_text.setReadOnly(True)
        layout.addWidget(self.review_text)
        self.approve = QCheckBox(
            "Aplicar somente na pasta de teste e criar snapshots internos verificáveis"
        )
        layout.addWidget(self.approve)
        self.addPage(review)
        install = InstallPage("8. Instalação, atualização e verificação final")
        layout = QVBoxLayout(install)
        self.install_text = QPlainTextEdit()
        self.install_text.setReadOnly(True)
        self.install_bar = QProgressBar()
        self.install_bar.setRange(0, 0)
        layout.addWidget(self.install_bar)
        layout.addWidget(self.install_text)
        self.addPage(install)
        self.currentIdChanged.connect(self.page_changed)

    def select_location(self) -> bool:
        try:
            selected = check_location(Path(self.install_root.text().strip()))
            existing = selected.root
            while not existing.exists() and existing != existing.parent:
                existing = existing.parent
            check_directory(existing, min_free=500_000_000)
            if selected.root != self.paths.root:
                if selected.config.is_file():
                    self.config = load(selected)
                    from .sandbox import validate_isolation

                    validate_isolation(selected, self.config)
                else:
                    self.config = prepare_config(selected, self.config)
                self.paths = selected
                self.installer = Installer(selected)
                self.email.setText(self.config.email)
                self.schedule_install.setChecked(self.config.install_schedules)
                self.build_destinations()
                self.refresh_routines()
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Pasta de teste", str(exc))
            return False

    def initial_decision(self) -> bool:
        if self.operation.currentIndex() == 2:
            current = read_json(self.installer.pointer)
            spawn([current["executable"], "--data-root", str(self.paths.root)])
            self.reject()
            return False
        return True

    def build_destinations(self) -> None:
        while self.destination_form.count():
            item = self.destination_form.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.destination_fields.clear()
        for job in self.config.routines:
            widget, field = path_field(str(Path(job.target).parent) if job.target else "")
            self.destination_fields[job.id] = field
            self.destination_form.addRow(job.label, widget)
        self.destination_form.addRow(
            QLabel(
                "A gravação é local. A sincronização do OneDrive/SharePoint não é confirmada pelo aplicativo."
            )
        )

    def import_legacy(self) -> None:
        filename = QFileDialog.getOpenFileName(
            self, "Configuração da instalação existente", "", "JSON (*.json)"
        )[0]
        if not filename:
            return
        try:
            candidate, self.changes = migrate(Path(filename), self.paths, source_root())
            self.config = prepare_config(self.paths, candidate)
            self.changes.append(
                "Destinos, perfil, logs e downloads redirecionados ao teste; tarefas e estado de produção preservados."
            )
            self.email.setText(self.config.email)
            self.build_destinations()
            self.refresh_routines()
            show_detail(self, "Prévia da migração", self.changes)
        except Exception as exc:
            QMessageBox.warning(self, "Migração não aplicada", str(exc))

    def apply_base(self) -> None:
        folder = self.accounts.currentData()
        if not folder:
            QMessageBox.information(
                self, "Destino", "Selecione uma conta ou escolha cada pasta na próxima etapa."
            )
            return
        for job in self.config.routines:
            subfolder = KNOWN.get(job.id, ("", job.id, ""))[1]
            self.destination_fields[job.id].setText(str(Path(folder) / subfolder))

    def validate_destinations(self) -> bool:
        try:
            for job in self.config.routines:
                text = self.destination_fields[job.id].text().strip()
                if not job.enabled and not text:
                    continue
                if not text or not Path(text).is_absolute():
                    raise ValueError(f"Escolha a pasta de destino de {job.label}.")
                candidate = Path(text)
                confined(self.paths, candidate, f"Pasta de {job.label}")
                existing = candidate
                while not existing.exists() and existing != existing.parent:
                    existing = existing.parent
                check_directory(existing)
                filename = KNOWN.get(job.id, ("", "", Path(job.target).name))[2]
                job.target = str(candidate / filename) if filename else job.target
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Destino inválido", str(exc))
            return False

    def refresh_routines(self) -> None:
        self.routine_table.setRowCount(len(self.config.routines))
        for row, job in enumerate(self.config.routines):
            for column, value in enumerate(
                (
                    job.label,
                    "Sim" if job.enabled else "Não",
                    job.schedule.frequency,
                    ", ".join(job.schedule.times),
                )
            ):
                self.routine_table.setItem(row, column, QTableWidgetItem(value))

    def edit_job(self, row: int) -> None:
        if row < 0:
            return
        dialog = RoutineDialog(self.config, self.config.routines[row], self)
        if dialog.exec():
            self.config.routines[row] = dialog.updated
            self.refresh_routines()

    def review_valid(self) -> bool:
        try:
            if not self.approve.isChecked():
                raise ValueError("Revise e marque a aplicação das alterações para continuar.")
            self.config.email = self.email.text().strip()
            self.config.install_root = str(self.paths.root / "app")
            self.config.install_schedules = self.schedule_install.isChecked()
            if self.config.email and "@" not in self.config.email:
                raise ValueError("Informe um e-mail válido ou deixe vazio para testes locais.")
            validate(self.config)
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Revisão", str(exc))
            return False

    def page_changed(self, page: int) -> None:
        if page == 6:
            self.config.email = self.email.text().strip()
            self.config.install_root = str(self.paths.root / "app")
            self.config.install_schedules = self.schedule_install.isChecked()
            self.review_text.setPlainText(
                json_view(
                    {
                        "version": VERSION,
                        "pasta_exclusiva_do_teste": str(self.paths.root),
                        "versionamento": "interno: snapshots e SHA-256; sem Git",
                        "changes": self.changes,
                        "configuration": to_dict(self.config),
                    }
                )
            )
        if page == 7:
            self.button(QWizard.WizardButton.BackButton).setEnabled(False)
            self.button(QWizard.WizardButton.CancelButton).setEnabled(False)
            self.button(QWizard.WizardButton.FinishButton).setEnabled(False)
            task = Task(
                lambda: self.installer.install(
                    Path(sys.executable),
                    self.config,
                    progress=lambda message: task.progress.emit(message),
                ),
                self,
            )
            self.install_task = task
            task.progress.connect(self.install_text.appendPlainText)
            task.done.connect(self.install_done)
            task.failed.connect(self.install_failed)
            task.start()

    def install_done(self, result: Any) -> None:
        self.installed_executable = Path(result)
        mark(self.paths)
        remember(self.paths)
        self.installed = True
        self.install_bar.setRange(0, 1)
        self.install_bar.setValue(1)
        self.button(QWizard.WizardButton.FinishButton).setEnabled(True)
        self.install_text.appendPlainText(f"Versão instalada: {result}")

    def install_failed(self, error: str) -> None:
        self.install_bar.setRange(0, 1)
        self.install_bar.setValue(0)
        self.install_text.appendPlainText(
            error
            + "\nConsulte acima o resultado da reversão. A conversão não será marcada como instalada."
        )
        self.button(QWizard.WizardButton.CancelButton).setEnabled(True)

    def reject(self) -> None:
        if self.install_task and self.install_task.isRunning():
            return
        super().reject()

    def accept(self) -> None:
        if self.installed:
            super().accept()


class MainWindow(QMainWindow):
    def __init__(self, paths: Paths):
        super().__init__()
        self.paths = paths
        self.config = load(paths)
        install_translation(QApplication.instance(), self.config.language)
        self.store = Store(paths.database)
        self.engine = Engine(paths, self.config)
        self.setWindowIcon(icon())
        app = QApplication.instance()
        if isinstance(app, QApplication):
            apply_theme(app)
        self.task: Task | None = None
        self.update_task: Task | None = None
        self.exit_requested = False
        self._log_stamp: tuple[str, int, int] | None = None
        self._last_stage = ""
        self.setWindowTitle(
            f"CAIO • Teste {VERSION}" if self.config.test_mode else f"CAIO • {VERSION}"
        )
        self.resize(1400, 850)
        self.tabs = QTabWidget()
        self.activity = QWidget()
        self.activity_layout = QVBoxLayout(self.activity)
        self.activity_layout.setContentsMargins(12, 6, 12, 6)
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.addWidget(self.tabs)
        splitter.addWidget(self.activity)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)
        self.setCentralWidget(splitter)
        self.build_panel()
        self.build_routines()
        self.build_settings()
        self.build_history()
        self.build_maintenance()
        from .dev_gui import DevPanel

        self.dev_panel = DevPanel(paths, self)
        self.tabs.addTab(self.dev_panel, "Dev • Internos")
        if self.config.test_mode:
            banner = QLabel(f"TESTE ISOLADO • {self.paths.root}")
            banner.setToolTip(str(self.paths.root))
            banner.setMaximumWidth(750)
            self.statusBar().addPermanentWidget(banner)
        self.tray = QSystemTrayIcon(icon(), self)
        self.tray.setToolTip("CAIO • Orquestrador")
        menu = QMenu()
        show = QAction("Abrir Orquestrador", self)
        show.triggered.connect(self.show_application)
        menu.addAction(show)
        quit_action = QAction("Sair da interface", self)
        quit_action.triggered.connect(self.explicit_exit)
        menu.addAction(quit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(
            lambda reason: self.show_application()
            if reason
            in (
                QSystemTrayIcon.ActivationReason.Trigger,
                QSystemTrayIcon.ActivationReason.DoubleClick,
            )
            else None
        )
        self.last_notification_run = ""
        self.vpn_notices: list[VpnNotice] = []
        self.tray.messageClicked.connect(self.notification_detail)
        self.tray.show()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(2000)
        for table in self.findChildren(QTableWidget):
            configure_table(table)
        for label in self.findChildren(QLabel):
            label.setWordWrap(True)
        self.refresh()
        translate_tree(self)
        from .windows_identity import set_process_identity, set_window_identity

        set_process_identity(paths)
        if isinstance(app, QApplication) and app.platformName() == "windows":
            set_window_identity(self, paths)

    def build_panel(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        title = QLabel("CAIO • Acompanhamento das extrações")
        title.setStyleSheet("font-size:24px; font-weight:600; color:#00338D")
        brand = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(icon().pixmap(48, 48))
        brand.addWidget(logo)
        brand.addWidget(title)
        brand.addStretch()
        layout.addLayout(brand)
        self.timezone = QLabel()
        layout.addWidget(self.timezone)
        self.panel = QTableWidget(0, 11)
        self.panel.setHorizontalHeaderLabels(
            [
                "Rotina",
                "Habilitada",
                "Estado/etapa",
                "Última tentativa",
                "Último sucesso",
                "Dados",
                "Próxima execução",
                "Duração (s)",
                "Tentativas",
                "Pendência/ação",
                "Execução",
            ]
        )
        self.panel.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.panel.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.panel.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.panel)
        actions = QHBoxLayout()
        self.batch_group = QGroupBox(tr("Lote completo"))
        batch_actions = QHBoxLayout(self.batch_group)
        self.batch_button = button("Executar todas", lambda: self.start_run(), batch_actions)
        button("Simular todas", lambda: self.start_run(simulate=True), batch_actions)
        actions.addWidget(self.batch_group)
        self.selection_group = QGroupBox(tr("Escolha uma rotina"))
        selected_actions = QHBoxLayout(self.selection_group)
        self.run_button = button(
            "Executar rotina", lambda: self.start_run(selected=True), selected_actions
        )
        self.force_button = button(
            "Forçar rotina", lambda: self.start_run(selected=True, force=True), selected_actions
        )
        self.simulate_button = button(
            "Simular", lambda: self.start_run(selected=True, simulate=True), selected_actions
        )
        self.login_button = button(
            "Testar login", lambda: self.start_run(selected=True, login=True), selected_actions
        )
        actions.addWidget(self.selection_group)
        self.panel.itemSelectionChanged.connect(self.selection_actions)
        self.panel.setAlternatingRowColors(True)
        layout.addLayout(actions)
        controls = QHBoxLayout()
        self.pause_schedule = button("Pausar/retomar agendamento", self.toggle_schedule, controls)
        button("Pausar execução", lambda: self.control("pause"), controls)
        button("Retomar execução", lambda: self.control("resume"), controls)
        button("Cancelar rotina", lambda: self.control("cancel"), controls)
        button("Cancelar lote", lambda: self.control("cancel", batch=True), controls)
        layout.addLayout(controls)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.hide()
        self.activity_layout.addWidget(self.progress)
        self.status_label = QLabel("Pronto")
        self.status_label.setWordWrap(True)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText(
            tr("Atividade do aplicativo: operações, avisos e logs aparecem aqui.")
        )
        self.log.setMinimumHeight(160)
        self.log.document().setMaximumBlockCount(800)
        self.activity_layout.addWidget(self.log, 1)
        self.activity_layout.addWidget(self.status_label)
        self.tabs.addTab(page, "Painel")

    def build_routines(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.routines = QTableWidget(0, 6)
        self.routines.setHorizontalHeaderLabels(
            ["Rotina", "Frequência", "Horários próprios", "Dias", "Ordem", "Origem"]
        )
        self.routines.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        self.routines.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.routines.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.routines.setAlternatingRowColors(True)
        self.routines.cellDoubleClicked.connect(lambda row, _: self.edit_routine(row))
        layout.addWidget(self.routines)
        actions = QHBoxLayout()
        button("Editar selecionada", lambda: self.edit_routine(self.routines.currentRow()), actions)
        button("Descobrir extratores…", self.discover_jobs, actions)
        button("Cadastrar script…", self.register_script, actions)
        button("Versões do script…", self.script_history, actions)
        button("Excluir rotina…", self.delete_routine, actions)
        button("Publicar arquivo local…", self.local_file, actions)
        layout.addLayout(actions)
        layout.addWidget(
            QLabel(
                "Adicionar scripts: selecione um arquivo .py, revise os argumentos e habilite a rotina. Versões são guardadas automaticamente. Publicar arquivo local valida e copia um Excel já baixado (Eventos: mescla o histórico), sem abrir o navegador."
            )
        )
        self.queue_delay = QSpinBox()
        self.queue_delay.setRange(0, 3600)
        self.queue_delay.setSuffix(" s")
        self.queue_delay.setValue(self.config.queue_delay_seconds)
        delay_form = QFormLayout()
        delay_form.addRow("Espera entre rotinas agendadas na fila", self.queue_delay)
        button("Salvar intervalo", self.save_delay, delay_form)
        layout.addLayout(delay_form)
        layout.addWidget(
            explain(
                "O intervalo começa quando a rotina anterior termina. Não há execuções simultâneas no perfil compartilhado."
            )
        )
        self.tabs.addTab(page, "Rotinas e agendamentos")

    def build_settings(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        languages = QHBoxLayout()
        languages.addWidget(QLabel("Idioma / Language / Idioma"))
        self.language = QComboBox()
        for label, code in (("Português (Brasil)", "pt-BR"), ("English", "en"), ("Español", "es")):
            self.language.addItem(label, code)
        self.language.setCurrentIndex(self.language.findData(self.config.language))
        languages.addWidget(self.language)
        button("Aplicar idioma", self.change_language, languages)
        layout.addLayout(languages)
        self.settings_json = QPlainTextEdit(json_view(to_dict(self.config)))
        layout.addWidget(
            QLabel(
                "Configuração completa • campos de máquina, caminhos, URLs, histórico, retries, notificações e retenção. Use Editar rotina para os controles guiados."
            )
        )
        layout.addWidget(self.settings_json)
        actions = QHBoxLayout()
        button("Validar e salvar", self.save_settings, actions)
        button("Exportar preferências sem segredos…", self.export_settings, actions)
        button("Importar com prévia…", self.import_settings, actions)
        button("Atualização…", self.installation, actions)
        layout.addLayout(actions)
        paths_form = QFormLayout()
        self.path_key = QComboBox()
        for key in ("profile", "driver", "downloads", "logs", "install_root"):
            self.path_key.addItem(key)
        paths_form.addRow("Selecionar caminho", self.path_key)
        layout.addWidget(
            explain(
                "O EdgeDriver é localizado e reparado automaticamente. Ao escolher um driver externo, ele será validado e copiado para o cache gerenciado; o arquivo original será preservado."
            )
        )
        button("Escolher e aplicar caminho…", self.choose_setting_path, paths_form)
        layout.addLayout(paths_form)
        layout.addWidget(
            QLabel(
                "Console oculto refere-se a subprocessos internos. Minimizar mantém a interface. Headless controla somente a janela do navegador. SSO/MFA não é convertido em serviço Windows."
            )
        )
        self.tabs.addTab(page, "Configurações")

    def build_history(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        filters = QHBoxLayout()
        self.filter_job = QLineEdit()
        self.filter_job.setPlaceholderText("ID da rotina; vazio = todas")
        self.filter_status = QComboBox()
        self.filter_status.addItem("Todos", "")
        for code, label in STATUS.items():
            self.filter_status.addItem(label, code)
        filters.addWidget(self.filter_job)
        filters.addWidget(self.filter_status)
        button("Filtrar", self.refresh_history, filters)
        button("Exportar diagnóstico sanitizado…", self.export_history, filters)
        layout.addLayout(filters)
        self.history = QTableWidget(0, 8)
        self.history.setHorizontalHeaderLabels(
            ["Início", "Rotina", "Estado", "Modo", "Categoria", "Lote", "Execução", "Etapa"]
        )
        self.history.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        self.history.cellDoubleClicked.connect(lambda row, _: self.history_detail(row))
        layout.addWidget(self.history)
        self.tabs.addTab(page, "Histórico e logs")

    def build_maintenance(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        targets = QHBoxLayout()
        targets.addWidget(QLabel(tr("Destino do teste de conectividade/VPN")))
        self.connectivity_job = QComboBox()
        for job in self.config.routines:
            if job.requires_browser:
                self.connectivity_job.addItem(job.label, job.id)
        index = self.connectivity_job.findData("kwms_alocacoes_tool_edge")
        if index >= 0:
            self.connectivity_job.setCurrentIndex(index)
        targets.addWidget(self.connectivity_job)
        layout.addLayout(targets)
        actions = QHBoxLayout()
        button(
            "Diagnosticar EdgeDriver",
            lambda: self.driver_operation(False),
            actions,
        )
        button(
            "Reparar EdgeDriver",
            lambda: self.driver_operation(True),
            actions,
        )
        button("Testar conectividade", self.connectivity, actions)
        layout.addLayout(actions)
        tasks = QHBoxLayout()
        button("Conferir tarefas", self.task_diff, tasks)
        button("Instalar/atualizar tarefa", self.install_task, tasks)
        button(
            "Remover tarefa própria",
            lambda: self.manage_task(False),
            tasks,
        )
        layout.addLayout(tasks)
        self.tasks_view = QTableWidget(0, 4)
        self.tasks_view.setHorizontalHeaderLabels(["Campo", "No Windows", "Esperado", "Resultado"])
        self.tasks_view.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tasks_view.setMaximumHeight(220)
        layout.addWidget(self.tasks_view)
        layout.addWidget(
            explain(
                "Conferir tarefas compara o monitor registrado com esta instalação. A lista abaixo contém backups de relatórios, não resultados do diagnóstico."
            )
        )
        layout.addWidget(
            QLabel(
                "Backups de relatórios • restaurar preserva a versão atual e não registra nova extração."
            )
        )
        self.backups = QTableWidget(0, 5)
        self.backups.setHorizontalHeaderLabels(["Data", "Arquivo", "Tamanho", "SHA-256", "Versão"])
        self.backups.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        layout.addWidget(self.backups)
        self.backup_empty = explain(
            "Nenhum backup de relatório ainda. A lista é preenchida após a primeira substituição de um arquivo válido."
        )
        layout.addWidget(self.backup_empty)
        controls = QHBoxLayout()
        button("Atualizar lista", self.refresh_backups, controls)
        button("Validar selecionado", self.validate_backup, controls)
        button("Restaurar selecionado", self.restore_backup, controls)
        button("Backup do aplicativo", self.backup_application, controls)
        button("Reverter atualização…", self.rollback_application, controls)
        layout.addLayout(controls)
        button("Desinstalar componentes próprios e preservar dados…", self.uninstall, layout)
        self.tabs.addTab(page, "Diagnóstico e manutenção")

    def selected_ids(self) -> list[str]:
        names = []
        for index in self.panel.selectionModel().selectedRows():
            item = self.panel.item(index.row(), 0)
            if item is not None:
                names.append(str(item.data(Qt.ItemDataRole.UserRole)))
        return names

    def selection_actions(self) -> None:
        count = len(self.selected_ids())
        self.batch_group.setVisible(count == 0)
        self.selection_group.setTitle(
            tr(
                "Lote selecionado"
                if count > 1
                else "Rotina selecionada"
                if count == 1
                else "Escolha uma rotina"
            )
        )
        self.simulate_button.setEnabled(count > 0)
        self.batch_button.setVisible(count == 0)
        self.run_button.setText(tr("Executar lote selecionado" if count > 1 else "Executar rotina"))
        self.force_button.setText(tr("Forçar lote selecionado" if count > 1 else "Forçar rotina"))
        self.login_button.setVisible(count <= 1)
        self.login_button.setEnabled(count == 1)
        self.run_button.setEnabled(count > 0)
        self.force_button.setEnabled(count > 0)

    def save_delay(self) -> None:
        try:
            config = load(self.paths)
            config.queue_delay_seconds = self.queue_delay.value()
            self.write_config(config)
            self.status_label.setText(tr("Intervalo salvo."))
        except Exception as exc:
            self.task_error(str(exc))

    def change_language(self) -> None:
        if self.task and self.task.isRunning():
            self.task_error(tr("Aguarde a operação atual antes de trocar o idioma."))
            return
        try:
            config = load(self.paths)
            config.language = self.language.currentData()
            self.write_config(config)
            install_translation(QApplication.instance(), config.language)
            # Rebuild presentation only; the DB, tasks, profiles and scripts stay untouched.
            self.timer.stop()
            self.dev_panel.shutdown()
            self.tray.hide()
            self.replacement = MainWindow(self.paths)
            self.replacement.tabs.setCurrentIndex(2)
            self.replacement.show()
            setattr(QApplication.instance(), "_caio_window", self.replacement)
            self.hide()
            self.deleteLater()
        except Exception as exc:
            self.task_error(str(exc))

    def delete_routine(self) -> None:
        row = self.routines.currentRow()
        if row < 0:
            return
        config = load(self.paths)
        job = config.routines[row]
        box = QMessageBox(self)
        box.setWindowTitle(tr("Excluir rotina"))
        box.setText(tr("Retirar esta rotina do programa?") + "\n" + job.label)
        box.setInformativeText(
            tr(
                "Por padrão, o histórico e as versões do script ficam guardados. O arquivo original e os relatórios nunca são apagados."
            )
        )
        purge = QCheckBox(tr("Apagar também as cópias e versões gerenciadas deste script"))
        box.setCheckBox(purge)
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.No)
        if box.exec() != QMessageBox.StandardButton.Yes:
            return
        try:
            from .script_versions import remove

            remove(self.paths, config, job.id, purge.isChecked())
            self.config = config
            self.refresh()
        except Exception as exc:
            self.task_error(str(exc))

    def script_history(self) -> None:
        row = self.routines.currentRow()
        if row < 0:
            return
        try:
            from .script_versions import capture, restore, versions

            config = load(self.paths)
            job = config.routines[row]
            capture(self.paths, job)
            records = versions(self.paths, job)
            dialog = QDialog(self)
            dialog.setWindowTitle(tr("Versões do script") + " • " + job.label)
            dialog.resize(850, 430)
            layout = QVBoxLayout(dialog)
            layout.addWidget(
                explain(
                    "Snapshots automáticos ao salvar e executar. Restaurar cria uma cópia gerenciada, sem sobrescrever o script original. Dependências Python e arquivos auxiliares continuam sendo responsabilidade do script."
                )
            )
            table = QTableWidget(len(records), 4)
            table.setHorizontalHeaderLabels([tr("Data"), tr("Versão"), "SHA-256", tr("Origem")])
            table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
            table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
            for i, record in enumerate(records):
                for j, key in enumerate(("at", "version", "sha256", "source")):
                    set_cell(table, i, j, record[key])
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
            layout.addWidget(table)

            def rollback() -> None:
                index = table.currentRow()
                if index < 0:
                    return
                if (
                    QMessageBox.question(
                        dialog,
                        tr("Restaurar script"),
                        tr(
                            "Ativar a versão selecionada? O histórico de execuções será preservado."
                        ),
                    )
                    != QMessageBox.StandardButton.Yes
                ):
                    return
                try:
                    restore(self.paths, config, job, records[index]["sha256"])
                    dialog.accept()
                    self.refresh()
                except Exception as exc:
                    QMessageBox.warning(dialog, tr("Restauração"), str(exc))

            button("Restaurar versão selecionada", rollback, layout)
            dialog.exec()
        except Exception as exc:
            self.task_error(str(exc))

    def driver_operation(self, repair: bool) -> None:
        def operation() -> Any:
            with Lock(self.paths.lock):
                return diagnose(self.paths, load(self.paths), repair=repair)

        self.background(operation)

    @staticmethod
    def task_report(value: dict[str, Any]) -> str:
        import xml.etree.ElementTree as ET

        from .tasks import NS

        lines = [
            tr("Tarefa instalada") + ": " + tr("Sim" if value["installed"] else "Não"),
            tr("Configuração corresponde") + ": " + tr("Sim" if value["matches"] else "Não"),
        ]
        for label, key in (("Efetiva", "actual"), ("Esperada", "expected")):
            if not value.get(key):
                continue
            root = ET.fromstring(value[key])
            lines.append("\n" + tr(label))
            for name, path in (
                ("Programa", "Actions/Exec/Command"),
                ("Argumentos", "Actions/Exec/Arguments"),
                ("Usuário", "Principals/Principal/UserId"),
                ("Sessão", "Principals/Principal/LogonType"),
                ("Intervalo do monitor", "Triggers/CalendarTrigger/Repetition/Interval"),
                ("Habilitada", "Settings/Enabled"),
            ):
                lines.append(
                    tr(name)
                    + ": "
                    + str(
                        root.findtext("/".join("{" + NS + "}" + p for p in path.split("/"))) or "—"
                    )
                )
        return "\n".join(lines)

    def selected_id(self) -> str:
        row = self.panel.currentRow()
        item = self.panel.item(row, 0)
        if row < 0 or item is None:
            raise ValueError("Selecione uma rotina no Painel.")
        return str(item.data(Qt.ItemDataRole.UserRole))

    def background(self, callback: Callable[[], Any], details: bool = False) -> None:
        if self.task and self.task.isRunning():
            QMessageBox.information(
                self, "Operação em andamento", "Acompanhe a operação atual antes de iniciar outra."
            )
            return
        self.status_label.setText(tr("Processando… acompanhe o log acima."))
        self.log.appendPlainText(tr("Operação iniciada."))
        self.set_status(tr("Processando… acompanhe o log acima."), "active")
        self.progress.setRange(0, 0)
        self.progress.show()
        self.task = Task(callback, self)
        self.task.progress.connect(lambda text: self.log.appendPlainText(tr(text)))
        self.task.done.connect(lambda value: self.task_done(value, details))
        self.task.failed.connect(lambda error: self.task_error(error))
        self.task.start()

    def task_done(self, value: Any, details: bool) -> None:
        self.refresh()
        self.settings_json.setPlainText(json_view(to_dict(load(self.paths))))
        self.progress.hide()
        self.set_status(tr("Etapa anterior concluída com sucesso."), "success")
        if isinstance(value, dict) and "expected" in value and "installed" in value:
            self.render_task_report(value)
            value = self.task_report(value)
        self.log.appendPlainText(
            value
            if isinstance(value, str)
            else json_view(value)
            if value is not None
            else tr("Etapa anterior concluída com sucesso.")
        )
        if isinstance(value, list) and any(
            r.get("status") in {"failed", "skipped", "cancelled", "blocked_dependency"}
            for r in value
            if isinstance(r, dict)
        ):
            self.set_status(tr("Execução com pendências. Consulte o log e o histórico."), "warning")
            QApplication.alert(self)
        if (
            isinstance(value, list)
            and value
            and all(
                isinstance(row, dict) and row.get("status") in {"ignored", "not_eligible"}
                for row in value
            )
        ):
            self.set_status(
                tr(
                    "Nenhuma rotina executada. Consulte os motivos no log; Forçar permite repetir uma atualização já concluída."
                ),
                "warning",
            )
        if details:
            show_detail(self, "Resultado da operação", value)

    def task_error(self, error: str) -> None:
        self.progress.hide()
        self.log.appendPlainText(error)
        self.set_status(error, "error")
        QApplication.alert(self, 15000)
        QMessageBox.warning(self, "Operação não concluída", error)
        self.refresh()

    def set_status(self, text: str, severity: str = "") -> None:
        self.status_label.setText(text)
        self.status_label.setProperty("severity", severity)
        self.status_label.style().unpolish(self.status_label)
        self.status_label.style().polish(self.status_label)

    def show_application(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def start_run(self, selected: bool = False, **options: Any) -> None:
        try:
            names = self.selected_ids() if selected else None
            if selected and not names:
                raise ValueError("Selecione uma ou mais rotinas no Painel.")
            self.background(
                lambda: Engine(self.paths).run(names, **options),
                details=options.get("simulate", False),
            )
        except Exception as exc:
            self.task_error(str(exc))

    def control(self, value: str, batch: bool = False) -> None:
        active = [r for r in self.store.history() if r["status"] == "running"]
        selected = set(self.selected_ids())
        active = [run for run in active if batch or run["job"] in selected]
        if not active:
            self.set_status(
                tr("Selecione uma rotina em execução para aplicar esta ação."), "warning"
            )
            return
        for run in active:
            self.store.control(run["id"], value)
            if value == "cancel" and batch:
                self.store.control("batch:" + run["batch"], "cancel")
        self.status_label.setText(
            {
                "pause": "Pausa solicitada: será aplicada no próximo checkpoint seguro; publicações não são suspensas.",
                "resume": "Retomada solicitada: pré-condições serão verificadas no checkpoint.",
                "cancel": "Cancelamento solicitado; subprocessos próprios serão encerrados após o prazo cooperativo.",
            }[value]
        )

    def write_config(self, config: Config) -> None:
        if self.config.test_mode and not config.test_mode:
            raise ValueError("O modo de teste isolado não pode ser desativado nesta instalação.")
        with Lock(self.paths.maintenance_lock), Lock(self.paths.root / "state/config.lock"):
            save(self.paths, config)
        self.config = config
        self.settings_json.setPlainText(json_view(to_dict(config)))

    def toggle_schedule(self) -> None:
        config = load(self.paths)
        config.scheduling_paused = not config.scheduling_paused
        self.write_config(config)
        self.refresh()

    def edit_routine(self, row: int) -> None:
        if row < 0:
            return
        config = load(self.paths)
        dialog = RoutineDialog(config, config.routines[row], self)
        if dialog.exec():
            from .script_versions import capture

            try:
                with Lock(self.paths.lock):
                    if script_path(config.routines[row].script).is_file():
                        capture(self.paths, config.routines[row])
                    capture(self.paths, dialog.updated)
                    self.write_config(dialog.result_config)
                self.refresh()
                self.set_status(tr("Etapa anterior concluída com sucesso."), "success")
            except Exception as exc:
                self.task_error(str(exc))

    def save_settings(self) -> None:
        try:
            candidate = from_dict(json.loads(self.settings_json.toPlainText()))
            self.write_config(candidate)
            self.refresh()
        except Exception as exc:
            self.task_error(str(exc))

    def choose_setting_path(self) -> None:
        key = self.path_key.currentText()
        value = (
            QFileDialog.getOpenFileName(
                self, "Selecionar executável do driver", "", "Executáveis (*.exe)"
            )[0]
            if key == "driver"
            else QFileDialog.getExistingDirectory(self, "Selecionar pasta")
        )
        if value:
            data = json.loads(self.settings_json.toPlainText())
            if key == "driver":
                options = data.setdefault("driver_options", {})
                options["search_paths"] = list(
                    dict.fromkeys([value, *options.get("search_paths", [])])
                )
                self.write_config(from_dict(data))
                self.driver_operation(True)
                return
            data[key] = value
            self.settings_json.setPlainText(json_view(data))

    def export_settings(self) -> None:
        filename = QFileDialog.getSaveFileName(
            self, "Exportar preferências", "preferencias.json", "JSON (*.json)"
        )[0]
        if filename:
            atomic_json(Path(filename), portable(load(self.paths)))

    def import_settings(self) -> None:
        filename = QFileDialog.getOpenFileName(self, "Importar preferências", "", "JSON (*.json)")[
            0
        ]
        if not filename:
            return
        try:
            candidate, changes = import_preview(load(self.paths), read_json(Path(filename)))
            show_detail(self, "Prévia das alterações", changes)
            if (
                QMessageBox.question(self, "Aplicar importação", "Aplicar as alterações exibidas?")
                == QMessageBox.StandardButton.Yes
            ):
                self.write_config(candidate)
        except Exception as exc:
            self.task_error(str(exc))

    def discover_jobs(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Localizar extratores adicionais")
        if folder:
            config = load(self.paths)
            additions = discover(config, Path(folder))
            show_detail(
                self,
                "Extratores encontrados; revise e habilite para executar",
                [dataclasses.asdict(j) for j in additions],
            )
            config.routines.extend(additions)
            self.write_config(config)

    def register_script(self) -> None:
        filename = QFileDialog.getOpenFileName(
            self, "Cadastrar extrator Python", "", "Python (*.py)"
        )[0]
        if filename:
            config = load(self.paths)
            script = Path(filename)
            job = Routine(
                id=script_identifier(script),
                label=script.stem,
                script=str(script),
                enabled=False,
                origin="cadastro manual explícito",
                order=max((j.order for j in config.routines), default=-1) + 1,
                command="",
                requires_browser=False,
            )
            config.routines.append(job)
            dialog = RoutineDialog(config, job, self)
            if dialog.exec():
                from .script_versions import capture

                capture(self.paths, dialog.updated)
                self.write_config(dialog.result_config)
                self.refresh()

    def local_file(self) -> None:
        try:
            row = self.routines.currentRow()
            if row < 0:
                raise ValueError("Selecione uma rotina nesta tabela.")
            name = self.config.routines[row].id
            if name not in {
                "pipefy_clientes_tool_edge",
                "pipefy_eventos_tool_edge",
                "pipefy_procedimentos_tool_edge",
                "pipefy_status_atms_tool_edge",
            }:
                raise ValueError(
                    "Publicação local disponível para Clientes, Eventos, Procedimentos e ATMS."
                )
            filename = QFileDialog.getOpenFileName(
                self, "Publicar/mesclar arquivo local", "", "Excel (*.xlsx)"
            )[0]
            if filename:
                self.background(lambda: Engine(self.paths).run([name], source=Path(filename)))
        except Exception as exc:
            self.task_error(str(exc))

    def refresh_history(self) -> None:
        rows = self.store.history(
            job=self.filter_job.text().strip(), status=self.filter_status.currentData()
        )
        self.history.setRowCount(len(rows))
        for index, row in enumerate(rows):
            for column, key in enumerate(
                ("started", "job", "status", "mode", "category", "batch", "id", "stage")
            ):
                set_cell(self.history, index, column, row.get(key) or "")

    def history_detail(self, row: int) -> None:
        if row >= 0:
            item = self.history.item(row, 6)
            if item is None:
                return
            run = item.text()
            show_detail(self, "Detalhes locais da execução", self.store.details(run))

    def export_history(self) -> None:
        filename = QFileDialog.getSaveFileName(
            self,
            "Exportar diagnóstico sem endpoints/segredos",
            "diagnostico.xlsx",
            "Excel (*.xlsx);;JSON (*.json)",
        )[0]
        if filename:
            self.background(lambda: self.store.export(Path(filename)))

    def refresh_backups(self) -> None:
        publisher = Publisher(self.paths.root / "backups/reports", self.config.retention)
        records = publisher.versions()
        self.backups.setRowCount(len(records))
        self.backup_empty.setVisible(not records)
        for row, record in enumerate(records):
            for column, key in enumerate(("at", "target", "size", "sha256", "id")):
                set_cell(self.backups, row, column, record[key])

    def selected_backup(self) -> str:
        row = self.backups.currentRow()
        if row < 0:
            raise ValueError("Selecione uma versão de relatório.")
        item = self.backups.item(row, 4)
        if item is None:
            raise ValueError("Versão inválida.")
        return item.text()

    def validate_backup(self) -> None:
        try:
            identifier = self.selected_backup()
            publisher = Publisher(self.paths.root / "backups/reports", self.config.retention)
            record = next(r for r in publisher.versions() if r["id"] == identifier)
            self.background(lambda: {"valid": str(publisher.validate_version(record))})
        except Exception as exc:
            self.task_error(str(exc))

    def restore_backup(self) -> None:
        try:
            identifier = self.selected_backup()
            if (
                QMessageBox.question(
                    self,
                    "Restaurar relatório",
                    "Restaurar esta versão, criando antes um backup do arquivo atual?",
                )
                != QMessageBox.StandardButton.Yes
            ):
                return

            def restore() -> Any:
                with Lock(self.paths.lock):
                    run = self.store.begin("restore", "report", "restore", None)
                    try:
                        result = Publisher(
                            self.paths.root / "backups/reports", self.config.retention
                        ).restore(identifier, run)
                        self.store.event(run, "restore", result)
                        self.store.finish(run, "success", 0)
                        return result
                    except Exception as exc:
                        self.store.finish(run, "failed", 1, evidence=str(exc))
                        raise

            self.background(restore)
        except Exception as exc:
            self.task_error(str(exc))

    def installation(self) -> None:
        if self.task and self.task.isRunning():
            self.task_error("Encerre a execução antes de atualizar o aplicativo.")
            return
        from .native_updates import is_native

        if is_native(self.paths):
            from .native_gui import preferences

            preferences(self)
            return
        wizard = InstallWizard(self.paths, load(self.paths), self)
        if wizard.exec():
            if wizard.paths.root != self.paths.root:
                spawn([str(wizard.installed_executable), "--data-root", str(wizard.paths.root)])
                return
            self.config = load(self.paths)

    def connectivity(self) -> None:
        try:
            job_id = self.connectivity_job.currentData()
            if not job_id:
                raise ValueError("Cadastre uma rotina de navegador para testar conectividade.")
            job = load(self.paths).job(job_id)
            if job.id not in KNOWN and not job.url:
                raise ValueError("Informe a URL da rotina para testar conectividade.")
            module = module_for(job) if job.id in KNOWN else None
            url = (
                job.url
                or getattr(module, "LOGIN_URL", "")
                or getattr(module, "DEFAULT_REPORT_URL", "")
                or getattr(module, "DEFAULT_DATABASE_URL", "")
            )

            def test() -> Any:
                if job.id == "kwms_alocacoes_tool_edge":
                    from .connectivity import kwms_diagnostic

                    return kwms_diagnostic(
                        self.paths, self.config, job, module, url, public_pipefy(self.config)
                    )
                evidence = probe(url, public_pipefy(self.config), self.config.vpn_interfaces)
                category = classify(evidence)
                return {
                    "category": category,
                    "evidence": as_dict(evidence),
                    "vpn": "confirmada"
                    if category == "vpn"
                    else "inconclusiva"
                    if category == "inconclusive"
                    else category,
                    "method": "Mesma sonda de rede do adaptador KWMS: destino, conexão pública e interfaces VPN. Resposta vazia isolada não confirma VPN.",
                }

            def locked_test() -> Any:
                with Lock(self.paths.lock):
                    return test()

            self.background(locked_test)
        except Exception as exc:
            self.task_error(str(exc))

    def installed_executable(self) -> Path:
        pointer = self.paths.root / "installation.json"
        if not pointer.is_file():
            raise ValueError("Instale o executável pelo wizard antes de gerenciar tarefas reais.")
        current = read_json(pointer)
        return Path(current.get("launcher", current["executable"]))

    def task_diff(self) -> None:
        try:
            executable = self.installed_executable()
            self.background(
                lambda: WindowsTasks(self.paths).differences(executable, current_user())
            )
        except Exception as exc:
            self.task_error(str(exc))

    def install_task(self) -> None:
        self.manage_task(True)

    def manage_task(self, install: bool) -> None:
        def operation() -> Any:
            tasks = WindowsTasks(self.paths)
            executable = self.installed_executable()
            if install:
                result = tasks.install(executable, current_user())
            else:
                result = tasks.remove()
            with Lock(self.paths.maintenance_lock), Lock(self.paths.root / "state/config.lock"):
                config = load(self.paths)
                config.install_schedules = install
                save(self.paths, config)
            return {**result, **tasks.differences(executable, current_user())}

        self.background(operation)

    def render_task_report(self, value: dict[str, Any]) -> None:
        import xml.etree.ElementTree as ET

        from .tasks import NS

        fields = [
            ("Programa", "Actions/Exec/Command"),
            ("Argumentos", "Actions/Exec/Arguments"),
            ("Usuário", "Principals/Principal/UserId"),
            ("Sessão", "Principals/Principal/LogonType"),
            ("Intervalo do monitor", "Triggers/CalendarTrigger/Repetition/Interval"),
            ("Habilitada", "Settings/Enabled"),
        ]
        self.tasks_view.setRowCount(len(fields))
        trees = {
            key: ET.fromstring(value[key]) if value.get(key) else None
            for key in ("actual", "expected")
        }
        for row, (label, path) in enumerate(fields):
            key = "/".join("{" + NS + "}" + part for part in path.split("/"))
            actual = (
                trees["actual"].findtext(key, "—")
                if trees["actual"] is not None
                else tr("Não instalada")
            )
            expected = (
                trees["expected"].findtext(key, "—") if trees["expected"] is not None else "—"
            )
            for column, content in enumerate(
                (label, actual, expected, "OK" if actual == expected else tr("Revisar"))
            ):
                set_cell(self.tasks_view, row, column, content)

    def backup_application(self) -> None:
        def backup() -> Any:
            with Lock(self.paths.lock):
                folder = (
                    self.paths.root
                    / "backups/app"
                    / ("manual-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
                )
                from .native_install import installer_for

                return installer_for(self.paths).snapshot(folder)

        self.background(backup)

    def rollback_application(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Selecionar backup de aplicativo", str(self.paths.root / "backups/app")
        )
        if (
            folder
            and QMessageBox.question(
                self,
                "Reverter aplicativo",
                "Restaurar versão, configuração, estado e tarefa deste backup? A configuração atual será preservada em outro backup.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            from .native_updates import is_native

            if is_native(self.paths):
                from .native_gui import handoff

                handoff(self, backup=Path(folder))
            else:
                self.background(lambda: Installer(self.paths).rollback(Path(folder)))

    def uninstall(self) -> None:
        if (
            QMessageBox.question(
                self,
                "Desinstalar",
                "Remover somente tarefa e atalho próprios? Dados, histórico e backups serão preservados.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            from .native_install import installer_for

            self.background(lambda: installer_for(self.paths).uninstall())

    def refresh(self) -> None:
        try:
            with Lock(self.paths.maintenance_lock):
                self.refresh_unlocked()
            from .native_updates import is_native

            if is_native(self.paths):
                from .native_gui import check_automatically

                check_automatically(self)
        except BusyError:
            self.status_label.setText(
                "Instalação/manutenção em andamento; aguardando liberação dos dados."
            )

    def refresh_unlocked(self) -> None:
        try:
            request = self.paths.root / "state/open-interface.json"
            if request.is_file():
                requested = read_json(request)
                request.unlink()
                self.show_application()
                if requested.get("run"):
                    show_detail(
                        self, tr("Detalhe da execução"), self.store.details(requested["run"])
                    )
            self.config = load(self.paths)
            self.pause_schedule.setText(
                tr("Retomar agendamento" if self.config.scheduling_paused else "Pausar agendamento")
            )
            choices = [(job.label, job.id) for job in self.config.routines if job.requires_browser]
            if [
                self.connectivity_job.itemData(i) for i in range(self.connectivity_job.count())
            ] != [job for _, job in choices]:
                current = self.connectivity_job.currentData()
                self.connectivity_job.clear()
                for label, identifier in choices:
                    self.connectivity_job.addItem(label, identifier)
                index = self.connectivity_job.findData(current or "kwms_alocacoes_tool_edge")
                if index >= 0:
                    self.connectivity_job.setCurrentIndex(index)
            self.engine.config = self.config
            rows = self.engine.panel()
            self.panel.setRowCount(len(rows))
            active = False
            for row, record in enumerate(rows):
                last = record["last"]
                running = last.get("status") == "running"
                active |= running
                success = record["last_success"]
                error = last.get("category") or ""
                error = {
                    "driver": "Repare o EdgeDriver em Diagnóstico e manutenção.",
                    "authentication": "Use Testar login para autenticar a sessão.",
                    "vpn": "Verifique a VPN; a rotina permanece pendente.",
                    "internet": "Verifique as conexões de rede necessárias.",
                    "locked_file": "Feche o arquivo no Excel e tente novamente.",
                }.get(error, error)
                values = [
                    record["label"],
                    "Sim" if record["enabled"] else "Não",
                    last.get("stage") if running else STATUS.get(last.get("status"), "Pronta"),
                    last.get("started", "Nunca"),
                    success["at"] if success else "Nunca",
                    record["freshness"]
                    + ("\n" + record["data_updated"] if record["data_updated"] else ""),
                    record["next"]
                    or (tr("Desabilitada") if not record["enabled"] else tr("Agendamento pausado")),
                    last.get("duration") or "",
                    last.get("attempt", ""),
                    error,
                    last.get("id", ""),
                ]
                for column, value in enumerate(values):
                    set_cell(self.panel, row, column, value, record["id"] if column == 0 else None)
            busy = active or bool(self.task and self.task.isRunning())
            self.progress.setVisible(busy)
            self.progress.setRange(0, 0 if busy else 1)
            self.timezone.setText(
                tr("Fuso local")
                + f": {local_now().tzinfo} • "
                + tr("Agendamento")
                + ": "
                + tr("pausado" if self.config.scheduling_paused else "ativo")
                + " • "
                + tr(
                    "Monitor configurado"
                    if self.config.install_schedules
                    else "Sem monitor: instale a tarefa para executar horários automaticamente"
                )
            )
            self.routines.setRowCount(len(self.config.routines))
            for row, job in enumerate(self.config.routines):
                for column, value in enumerate(
                    (
                        job.label,
                        job.schedule.frequency,
                        ", ".join(job.schedule.times),
                        ", ".join(tr(DAYS[d])[:3] for d in job.schedule.days),
                        str(job.order),
                        job.origin,
                    )
                ):
                    set_cell(self.routines, row, column, value)
            if self.tabs.currentIndex() == 3:
                self.refresh_history()
            if self.tabs.currentIndex() == 4:
                self.refresh_backups()
            self.deliver_notifications()
            row = self.panel.currentRow()
            if row < 0 and active:
                row = next(
                    (i for i, r in enumerate(rows) if r["last"].get("status") == "running"), -1
                )
            if row >= 0:
                log_item = self.panel.item(row, 10)
                log_path = (
                    Path(self.config.logs) / (log_item.text() + ".process.log")
                    if log_item and log_item.text()
                    else None
                )
                if log_path and log_path.is_file():
                    stat = log_path.stat()
                    stamp = (str(log_path), stat.st_mtime_ns, stat.st_size)
                    if stamp != self._log_stamp:
                        self._log_stamp = stamp
                        with log_path.open("rb") as stream:
                            stream.seek(max(0, stat.st_size - 12000))
                            text = stream.read().decode("utf-8", errors="replace")
                        if text:
                            self.log.setPlainText(text)
                            self.log.verticalScrollBar().setValue(
                                self.log.verticalScrollBar().maximum()
                            )
            running_stages = [
                r["label"] + ": " + str(r["last"].get("stage", ""))
                for r in rows
                if r["last"].get("status") == "running"
            ]
            stage = " | ".join(running_stages)
            if stage and stage != self._last_stage:
                self.log.appendPlainText(stage)
                self.status_label.setText(stage)
            self._last_stage = stage
            self.selection_actions()
        except Exception as exc:
            self.status_label.setText(str(exc))

    def deliver_notifications(self) -> None:
        with self.store.connect() as db:
            rows = list(
                db.execute("SELECT * FROM notifications WHERE delivered=0 ORDER BY at LIMIT 2")
            )
            for row in rows:
                claimed = db.execute(
                    "UPDATE notifications SET delivered=1 WHERE id=? AND delivered=0", (row["id"],)
                )
                if not claimed.rowcount:
                    continue
                self.last_notification_run = row["run"] or ""
                from .notifications import show

                show(self.tray, row["message"])
                if row["kind"] == "vpn":
                    QApplication.alert(self, 15000)
                    self.vpn_notices.append(VpnNotice(self.store, row["run"], row["message"], self))

    def notification_detail(self) -> None:
        self.show_application()
        if self.last_notification_run:
            show_detail(self, "Detalhe da execução", self.store.details(self.last_notification_run))

    def explicit_exit(self) -> None:
        if (
            (self.task and self.task.isRunning())
            or (self.update_task and self.update_task.isRunning())
            or (self.dev_panel.task and self.dev_panel.task.isRunning())
            or any(r["status"] == "running" for r in self.store.history())
        ):
            QMessageBox.information(
                self,
                "Execução em andamento",
                "Use Cancelar e aguarde o encerramento controlado, ou minimize para manter a execução.",
            )
            self.hide()
            return
        self.exit_requested = True
        self.close()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.exit_requested:
            self.timer.stop()
            self.dev_panel.shutdown()
            self.tray.hide()
            event.accept()
            QApplication.quit()
            return
        self.hide()
        from .notifications import show

        show(
            self.tray,
            "Interface minimizada. A execução continua ativa. Use Sair da interface para encerrar.",
        )
        event.ignore()


def launch(paths: Paths, run_detail: str = "") -> int:
    existing_app = QApplication.instance()
    if existing_app is not None and not isinstance(existing_app, QApplication):
        raise RuntimeError("A interface exige uma instância QApplication.")
    app = existing_app if existing_app is not None else QApplication(sys.argv[:1])
    app.setApplicationName("Orquestrador")
    app.setOrganizationName("Orquestrador")
    apply_theme(app)
    paths.ensure()
    from .native_updates import is_native

    native = is_native(paths)
    installer = Installer(paths)
    recovery = "" if native else installer.recover()
    if recovery:
        QMessageBox.information(None, "Recuperação de instalação", recovery)
    current = read_json(installer.pointer) if installer.pointer.is_file() else None
    if not paths.config.is_file() or (
        not native
        and getattr(sys, "frozen", False)
        and (not current or current.get("version") != VERSION)
    ):
        wizard = InstallWizard(paths, load(paths) if paths.config.is_file() else None)
        if not wizard.exec():
            return 3
        paths = wizard.paths
        from .__main__ import configure_logging

        logging_root = paths.root / "logs"
        logging_root.mkdir(parents=True, exist_ok=True)
        configure_logging(paths)
        from .runtime import capture_windowed_streams

        capture_windowed_streams(logging_root)
    window = MainWindow(paths)
    window.show()
    if native and any(job.enabled and job.requires_browser for job in window.config.routines):
        QTimer.singleShot(
            0,
            lambda: window.background(
                lambda: diagnose(paths, load(paths), repair=True, test_session=False)
            ),
        )
    if run_detail:
        show_detail(window, "Detalhe da execução", Store(paths.database).details(run_detail))
    return app.exec()

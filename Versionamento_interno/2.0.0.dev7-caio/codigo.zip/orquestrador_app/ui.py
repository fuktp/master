"""Shared native controls and explicit light palette; no extra UI framework."""

from __future__ import annotations

import json
from functools import cache
from string import Template
from typing import Any

from PySide6.QtCore import Qt, QTime
from PySide6.QtGui import QColor, QIcon, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
    QTableWidget,
    QTimeEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .i18n import tr
from .resources import asset_path

DAYS = (
    "Segunda-feira",
    "Terça-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "Sábado",
    "Domingo",
)


@cache
def theme() -> dict[str, Any]:
    return json.loads(asset_path("dashboard-theme.json").read_text(encoding="utf-8"))


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    colors = theme()
    palette = QPalette()
    for role, name in {
        QPalette.ColorRole.Window: "backgroundNeutral",
        QPalette.ColorRole.WindowText: "foreground",
        QPalette.ColorRole.Base: "background",
        QPalette.ColorRole.AlternateBase: "backgroundDark",
        QPalette.ColorRole.Text: "foreground",
        QPalette.ColorRole.Button: "backgroundDark",
        QPalette.ColorRole.ButtonText: "firstLevelElements",
        QPalette.ColorRole.Highlight: "accent",
        QPalette.ColorRole.HighlightedText: "foregroundSelected",
        QPalette.ColorRole.ToolTipBase: "background",
        QPalette.ColorRole.ToolTipText: "foregroundDark",
        QPalette.ColorRole.PlaceholderText: "foregroundNeutralSecondary",
    }.items():
        palette.setColor(QPalette.ColorGroup.All, role, QColor(colors[name]))
    for role in (
        QPalette.ColorRole.Text,
        QPalette.ColorRole.WindowText,
        QPalette.ColorRole.ButtonText,
    ):
        palette.setColor(
            QPalette.ColorGroup.Disabled, role, QColor(colors["foregroundNeutralSecondaryAlt"])
        )
    app.setPalette(palette)
    stylesheet = Template("""
        QWidget { font-family: "$font"; font-size: 10pt; color: $foreground; }
        QMainWindow, QDialog, QWizard, QScrollArea { background: $backgroundNeutral; }
        QLabel { background: transparent; color: $foreground; }
        QLabel[severity="error"] { color: $bad; font-weight: 600; }
        QLabel[severity="warning"] { color: $foregroundDark; background: #FFF4DD; padding: 8px; border-left: 4px solid $neutral; }
        QLabel[severity="success"] { color: $good; font-weight: 600; }
        QTabWidget::pane { border: 1px solid $shapeStroke; background: $background; }
        QTabBar::tab { padding: 10px 12px; background: $backgroundDark; color: $firstLevelElements; }
        QTabBar::tab:selected { background: $background; border-top: 3px solid $center; }
        QPushButton { padding: 7px 12px; min-height: 20px; background: $accent; color: $foregroundButton; border: 1px solid $accent; border-radius: 5px; }
        QPushButton:hover { background: $firstLevelElements; }
        QPushButton:disabled { background: $backgroundDark; color: $foregroundNeutralSecondary; border-color: $shapeStroke; }
        QToolButton { padding: 7px; background: $background; color: $firstLevelElements; border: 1px solid $shapeStroke; border-radius: 5px; }
        QToolButton:checked { background: $accent; color: $foregroundSelected; }
        QCheckBox, QRadioButton { color: $foreground; spacing: 8px; }
        QCheckBox::indicator { width: 18px; height: 18px; background: $background; border: 1px solid $foregroundNeutralSecondary; border-radius: 3px; }
        QCheckBox::indicator:checked { background: $accent; image: url("$checkmark"); }
        QCheckBox:disabled, QRadioButton:disabled { color: $foregroundNeutralSecondaryAlt; }
        QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QAbstractSpinBox, QListWidget { background: $background; color: $foreground; padding: 5px; border: 1px solid $shapeStroke; selection-background-color: $accent; selection-color: $foregroundSelected; }
        QComboBox QAbstractItemView, QMenu { background: $background; color: $foreground; selection-background-color: $accent; selection-color: $foregroundSelected; }
        QMenu::item:selected { background: $accent; color: $foregroundSelected; }
        QTableView { background: $background; color: $foreground; alternate-background-color: #F7F9FC; gridline-color: $foregroundNeutralTertiaryAlt; selection-background-color: $accent; selection-color: $foregroundSelected; }
        QTableView::item { padding: 5px; color: $foreground; }
        QTableView::item:selected { background: $accent; color: $foregroundSelected; }
        QHeaderView::section, QTableCornerButton::section { background: $tableAccent; color: $foregroundLight; padding: 9px; border: 1px solid $accent; font-weight: 600; }
        QProgressBar { color: $firstLevelElements; border: 1px solid $shapeStroke; min-height: 8px; }
        QProgressBar::chunk { background: $center; }
        QToolTip { background: $background; color: $foregroundDark; border: 1px solid $shapeStroke; }
        QGroupBox { border: 1px solid $shapeStroke; border-radius: 8px; margin-top: 12px; padding: 12px; }
        QGroupBox::title { color: $firstLevelElements; }
    """)
    app.setStyleSheet(
        stylesheet.substitute(
            colors,
            font=colors["textClasses"]["label"]["fontFace"],
            checkmark=asset_path("checkmark.svg").as_posix(),
        )
    )
    app.setApplicationName("CAIO")
    app.setWindowIcon(icon())


def icon() -> QIcon:
    result = QIcon(str(asset_path("caio.ico")))
    if result.isNull():
        raise ValueError("O ícone CAIO não pôde ser carregado.")
    return result


def configure_table(table: QTableWidget) -> None:
    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    table.horizontalHeader().setMinimumSectionSize(95)
    table.horizontalHeader().setMinimumHeight(42)
    table.horizontalHeader().setDefaultAlignment(
        Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
    )
    table.verticalHeader().setVisible(False)
    table.setPalette(QApplication.palette())


class DaysPicker(QWidget):
    def __init__(self, days: list[int], parent: QWidget | None = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.buttons = []
        for index, name in enumerate(DAYS):
            button = QToolButton()
            button.setText(tr(name)[:1])
            button.setToolTip(tr(name))
            button.setAccessibleName(tr(name))
            button.setCheckable(True)
            button.setChecked(index in days)
            button.setMinimumSize(44, 38)
            self.buttons.append(button)
            layout.addWidget(button)
        layout.addStretch()

    def values(self) -> list[int]:
        return [i for i, button in enumerate(self.buttons) if button.isChecked()]

    def set_days(self, days: list[int]) -> None:
        for i, button in enumerate(self.buttons):
            button.setChecked(i in days)


class TimesPicker(QWidget):
    def __init__(self, times: list[str], parent: QWidget | None = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.list = QListWidget()
        self.list.addItems(sorted(times))
        self.list.setMaximumHeight(90)
        layout.addWidget(self.list)
        tools = QVBoxLayout()
        self.clock = QTimeEdit(QTime(8, 30))
        self.clock.setDisplayFormat("HH:mm")
        self.clock.setToolTip(
            tr("Escolha a hora e os minutos; depois clique em Adicionar horário.")
        )
        tools.addWidget(self.clock)
        add = QPushButton(tr("Adicionar horário"))
        add.clicked.connect(self.add)
        tools.addWidget(add)
        remove = QPushButton(tr("Retirar horário"))
        remove.clicked.connect(lambda: self.list.takeItem(self.list.currentRow()))
        tools.addWidget(remove)
        layout.addLayout(tools)

    def add(self) -> None:
        value = self.clock.time().toString("HH:mm")
        if value not in self.values():
            self.list.addItem(value)
            self.list.sortItems()

    def values(self) -> list[str]:
        return [self.list.item(i).text() for i in range(self.list.count())]


def explain(text: str) -> QLabel:
    label = QLabel(tr(text))
    label.setWordWrap(True)
    label.setStyleSheet("color: #5B6770; padding: 3px 0;")
    return label


def set_cell(table: Any, row: int, column: int, value: Any, role: Any = None) -> None:
    from PySide6.QtWidgets import QTableWidgetItem

    text = str(value if value is not None else "")
    if len(text) > 19 and text[4:5] == "-" and text[10:11] == "T":
        import datetime as dt

        try:
            text = dt.datetime.fromisoformat(text).astimezone().strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    text = tr(text)
    item = table.item(row, column)
    if item is None:
        item = QTableWidgetItem(text)
        table.setItem(row, column, item)
    elif item.text() != text:
        item.setText(text)
    item.setForeground(QColor(theme()["foreground"]))
    if role is not None:
        item.setData(Qt.ItemDataRole.UserRole, role)

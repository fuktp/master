from __future__ import annotations

import os
import socket
from pathlib import Path
from typing import Any

import pytest

from orquestrador_app.config import Config, Routine, save
from orquestrador_app.paths import Paths

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(autouse=True)
def no_network(monkeypatch: pytest.MonkeyPatch) -> None:
    def denied(*_: Any, **__: Any) -> Any:
        raise AssertionError("Rede bloqueada na suíte padrão.")

    monkeypatch.setattr(socket, "create_connection", denied)
    monkeypatch.setattr(socket.socket, "connect", denied)


@pytest.fixture
def environment(tmp_path: Path) -> tuple[Paths, Config]:
    paths = Paths.user(tmp_path / "usuário diferente com acentuação")
    paths.ensure()
    config = Config(
        email="usuario@example.invalid",
        profile=str(paths.root / "profiles/Edge"),
        driver=str(paths.root / "cache/driver.exe"),
        downloads=str(paths.root / "downloads"),
        logs=str(paths.root / "logs"),
        install_root=str(paths.root / "installed"),
    )
    for index, name in enumerate(
        ("pipefy_clientes_tool_edge", "pipefy_eventos_tool_edge", "kwms_alocacoes_tool_edge")
    ):
        config.routines.append(Routine(id=name, label=name, script="not-used.py", order=index))
    save(paths, config)
    return paths, config

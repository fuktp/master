from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
)

from .io import Lock, atomic_json, read_json
from .native_updates import check_feed, https_host, open_wizard, prepare_zip


def preferences(window: Any) -> None:
    file = window.paths.root / "update.json"
    values = read_json(file) if file.is_file() else {}
    dialog = QDialog(window)
    dialog.setWindowTitle("Instalação e atualização • scripts nativos")
    dialog.resize(680, 260)
    form = QFormLayout(dialog)
    form.addRow(
        QLabel(
            "O wizard WinForms prepara versões em pastas separadas. Dados e extratores são preservados."
        )
    )
    address = QLineEdit(values.get("feed_url", ""))
    address.setPlaceholderText("Endereço HTTPS fornecido pelo administrador; opcional")
    form.addRow("Feed interno", address)
    enabled = QCheckBox("Verificar e baixar atualizações a cada 4 horas com a interface aberta")
    enabled.setChecked(values.get("enabled", False))
    form.addRow(enabled)
    form.addRow(
        QLabel("A ativação solicita reinício. O feed fica desativado até configurar uma origem.")
    )

    def persist() -> None:
        url = address.text().strip()
        if url:
            https_host(url)
        if enabled.isChecked() and not url:
            raise ValueError("Informe o feed HTTPS antes de ativar a verificação.")
        atomic_json(file, {**values, "feed_url": url, "enabled": enabled.isChecked()})

    def save_preferences() -> None:
        try:
            persist()
            dialog.accept()
        except Exception as exc:
            QMessageBox.warning(dialog, "Atualização", str(exc))

    def local_package() -> None:
        archive = QFileDialog.getOpenFileName(
            dialog, "Selecionar pacote completo", "", "Pacote ZIP (*.zip)"
        )[0]
        if archive:
            dialog.accept()
            from .gui import Task

            task = Task(lambda: str(prepare_zip(window.paths, Path(archive))), window)
            window.task = task
            prepared: list[str] = []
            task.done.connect(lambda result: prepared.append(result))
            task.failed.connect(window.task_error)
            task.finished.connect(lambda: handoff(window, Path(prepared[0])) if prepared else None)
            task.start()

    def repair() -> None:
        dialog.accept()
        handoff(window)

    def check_now() -> None:
        try:
            if not address.text().strip():
                raise ValueError("Informe um feed HTTPS para verificar atualizações.")
            persist()
            dialog.accept()
            check_automatically(window, force=True)
        except Exception as exc:
            QMessageBox.warning(dialog, "Atualização", str(exc))

    for label, callback in (
        ("Salvar preferências", save_preferences),
        ("Abrir wizard de reparo e configuração", repair),
        ("Atualizar por ZIP local…", local_package),
        ("Verificar feed agora", check_now),
    ):
        button = QPushButton(label)
        button.clicked.connect(callback)
        form.addRow(button)
    dialog.exec()


def handoff(window: Any, package: Path | None = None, backup: Path | None = None) -> None:
    try:
        if window.task and window.task.isRunning():
            raise ValueError("Aguarde a operação atual antes de atualizar.")
        if window.dev_panel.task and window.dev_panel.task.isRunning():
            raise ValueError("Aguarde o diagnóstico de Dev antes de atualizar.")
        update_task = getattr(window, "update_task", None)
        if update_task and update_task.isRunning():
            raise ValueError("Aguarde a conclusão da verificação de atualização.")
        with Lock(window.paths.lock):
            pass
        if (
            QMessageBox.question(
                window,
                "Abrir manutenção",
                "O aplicativo será fechado para o wizard de instalação/atualização. Continuar?",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        open_wizard(window.paths, package, backup)
        window.exit_requested = True
        window.close()
    except Exception as exc:
        window.task_error(str(exc))


def check_automatically(window: Any, force: bool = False) -> None:
    from .gui import Task

    file = window.paths.root / "update.json"
    values = read_json(file) if file.is_file() else {}
    if not values.get("feed_url") or (not force and not values.get("enabled")):
        return
    now = dt.datetime.now(dt.timezone.utc)
    if not force and values.get("last_checked"):
        if (now - dt.datetime.fromisoformat(values["last_checked"])).total_seconds() < 14400:
            return
    if (window.task and window.task.isRunning()) or (
        getattr(window, "update_task", None) and window.update_task.isRunning()
    ):
        return
    atomic_json(file, {**values, "last_checked": now.isoformat()})
    task = Task(lambda: check_feed(window.paths, values["feed_url"]))
    window.update_task = task

    def done(result: dict[str, Any]) -> None:
        window.store.event(
            None,
            "native_update_checked",
            {"available": result["available"], "version": result["version"]},
        )
        if not result["available"]:
            if force:
                QMessageBox.information(
                    window, "Atualização", "A versão instalada está atualizada no feed configurado."
                )
            return
        if not force and values.get("last_notified") == result["sha256"]:
            return
        latest = read_json(file)
        atomic_json(
            file,
            {**latest, "last_notified": result["sha256"], "pending_package": result["package"]},
        )
        if (
            QMessageBox.question(
                window,
                "Atualização disponível",
                f"Versão {result['version']} baixada e verificada. Abrir o wizard para instalar e reiniciar?",
            )
            == QMessageBox.StandardButton.Yes
        ):
            # The signal may arrive just before QThread.finished; defer handoff until termination.
            from PySide6.QtCore import QTimer

            QTimer.singleShot(250, lambda: handoff(window, Path(result["package"])))

    task.done.connect(done)
    task.failed.connect(
        window.task_error
        if force
        else lambda message: window.store.event(None, "native_update_error", message)
    )
    task.start()

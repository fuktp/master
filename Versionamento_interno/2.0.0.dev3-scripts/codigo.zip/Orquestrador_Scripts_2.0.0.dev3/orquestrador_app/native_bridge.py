"""JSON protocol for the PowerShell UI; no corporate connections during setup."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
from typing import Any

from . import VERSION
from .config import from_dict, load, to_dict, validate
from .io import atomic_json, read_json
from .native_install import NativeInstaller, verify_release
from .paths import Paths, identity, onedrives
from .sandbox import check_location, prepare_config, validate_isolation


def preview(root: Path) -> dict[str, Any]:
    paths = check_location(root.resolve())
    config = load(paths) if paths.config.is_file() else prepare_config(paths)
    validate_isolation(paths, config)
    pointer = paths.root / "installation.json"
    return {
        "version": VERSION,
        "config": to_dict(config),
        "identity": identity(),
        "onedrives": onedrives(),
        "current": read_json(pointer) if pointer.is_file() else None,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--cancel", type=Path)
    args = parser.parse_args(argv)
    args.events.parent.mkdir(parents=True, exist_ok=True)

    def progress(message: str) -> None:
        with args.events.open("a", encoding="utf-8") as stream:
            stream.write(
                json.dumps(
                    {"at": dt.datetime.now(dt.timezone.utc).isoformat(), "stage": message},
                    ensure_ascii=False,
                )
                + "\n"
            )

    try:
        from .runtime import install_console_policy

        install_console_policy()
        request = read_json(args.request)
        paths = Paths.user(request["data_root"])
        action = request["action"]
        installer = NativeInstaller(paths)
        if action == "preview":
            value = preview(paths.root)
        elif action == "recover":
            value = {"recovery": installer.recover()}
        elif action == "health":
            from .__main__ import health_check

            verify_release(Path(request["payload"]))
            value = health_check()
        elif action in {"install", "repair", "update"}:
            recovery = installer.recover()
            if recovery:
                progress(recovery)
            if "config" in request:
                config = from_dict(request["config"])
            else:
                config = load(paths) if paths.config.is_file() else prepare_config(paths)
            validate(config)
            validate_isolation(paths, config)
            source = Path(request["payload"])
            record = verify_release(source)

            def cancel() -> bool:
                return bool(args.cancel and args.cancel.is_file())

            launcher = installer.install(source, config, progress, cancelled=cancel)
            value = {"launcher": str(launcher), "version": record["version"], "status": "committed"}
        elif action == "rollback":
            installer.rollback(Path(request["backup"]))
            value = {"status": "rolled_back"}
        else:
            raise ValueError("Ação nativa desconhecida.")
        atomic_json(args.result, {"ok": True, "pid": os.getpid(), "result": value})
        return 0
    except Exception as exc:
        progress(str(exc))
        atomic_json(args.result, {"ok": False, "error": str(exc), "type": type(exc).__name__})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

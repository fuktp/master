from __future__ import annotations

import dataclasses
import logging
import os
import shutil
import subprocess
from typing import Any, Mapping

from .config import Config
from .io import atomic_json
from .paths import Paths


def guard(paths: Paths, config: Config) -> Any:
    import pipefy_orchestrator as legacy

    temporary = paths.root / "cache/driver-compat.config.json"
    atomic_json(
        temporary,
        {
            "schema_version": 1,
            "project_root": str(paths.root / "extras"),
            "output_dir": str(paths.root / "cache/diagnostic"),
            "runtime_dir": str(paths.root / "cache/driver-health"),
            "logs_dir": config.logs,
            "jobs": [],
            "driver": {
                **config.driver_options,
                "managed_path": config.driver,
                "selenium_cache": config.driver_options.get(
                    "selenium_cache", str(paths.root / "cache/selenium")
                ),
                "verify_authenticode": True,
                "adapt_script_driver_paths": False,
            },
        },
    )

    class DesktopGuard(legacy.DriverGuard):
        @staticmethod
        def _powershell_output(command: str, environment: Mapping[str, str]) -> str:
            executable = shutil.which("powershell.exe")
            if not executable:
                raise RuntimeError("PowerShell do Windows indisponível para diagnóstico de versão.")
            result = subprocess.run(
                [executable, "-NoProfile", "-NonInteractive", "-Command", command],
                env={**os.environ, **environment},
                capture_output=True,
                text=True,
                timeout=30,
                creationflags=0x08000000 if os.name == "nt" else 0,
            )
            if result.returncode:
                raise RuntimeError("Falha na consulta de versão pelo Windows.")
            return result.stdout.strip()

        def authenticode_status(self, path: Any) -> Any:
            status = super().authenticode_status(path)
            if os.name == "nt" and status != "Valid":
                raise RuntimeError(
                    f"Verificação de assinatura do EdgeDriver não aprovada: {status}"
                )
            return status

    settings = legacy.load_settings(temporary)
    settings = dataclasses.replace(settings, python_executable="")
    return DesktopGuard(settings, logging.getLogger("desktop.driver"))


def diagnose(paths: Paths, config: Config, repair: bool = False) -> dict[str, Any]:
    instance = guard(paths, config)
    details = instance.ensure(repair=repair, test_session=True)
    return dict(details)

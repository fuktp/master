from __future__ import annotations

import copy
import dataclasses
import datetime as dt
import importlib.metadata
import json
import os
import sys
from pathlib import Path
from typing import Any, Callable

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QAction, QCloseEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QStyle,
    QSystemTrayIcon,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QWizard,
    QWizardPage,
)

from . import VERSION
from .clock import local_now
from .config import (
    KNOWN,
    Config,
    Routine,
    Schedule,
    discover,
    from_dict,
    import_preview,
    load,
    migrate,
    portable,
    save,
    to_dict,
    validate,
)
from .connectivity import as_dict, classify, probe
from .driver import diagnose
from .engine import Engine
from .files import Publisher
from .install import Installer
from .io import BusyError, Lock, atomic_json, digest, read_json
from .paths import Paths, check_directory, identity, onedrives
from .processes import spawn
from .resources import script_path, source_root
from .sandbox import check_location, confined, mark, prepare_config, remember
from .store import Store
from .tasks import WindowsTasks
from .worker import module_for, public_pipefy

STATUS = {
    "running": "Em execução",
    "success": "Concluída",
    "failed": "Falhou",
    "skipped": "Ignorada; pendente",
    "cancelled": "Cancelada",
    "not_eligible": "Não elegível",
    "ignored": "Desabilitada",
    "blocked_dependency": "Bloqueada por dependência",
}


class Task(QThread):
    done = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, callback: Callable[[], Any], parent: Any = None):
        super().__init__(parent)
        self.callback = callback

    def run(self) -> None:
        try:
            self.done.emit(self.callback())
        except Exception as exc:
            self.failed.emit(str(exc))


class VpnNotice(QDialog):
    def __init__(self, store: Store, run: str, message: str, parent: QWidget | None = None):
        super().__init__(parent)
        self.store, self.run_id = store, run
        self.setWindowTitle("KWMS • Verifique a VPN")
        layout = QVBoxLayout(self)
        label = QLabel(message)
        label.setWordWrap(True)
        layout.addWidget(label)
        self.countdown = QLabel("Aguardando o próximo registro da execução…")
        layout.addWidget(self.countdown)
        self.clock = QTimer(self)
        self.clock.timeout.connect(self.update_countdown)
        self.clock.start(1000)
        self.update_countdown()
        self.show()
        QApplication.alert(self, 15000)

    def update_countdown(self) -> None:
        with self.store.connect() as db:
            row = db.execute("SELECT status,stage FROM runs WHERE id=?", (self.run_id,)).fetchone()
        if not row or row["status"] != "running":
            self.clock.stop()
            self.close()
            return
        self.countdown.setText(row["stage"])


def button(text: str, callback: Callable[..., Any], layout: Any) -> QPushButton:
    result = QPushButton(text)
    result.clicked.connect(callback)
    layout.addWidget(result)
    return result


def path_field(value: str, *, file: bool = False) -> tuple[QWidget, QLineEdit]:
    widget = QWidget()
    layout = QHBoxLayout(widget)
    layout.setContentsMargins(0, 0, 0, 0)
    field = QLineEdit(value)
    layout.addWidget(field)

    def browse() -> None:
        result = (
            QFileDialog.getOpenFileName(widget, "Selecionar arquivo", field.text())[0]
            if file
            else QFileDialog.getExistingDirectory(widget, "Selecionar pasta", field.text())
        )
        if result:
            field.setText(result)

    button("Escolher…", browse, layout)
    return widget, field


def json_view(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, default=str)


def show_detail(parent: QWidget, title: str, value: Any) -> None:
    dialog = QDialog(parent)
    dialog.setWindowTitle(title)
    dialog.resize(900, 600)
    layout = QVBoxLayout(dialog)
    content = QPlainTextEdit(value if isinstance(value, str) else json_view(value))
    content.setReadOnly(True)
    layout.addWidget(content)
    button("Fechar", dialog.accept, layout)
    dialog.exec()


class RoutineDialog(QDialog):
    def __init__(self, config: Config, job: Routine, parent: QWidget | None = None):
        super().__init__(parent)
        self.config, self.job = config, job
        self.updated = job
        self.setWindowTitle(f"Rotina • {job.label}")
        self.resize(750, 700)
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)
        general = QWidget()
        form = QFormLayout(general)
        self.enabled = QCheckBox("Habilitar esta rotina")
        self.enabled.setChecked(job.enabled)
        form.addRow(self.enabled)
        form.addRow("Origem", QLabel(job.origin))
        script, self.script = path_field(job.script, file=True)
        form.addRow("Extrator", script)
        self.trust = QCheckBox("Autorizar o código deste arquivo pelo hash atual")
        form.addRow(self.trust)
        self.hash = QLabel(job.trusted_sha256 or "Não autorizado")
        self.hash.setWordWrap(True)
        form.addRow("SHA-256 autorizado", self.hash)
        self.frequency = QComboBox()
        for label, value in (
            ("Diária: um sucesso por data", "daily"),
            ("Semanal: um sucesso por semana", "weekly"),
            ("Todos os horários: um sucesso por ocorrência", "every_run"),
        ):
            self.frequency.addItem(label, value)
        self.frequency.setCurrentIndex(max(0, self.frequency.findData(job.schedule.frequency)))
        form.addRow("Frequência", self.frequency)
        self.times = QLineEdit(", ".join(job.schedule.times))
        form.addRow("Horários próprios (HH:MM)", self.times)
        weekdays = QWidget()
        weekday_layout = QHBoxLayout(weekdays)
        self.days = []
        for index, label in enumerate(("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")):
            box = QCheckBox(label)
            box.setChecked(index in job.schedule.days)
            self.days.append(box)
            weekday_layout.addWidget(box)
        form.addRow("Dias; feriados não são excluídos", weekdays)
        self.weekday = QComboBox()
        self.weekday.addItems(
            ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]
        )
        self.weekday.setCurrentIndex(job.schedule.weekday)
        form.addRow("Dia inicial semanal", self.weekday)
        self.paused = QCheckBox("Pausar o agendamento desta rotina")
        self.paused.setChecked(job.schedule.paused)
        form.addRow(self.paused)
        self.order = QSpinBox()
        self.order.setRange(0, 999)
        self.order.setValue(job.order)
        form.addRow("Ordem/prioridade na fila", self.order)
        self.headless = QCheckBox("Navegador headless (sem janela); SSO pode exigir Testar login")
        self.headless.setChecked(job.headless)
        form.addRow(self.headless)
        destination, self.destination = path_field(
            str(Path(job.target).parent) if job.target else ""
        )
        form.addRow("Pasta de publicação local", destination)
        self.url = QLineEdit(job.url)
        self.url.setPlaceholderText("Vazio preserva a URL confirmada no extrator")
        form.addRow("URL configurável", self.url)
        note = QLabel(
            "Diária: horários extras recuperam pendências. Todos os horários permite atualizar novamente após um sucesso. Recuperação reúne horários perdidos em uma oportunidade; não reexecuta toda a fila antiga."
        )
        note.setWordWrap(True)
        form.addRow(note)
        tabs.addTab(general, "Rotina e horários")
        advanced = QWidget()
        advanced_form = QFormLayout(advanced)
        data = dataclasses.asdict(job)
        for key in (
            "id",
            "label",
            "script",
            "origin",
            "enabled",
            "order",
            "schedule",
            "trusted_sha256",
            "target",
            "headless",
            "url",
        ):
            data.pop(key)
        data["catch_up_hours"] = job.schedule.catch_up_hours
        self.advanced = QPlainTextEdit(json_view(data))
        advanced_form.addRow(
            QLabel(
                "Dependências: same_chain ou fresh_success + max_age_minutes.\nArgumentos: lista JSON, sem shell. Variáveis não podem conter segredos.\nPrazo esperado: horas em dias habilitados; tolerância em grace_hours.\nTentativas por categoria incluem a tentativa inicial; VPN interna = 2 × 30 s."
            )
        )
        advanced_form.addRow(self.advanced)
        tabs.addTab(advanced, "Dependências, retries e opções")
        controls = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        controls.accepted.connect(self.accept_values)
        controls.rejected.connect(self.reject)
        layout.addWidget(controls)

    def accept_values(self) -> None:
        try:
            value = dataclasses.asdict(self.job)
            extra = json.loads(self.advanced.toPlainText())
            catchup = extra.pop("catch_up_hours", 24)
            value.update(extra)
            value.update(
                enabled=self.enabled.isChecked(),
                script=self.script.text(),
                order=self.order.value(),
                headless=self.headless.isChecked(),
                url=self.url.text().strip(),
            )
            value["schedule"] = dataclasses.asdict(
                Schedule(
                    frequency=self.frequency.currentData(),
                    times=[t.strip() for t in self.times.text().split(",")],
                    days=[i for i, d in enumerate(self.days) if d.isChecked()],
                    weekday=self.weekday.currentIndex(),
                    paused=self.paused.isChecked(),
                    catch_up_hours=int(catchup),
                )
            )
            folder = self.destination.text().strip()
            if folder:
                filename = KNOWN.get(self.job.id, ("", "", Path(self.job.target).name))[2]
                if not filename:
                    raise ValueError(
                        "Extrator adicional exige um contrato de destino explícito em Configuração completa."
                    )
                value["target"] = str(Path(folder) / filename)
            if self.trust.isChecked():
                value["trusted_sha256"] = digest(script_path(value["script"]))
            candidate = to_dict(self.config)
            candidate["routines"] = [
                value if j["id"] == self.job.id else j for j in candidate["routines"]
            ]
            self.updated = from_dict(candidate).job(self.job.id)
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "Configuração inválida", str(exc))


class InstallPage(QWizardPage):
    def __init__(self, title: str, validator: Callable[[], bool] | None = None):
        super().__init__()
        self.setTitle(title)
        self.validator = validator

    def validatePage(self) -> bool:
        return self.validator() if self.validator else True


class InstallWizard(QWizard):
    def __init__(
        self,
        paths: Paths,
        config: Config | None = None,
        parent: QWidget | None = None,
        installer: Installer | None = None,
    ):
        super().__init__(parent)
        self.paths = paths
        self.config = (
            copy.deepcopy(config) if config and config.test_mode else prepare_config(paths, config)
        )
        self.installer = installer or Installer(paths)
        self.installed = False
        self.install_task: Task | None = None
        self.changes: list[str] = []
        self.setWindowTitle("Orquestrador • Instalação de teste e atualização")
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        self.setButtonText(QWizard.WizardButton.NextButton, "Avançar")
        self.setButtonText(QWizard.WizardButton.BackButton, "Voltar")
        self.setButtonText(QWizard.WizardButton.CancelButton, "Cancelar")
        self.setButtonText(QWizard.WizardButton.FinishButton, "Abrir aplicativo")
        self.resize(900, 690)
        diagnostic = InstallPage("1. Diagnóstico prévio", self.initial_decision)
        layout = QVBoxLayout(diagnostic)
        current = read_json(self.installer.pointer) if self.installer.pointer.is_file() else {}
        text = f"Versão atual de teste: {current.get('version', 'não instalada')}\nNova versão: {VERSION}\nSistema: {sys.platform}\nRuntime: {'privado no executável' if getattr(sys, 'frozen', False) else 'modo de desenvolvimento'}\n\nEDIÇÃO DE TESTE ISOLADA\nEscolha uma pasta vazia. Aplicativo, perfil do Edge, relatórios, configurações e logs serão mantidos nessa pasta. A instalação original e suas tarefas permanecem preservadas. O versionamento usa snapshots e hashes internos. Falhas internas acionam reversão automática. Login e VPN são testes operacionais separados."
        label = QLabel(text)
        label.setWordWrap(True)
        layout.addWidget(label)
        self.operation = QComboBox()
        self.operation.addItems(
            ["Instalar/atualizar", "Reparar a instalação", "Abrir versão instalada"]
            if current
            else ["Instalar"]
        )
        layout.addWidget(self.operation)
        button("Copiar preferências da v1.3.0 para o teste…", self.import_legacy, layout)
        layout.addStretch()
        self.addPage(diagnostic)
        location = InstallPage("2. Pasta exclusiva da versão de teste", self.select_location)
        form = QFormLayout(location)
        suggestion = (
            paths.root
            if (paths.root / "instalacao-teste.json").is_file()
            else paths.root.parent / "Ambiente"
        )
        widget, self.install_root = path_field(str(suggestion))
        form.addRow("Pasta de teste", widget)
        form.addRow(
            QLabel(
                "Use uma pasta vazia ou uma instalação de teste reconhecida. Nenhum arquivo existente de outra instalação será substituído. É possível voltar ou cancelar antes de aplicar."
            )
        )
        self.addPage(location)
        who = InstallPage("3. Usuário, computador e OneDrive")
        form = QFormLayout(who)
        self.who = QLabel(json_view(identity()))
        self.who.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        form.addRow(self.who)
        self.email = QLineEdit(self.config.email)
        form.addRow("E-mail corporativo", self.email)
        self.accounts = QComboBox()
        self.accounts.addItem("Selecione explicitamente um destino ou use o seletor de pastas", "")
        for account in onedrives():
            self.accounts.addItem(
                f"{account['kind']} • {account['account']} • {account['path']}", account["path"]
            )
        form.addRow("Contas detectadas", self.accounts)
        form.addRow(
            QLabel(
                "Contas exibidas para identificação. Os destinos desta edição permanecem na pasta de teste."
            )
        )
        self.addPage(who)
        destinations = InstallPage("4. Destinos dos arquivos", self.validate_destinations)
        self.destination_form = QFormLayout(destinations)
        self.destination_fields: dict[str, QLineEdit] = {}
        self.build_destinations()
        self.addPage(destinations)
        routines = InstallPage("5. Rotinas, dependências e horários próprios")
        layout = QVBoxLayout(routines)
        layout.addWidget(
            QLabel(
                "Selecione uma rotina para editar frequência, dias, horários, ordem, dependências e retries."
            )
        )
        self.routine_table = QTableWidget(0, 4)
        self.routine_table.setHorizontalHeaderLabels(
            ["Rotina", "Habilitada", "Frequência", "Horários próprios"]
        )
        self.routine_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.routine_table.cellDoubleClicked.connect(lambda row, _: self.edit_job(row))
        layout.addWidget(self.routine_table)
        button(
            "Editar rotina selecionada",
            lambda: self.edit_job(self.routine_table.currentRow()),
            layout,
        )
        self.refresh_routines()
        self.schedule_install = QCheckBox(
            "Instalar monitor de teste no Agendador (agendamento inicialmente pausado)"
        )
        self.schedule_install.setChecked(self.config.install_schedules)
        layout.addWidget(self.schedule_install)
        self.addPage(routines)
        dependencies = InstallPage("6. Validação de dependências")
        layout = QVBoxLayout(dependencies)
        self.dependency_text = QPlainTextEdit()
        self.dependency_text.setReadOnly(True)
        layout.addWidget(self.dependency_text)
        self.dependency_text.setPlainText(
            json_view(
                {
                    name: importlib.metadata.version(name)
                    for name in ("PySide6", "selenium", "pandas", "openpyxl", "requests")
                }
            )
        )
        layout.addWidget(
            QLabel(
                "O health check de instalação valida somente recursos internos. Antes da primeira extração, use Diagnóstico para verificar Edge/assinatura e Testar login para renovar SSO/MFA."
            )
        )
        self.addPage(dependencies)
        review = InstallPage("7. Revisão das alterações", self.review_valid)
        layout = QVBoxLayout(review)
        self.review_text = QPlainTextEdit()
        self.review_text.setReadOnly(True)
        layout.addWidget(self.review_text)
        self.approve = QCheckBox(
            "Aplicar somente na pasta de teste e criar snapshots internos verificáveis"
        )
        layout.addWidget(self.approve)
        self.addPage(review)
        install = InstallPage("8. Instalação, atualização e verificação final")
        layout = QVBoxLayout(install)
        self.install_text = QPlainTextEdit()
        self.install_text.setReadOnly(True)
        self.install_bar = QProgressBar()
        self.install_bar.setRange(0, 0)
        layout.addWidget(self.install_bar)
        layout.addWidget(self.install_text)
        self.addPage(install)
        self.currentIdChanged.connect(self.page_changed)

    def select_location(self) -> bool:
        try:
            selected = check_location(Path(self.install_root.text().strip()))
            existing = selected.root
            while not existing.exists() and existing != existing.parent:
                existing = existing.parent
            check_directory(existing, min_free=500_000_000)
            if selected.root != self.paths.root:
                if selected.config.is_file():
                    self.config = load(selected)
                    from .sandbox import validate_isolation

                    validate_isolation(selected, self.config)
                else:
                    self.config = prepare_config(selected, self.config)
                self.paths = selected
                self.installer = Installer(selected)
                self.email.setText(self.config.email)
                self.schedule_install.setChecked(self.config.install_schedules)
                self.build_destinations()
                self.refresh_routines()
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Pasta de teste", str(exc))
            return False

    def initial_decision(self) -> bool:
        if self.operation.currentText() == "Abrir versão instalada":
            current = read_json(self.installer.pointer)
            spawn([current["executable"], "--data-root", str(self.paths.root)])
            self.reject()
            return False
        return True

    def build_destinations(self) -> None:
        while self.destination_form.count():
            item = self.destination_form.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.destination_fields.clear()
        for job in self.config.routines:
            widget, field = path_field(str(Path(job.target).parent) if job.target else "")
            self.destination_fields[job.id] = field
            self.destination_form.addRow(job.label, widget)
        self.destination_form.addRow(
            QLabel(
                "A gravação é local. A sincronização do OneDrive/SharePoint não é confirmada pelo aplicativo."
            )
        )

    def import_legacy(self) -> None:
        filename = QFileDialog.getOpenFileName(
            self, "Configuração da instalação existente", "", "JSON (*.json)"
        )[0]
        if not filename:
            return
        try:
            candidate, self.changes = migrate(Path(filename), self.paths, source_root())
            self.config = prepare_config(self.paths, candidate)
            self.changes.append(
                "Destinos, perfil, logs e downloads redirecionados ao teste; tarefas e estado de produção preservados."
            )
            self.email.setText(self.config.email)
            self.build_destinations()
            self.refresh_routines()
            show_detail(self, "Prévia da migração", self.changes)
        except Exception as exc:
            QMessageBox.warning(self, "Migração não aplicada", str(exc))

    def apply_base(self) -> None:
        folder = self.accounts.currentData()
        if not folder:
            QMessageBox.information(
                self, "Destino", "Selecione uma conta ou escolha cada pasta na próxima etapa."
            )
            return
        for job in self.config.routines:
            subfolder = KNOWN.get(job.id, ("", job.id, ""))[1]
            self.destination_fields[job.id].setText(str(Path(folder) / subfolder))

    def validate_destinations(self) -> bool:
        try:
            for job in self.config.routines:
                text = self.destination_fields[job.id].text().strip()
                if not job.enabled and not text:
                    continue
                if not text or not Path(text).is_absolute():
                    raise ValueError(f"Escolha a pasta de destino de {job.label}.")
                candidate = Path(text)
                confined(self.paths, candidate, f"Pasta de {job.label}")
                existing = candidate
                while not existing.exists() and existing != existing.parent:
                    existing = existing.parent
                check_directory(existing)
                filename = KNOWN.get(job.id, ("", "", Path(job.target).name))[2]
                job.target = str(candidate / filename) if filename else job.target
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Destino inválido", str(exc))
            return False

    def refresh_routines(self) -> None:
        self.routine_table.setRowCount(len(self.config.routines))
        for row, job in enumerate(self.config.routines):
            for column, value in enumerate(
                (
                    job.label,
                    "Sim" if job.enabled else "Não",
                    job.schedule.frequency,
                    ", ".join(job.schedule.times),
                )
            ):
                self.routine_table.setItem(row, column, QTableWidgetItem(value))

    def edit_job(self, row: int) -> None:
        if row < 0:
            return
        dialog = RoutineDialog(self.config, self.config.routines[row], self)
        if dialog.exec():
            self.config.routines[row] = dialog.updated
            self.refresh_routines()

    def review_valid(self) -> bool:
        try:
            if not self.approve.isChecked():
                raise ValueError("Revise e marque a aplicação das alterações para continuar.")
            self.config.email = self.email.text().strip()
            self.config.install_root = str(self.paths.root / "app")
            self.config.install_schedules = self.schedule_install.isChecked()
            if self.config.email and "@" not in self.config.email:
                raise ValueError("Informe um e-mail válido ou deixe vazio para testes locais.")
            validate(self.config)
            return True
        except Exception as exc:
            QMessageBox.warning(self, "Revisão", str(exc))
            return False

    def page_changed(self, page: int) -> None:
        if page == 6:
            self.config.email = self.email.text().strip()
            self.config.install_root = str(self.paths.root / "app")
            self.config.install_schedules = self.schedule_install.isChecked()
            self.review_text.setPlainText(
                json_view(
                    {
                        "version": VERSION,
                        "pasta_exclusiva_do_teste": str(self.paths.root),
                        "versionamento": "interno: snapshots e SHA-256; sem Git",
                        "changes": self.changes,
                        "configuration": to_dict(self.config),
                    }
                )
            )
        if page == 7:
            self.button(QWizard.WizardButton.BackButton).setEnabled(False)
            self.button(QWizard.WizardButton.CancelButton).setEnabled(False)
            self.button(QWizard.WizardButton.FinishButton).setEnabled(False)
            task = Task(
                lambda: self.installer.install(
                    Path(sys.executable),
                    self.config,
                    progress=lambda message: task.progress.emit(message),
                ),
                self,
            )
            self.install_task = task
            task.progress.connect(self.install_text.appendPlainText)
            task.done.connect(self.install_done)
            task.failed.connect(self.install_failed)
            task.start()

    def install_done(self, result: Any) -> None:
        self.installed_executable = Path(result)
        mark(self.paths)
        remember(self.paths)
        self.installed = True
        self.install_bar.setRange(0, 1)
        self.install_bar.setValue(1)
        self.button(QWizard.WizardButton.FinishButton).setEnabled(True)
        self.install_text.appendPlainText(f"Versão instalada: {result}")

    def install_failed(self, error: str) -> None:
        self.install_bar.setRange(0, 1)
        self.install_bar.setValue(0)
        self.install_text.appendPlainText(
            error
            + "\nConsulte acima o resultado da reversão. A conversão não será marcada como instalada."
        )
        self.button(QWizard.WizardButton.CancelButton).setEnabled(True)

    def reject(self) -> None:
        if self.install_task and self.install_task.isRunning():
            return
        super().reject()

    def accept(self) -> None:
        if self.installed:
            super().accept()


class MainWindow(QMainWindow):
    def __init__(self, paths: Paths):
        super().__init__()
        self.paths = paths
        self.config = load(paths)
        self.store = Store(paths.database)
        self.task: Task | None = None
        self.update_task: Task | None = None
        self.exit_requested = False
        self.setWindowTitle(
            f"Orquestrador • Teste {VERSION}"
            if self.config.test_mode
            else f"Orquestrador • {VERSION}"
        )
        self.resize(1400, 850)
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.build_panel()
        self.build_routines()
        self.build_settings()
        self.build_history()
        self.build_maintenance()
        from .dev_gui import DevPanel

        self.dev_panel = DevPanel(paths, self)
        self.tabs.addTab(self.dev_panel, "Dev • Internos")
        if self.config.test_mode:
            banner = QLabel(f"TESTE ISOLADO • {self.paths.root}")
            banner.setToolTip(str(self.paths.root))
            banner.setMaximumWidth(750)
            self.statusBar().addPermanentWidget(banner)
        self.tray = QSystemTrayIcon(
            self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon), self
        )
        menu = QMenu()
        show = QAction("Abrir Orquestrador", self)
        show.triggered.connect(self.showNormal)
        menu.addAction(show)
        quit_action = QAction("Sair da interface", self)
        quit_action.triggered.connect(self.explicit_exit)
        menu.addAction(quit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda _: self.showNormal())
        self.last_notification_run = ""
        self.vpn_notices: list[VpnNotice] = []
        self.tray.messageClicked.connect(self.notification_detail)
        self.tray.show()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1500)
        self.refresh()

    def build_panel(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        title = QLabel("Acompanhamento das extrações")
        title.setStyleSheet("font-size:24px; font-weight:600; color:#00338D")
        layout.addWidget(title)
        self.timezone = QLabel()
        layout.addWidget(self.timezone)
        self.panel = QTableWidget(0, 11)
        self.panel.setHorizontalHeaderLabels(
            [
                "Rotina",
                "Habilitada",
                "Estado/etapa",
                "Última tentativa",
                "Último sucesso",
                "Dados",
                "Próxima execução",
                "Duração (s)",
                "Tentativas",
                "Pendência/ação",
                "Execução",
            ]
        )
        self.panel.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.panel.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.panel.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.panel)
        actions = QHBoxLayout()
        button("Executar lote", lambda: self.start_run(), actions)
        button("Executar rotina", lambda: self.start_run(selected=True), actions)
        button("Forçar rotina", lambda: self.start_run(selected=True, force=True), actions)
        button("Simular lote", lambda: self.start_run(simulate=True), actions)
        button("Testar login", lambda: self.start_run(selected=True, login=True), actions)
        layout.addLayout(actions)
        controls = QHBoxLayout()
        self.pause_schedule = button("Pausar/retomar agendamento", self.toggle_schedule, controls)
        button("Pausar execução", lambda: self.control("pause"), controls)
        button("Retomar execução", lambda: self.control("resume"), controls)
        button("Cancelar rotina", lambda: self.control("cancel"), controls)
        button("Cancelar lote", lambda: self.control("cancel", batch=True), controls)
        layout.addLayout(controls)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        layout.addWidget(self.progress)
        self.status_label = QLabel("Pronto")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(190)
        layout.addWidget(self.log)
        self.tabs.addTab(page, "Painel")

    def build_routines(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.routines = QTableWidget(0, 6)
        self.routines.setHorizontalHeaderLabels(
            ["Rotina", "Frequência", "Horários próprios", "Dias", "Ordem", "Origem"]
        )
        self.routines.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        self.routines.cellDoubleClicked.connect(lambda row, _: self.edit_routine(row))
        layout.addWidget(self.routines)
        actions = QHBoxLayout()
        button("Editar selecionada", lambda: self.edit_routine(self.routines.currentRow()), actions)
        button("Descobrir extratores…", self.discover_jobs, actions)
        button("Cadastrar script…", self.register_script, actions)
        button("Publicar arquivo local…", self.local_file, actions)
        layout.addLayout(actions)
        layout.addWidget(
            QLabel(
                "Rotinas descobertas começam desabilitadas. Um script alterado exige nova autorização por hash. O lote manual respeita ordem e dependências."
            )
        )
        self.tabs.addTab(page, "Rotinas e agendamentos")

    def build_settings(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.settings_json = QPlainTextEdit(json_view(to_dict(self.config)))
        layout.addWidget(
            QLabel(
                "Configuração completa • campos de máquina, caminhos, URLs, histórico, retries, notificações e retenção. Use Editar rotina para os controles guiados."
            )
        )
        layout.addWidget(self.settings_json)
        actions = QHBoxLayout()
        button("Validar e salvar", self.save_settings, actions)
        button("Exportar preferências sem segredos…", self.export_settings, actions)
        button("Importar com prévia…", self.import_settings, actions)
        button("Instalação e atualização…", self.installation, actions)
        layout.addLayout(actions)
        paths_form = QFormLayout()
        self.path_key = QComboBox()
        for key in ("profile", "driver", "downloads", "logs", "install_root"):
            self.path_key.addItem(key)
        paths_form.addRow("Selecionar caminho", self.path_key)
        button("Escolher e aplicar caminho…", self.choose_setting_path, paths_form)
        layout.addLayout(paths_form)
        layout.addWidget(
            QLabel(
                "Console oculto refere-se a subprocessos internos. Minimizar mantém a interface. Headless controla somente a janela do navegador. SSO/MFA não é convertido em serviço Windows."
            )
        )
        self.tabs.addTab(page, "Configurações")

    def build_history(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        filters = QHBoxLayout()
        self.filter_job = QLineEdit()
        self.filter_job.setPlaceholderText("ID da rotina; vazio = todas")
        self.filter_status = QComboBox()
        self.filter_status.addItem("Todos", "")
        for code, label in STATUS.items():
            self.filter_status.addItem(label, code)
        filters.addWidget(self.filter_job)
        filters.addWidget(self.filter_status)
        button("Filtrar", self.refresh_history, filters)
        button("Exportar diagnóstico sanitizado…", self.export_history, filters)
        layout.addLayout(filters)
        self.history = QTableWidget(0, 8)
        self.history.setHorizontalHeaderLabels(
            ["Início", "Rotina", "Estado", "Modo", "Categoria", "Lote", "Execução", "Etapa"]
        )
        self.history.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        self.history.cellDoubleClicked.connect(lambda row, _: self.history_detail(row))
        layout.addWidget(self.history)
        self.tabs.addTab(page, "Histórico e logs")

    def build_maintenance(self) -> None:
        page = QWidget()
        layout = QVBoxLayout(page)
        actions = QHBoxLayout()
        button(
            "Diagnosticar EdgeDriver",
            lambda: self.background(lambda: diagnose(self.paths, self.config)),
            actions,
        )
        button(
            "Reparar EdgeDriver",
            lambda: self.background(lambda: diagnose(self.paths, self.config, repair=True)),
            actions,
        )
        button("Testar conectividade", self.connectivity, actions)
        layout.addLayout(actions)
        tasks = QHBoxLayout()
        button("Conferir tarefas", self.task_diff, tasks)
        button("Instalar/atualizar tarefa", self.install_task, tasks)
        button(
            "Remover tarefa própria",
            lambda: self.background(lambda: WindowsTasks(self.paths).remove()),
            tasks,
        )
        layout.addLayout(tasks)
        layout.addWidget(
            QLabel(
                "Backups de relatórios • restaurar preserva a versão atual e não registra nova extração."
            )
        )
        self.backups = QTableWidget(0, 5)
        self.backups.setHorizontalHeaderLabels(["Data", "Arquivo", "Tamanho", "SHA-256", "Versão"])
        self.backups.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        layout.addWidget(self.backups)
        controls = QHBoxLayout()
        button("Atualizar lista", self.refresh_backups, controls)
        button("Validar selecionado", self.validate_backup, controls)
        button("Restaurar selecionado", self.restore_backup, controls)
        button("Backup do aplicativo", self.backup_application, controls)
        button("Reverter atualização…", self.rollback_application, controls)
        layout.addLayout(controls)
        button("Desinstalar componentes próprios e preservar dados…", self.uninstall, layout)
        self.tabs.addTab(page, "Diagnóstico e manutenção")

    def selected_id(self) -> str:
        row = self.panel.currentRow()
        item = self.panel.item(row, 0)
        if row < 0 or item is None:
            raise ValueError("Selecione uma rotina no Painel.")
        return str(item.data(Qt.ItemDataRole.UserRole))

    def background(self, callback: Callable[[], Any], details: bool = True) -> None:
        if self.task and self.task.isRunning():
            QMessageBox.information(
                self, "Operação em andamento", "Acompanhe a operação atual antes de iniciar outra."
            )
            return
        self.task = Task(callback, self)
        self.task.done.connect(lambda value: self.task_done(value, details))
        self.task.failed.connect(lambda error: self.task_error(error))
        self.task.start()

    def task_done(self, value: Any, details: bool) -> None:
        self.refresh()
        self.settings_json.setPlainText(json_view(to_dict(load(self.paths))))
        if details:
            show_detail(self, "Resultado da operação", value)

    def task_error(self, error: str) -> None:
        self.status_label.setText(error)
        QMessageBox.warning(self, "Operação não concluída", error)
        self.refresh()

    def start_run(self, selected: bool = False, **options: Any) -> None:
        try:
            names = [self.selected_id()] if selected else None
            self.background(
                lambda: Engine(self.paths).run(names, **options),
                details=options.get("simulate", False),
            )
        except Exception as exc:
            self.task_error(str(exc))

    def control(self, value: str, batch: bool = False) -> None:
        active = [r for r in self.store.history() if r["status"] == "running"]
        for run in active:
            self.store.control(run["id"], value)
            if value == "cancel" and batch:
                self.store.control("batch:" + run["batch"], "cancel")
        self.status_label.setText(
            {
                "pause": "Pausa solicitada: será aplicada no próximo checkpoint seguro; publicações não são suspensas.",
                "resume": "Retomada solicitada: pré-condições serão verificadas no checkpoint.",
                "cancel": "Cancelamento solicitado; subprocessos próprios serão encerrados após o prazo cooperativo.",
            }[value]
        )

    def write_config(self, config: Config) -> None:
        if self.config.test_mode and not config.test_mode:
            raise ValueError("O modo de teste isolado não pode ser desativado nesta instalação.")
        with Lock(self.paths.maintenance_lock), Lock(self.paths.root / "state/config.lock"):
            save(self.paths, config)
        self.config = config
        self.settings_json.setPlainText(json_view(to_dict(config)))

    def toggle_schedule(self) -> None:
        config = load(self.paths)
        config.scheduling_paused = not config.scheduling_paused
        self.write_config(config)
        self.refresh()

    def edit_routine(self, row: int) -> None:
        if row < 0:
            return
        config = load(self.paths)
        dialog = RoutineDialog(config, config.routines[row], self)
        if dialog.exec():
            config.routines[row] = dialog.updated
            self.write_config(config)
            self.refresh()

    def save_settings(self) -> None:
        try:
            candidate = from_dict(json.loads(self.settings_json.toPlainText()))
            self.write_config(candidate)
            self.refresh()
        except Exception as exc:
            self.task_error(str(exc))

    def choose_setting_path(self) -> None:
        key = self.path_key.currentText()
        value = (
            QFileDialog.getOpenFileName(
                self, "Selecionar executável do driver", "", "Executáveis (*.exe)"
            )[0]
            if key == "driver"
            else QFileDialog.getExistingDirectory(self, "Selecionar pasta")
        )
        if value:
            data = json.loads(self.settings_json.toPlainText())
            data[key] = value
            self.settings_json.setPlainText(json_view(data))

    def export_settings(self) -> None:
        filename = QFileDialog.getSaveFileName(
            self, "Exportar preferências", "preferencias.json", "JSON (*.json)"
        )[0]
        if filename:
            atomic_json(Path(filename), portable(load(self.paths)))

    def import_settings(self) -> None:
        filename = QFileDialog.getOpenFileName(self, "Importar preferências", "", "JSON (*.json)")[
            0
        ]
        if not filename:
            return
        try:
            candidate, changes = import_preview(load(self.paths), read_json(Path(filename)))
            show_detail(self, "Prévia das alterações", changes)
            if (
                QMessageBox.question(self, "Aplicar importação", "Aplicar as alterações exibidas?")
                == QMessageBox.StandardButton.Yes
            ):
                self.write_config(candidate)
        except Exception as exc:
            self.task_error(str(exc))

    def discover_jobs(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Localizar extratores adicionais")
        if folder:
            config = load(self.paths)
            additions = discover(config, Path(folder))
            show_detail(
                self,
                "Extratores encontrados; desabilitados até autorização",
                [dataclasses.asdict(j) for j in additions],
            )
            config.routines.extend(additions)
            self.write_config(config)

    def register_script(self) -> None:
        filename = QFileDialog.getOpenFileName(
            self, "Cadastrar extrator Python", "", "Python (*.py)"
        )[0]
        if filename:
            config = load(self.paths)
            script = Path(filename)
            job = Routine(
                id=script.stem,
                label=script.stem,
                script=str(script),
                enabled=False,
                origin="cadastro manual explícito",
            )
            config.routines.append(job)
            dialog = RoutineDialog(config, job, self)
            if dialog.exec():
                config.routines[-1] = dialog.updated
                self.write_config(config)

    def local_file(self) -> None:
        try:
            name = self.selected_id()
            if name not in {
                "pipefy_clientes_tool_edge",
                "pipefy_eventos_tool_edge",
                "pipefy_procedimentos_tool_edge",
                "pipefy_status_atms_tool_edge",
            }:
                raise ValueError(
                    "Publicação local disponível para Clientes, Eventos, Procedimentos e ATMS."
                )
            filename = QFileDialog.getOpenFileName(
                self, "Publicar/mesclar arquivo local", "", "Excel (*.xlsx)"
            )[0]
            if filename:
                self.background(lambda: Engine(self.paths).run([name], source=Path(filename)))
        except Exception as exc:
            self.task_error(str(exc))

    def refresh_history(self) -> None:
        rows = self.store.history(
            job=self.filter_job.text().strip(), status=self.filter_status.currentData()
        )
        self.history.setRowCount(len(rows))
        for index, row in enumerate(rows):
            for column, key in enumerate(
                ("started", "job", "status", "mode", "category", "batch", "id", "stage")
            ):
                self.history.setItem(index, column, QTableWidgetItem(str(row.get(key) or "")))

    def history_detail(self, row: int) -> None:
        if row >= 0:
            item = self.history.item(row, 6)
            if item is None:
                return
            run = item.text()
            show_detail(self, "Detalhes locais da execução", self.store.details(run))

    def export_history(self) -> None:
        filename = QFileDialog.getSaveFileName(
            self, "Exportar diagnóstico sem endpoints/segredos", "diagnostico.json", "JSON (*.json)"
        )[0]
        if filename:
            self.background(lambda: self.store.export(Path(filename)))

    def refresh_backups(self) -> None:
        publisher = Publisher(self.paths.root / "backups/reports", self.config.retention)
        records = publisher.versions()
        self.backups.setRowCount(len(records))
        for row, record in enumerate(records):
            for column, key in enumerate(("at", "target", "size", "sha256", "id")):
                self.backups.setItem(row, column, QTableWidgetItem(str(record[key])))

    def selected_backup(self) -> str:
        row = self.backups.currentRow()
        if row < 0:
            raise ValueError("Selecione uma versão de relatório.")
        item = self.backups.item(row, 4)
        if item is None:
            raise ValueError("Versão inválida.")
        return item.text()

    def validate_backup(self) -> None:
        try:
            identifier = self.selected_backup()
            publisher = Publisher(self.paths.root / "backups/reports", self.config.retention)
            record = next(r for r in publisher.versions() if r["id"] == identifier)
            self.background(lambda: {"valid": str(publisher.validate_version(record))})
        except Exception as exc:
            self.task_error(str(exc))

    def restore_backup(self) -> None:
        try:
            identifier = self.selected_backup()
            if (
                QMessageBox.question(
                    self,
                    "Restaurar relatório",
                    "Restaurar esta versão, criando antes um backup do arquivo atual?",
                )
                != QMessageBox.StandardButton.Yes
            ):
                return

            def restore() -> Any:
                with Lock(self.paths.lock):
                    run = self.store.begin("restore", "report", "restore", None)
                    try:
                        result = Publisher(
                            self.paths.root / "backups/reports", self.config.retention
                        ).restore(identifier, run)
                        self.store.event(run, "restore", result)
                        self.store.finish(run, "success", 0)
                        return result
                    except Exception as exc:
                        self.store.finish(run, "failed", 1, evidence=str(exc))
                        raise

            self.background(restore)
        except Exception as exc:
            self.task_error(str(exc))

    def installation(self) -> None:
        if self.task and self.task.isRunning():
            self.task_error("Encerre a execução antes de atualizar o aplicativo.")
            return
        from .native_updates import is_native

        if is_native(self.paths):
            from .native_gui import preferences

            preferences(self)
            return
        wizard = InstallWizard(self.paths, load(self.paths), self)
        if wizard.exec():
            if wizard.paths.root != self.paths.root:
                spawn([str(wizard.installed_executable), "--data-root", str(wizard.paths.root)])
                return
            self.config = load(self.paths)

    def connectivity(self) -> None:
        try:
            job = self.config.job(self.selected_id())
            module = module_for(job)
            url = (
                job.url
                or getattr(module, "LOGIN_URL", None)
                or getattr(module, "DEFAULT_REPORT_URL", None)
                or module.DEFAULT_DATABASE_URL
            )

            def test() -> Any:
                evidence = probe(url, public_pipefy(self.config), self.config.vpn_interfaces)
                return {"category": classify(evidence), "evidence": as_dict(evidence)}

            self.background(test)
        except Exception as exc:
            self.task_error(str(exc))

    def installed_executable(self) -> Path:
        pointer = self.paths.root / "installation.json"
        if not pointer.is_file():
            raise ValueError("Instale o executável pelo wizard antes de gerenciar tarefas reais.")
        current = read_json(pointer)
        return Path(current.get("launcher", current["executable"]))

    def task_diff(self) -> None:
        try:
            executable = self.installed_executable()
            self.background(
                lambda: WindowsTasks(self.paths).differences(
                    executable, os.environ.get("USERNAME", "")
                )
            )
        except Exception as exc:
            self.task_error(str(exc))

    def install_task(self) -> None:
        try:
            executable = self.installed_executable()
            self.background(
                lambda: WindowsTasks(self.paths).install(
                    executable,
                    os.environ.get("USERDOMAIN", "") + "\\" + os.environ.get("USERNAME", ""),
                )
            )
        except Exception as exc:
            self.task_error(str(exc))

    def backup_application(self) -> None:
        def backup() -> Any:
            with Lock(self.paths.lock):
                folder = (
                    self.paths.root
                    / "backups/app"
                    / ("manual-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
                )
                from .native_install import installer_for

                return installer_for(self.paths).snapshot(folder)

        self.background(backup)

    def rollback_application(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Selecionar backup de aplicativo", str(self.paths.root / "backups/app")
        )
        if (
            folder
            and QMessageBox.question(
                self,
                "Reverter aplicativo",
                "Restaurar versão, configuração, estado e tarefa deste backup? A configuração atual será preservada em outro backup.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            from .native_updates import is_native

            if is_native(self.paths):
                from .native_gui import handoff

                handoff(self, backup=Path(folder))
            else:
                self.background(lambda: Installer(self.paths).rollback(Path(folder)))

    def uninstall(self) -> None:
        if (
            QMessageBox.question(
                self,
                "Desinstalar",
                "Remover somente tarefa e atalho próprios? Dados, histórico e backups serão preservados.",
            )
            == QMessageBox.StandardButton.Yes
        ):
            from .native_install import installer_for

            self.background(lambda: installer_for(self.paths).uninstall())

    def refresh(self) -> None:
        try:
            with Lock(self.paths.maintenance_lock):
                self.refresh_unlocked()
            from .native_updates import is_native

            if is_native(self.paths):
                from .native_gui import check_automatically

                check_automatically(self)
        except BusyError:
            self.status_label.setText(
                "Instalação/manutenção em andamento; aguardando liberação dos dados."
            )

    def refresh_unlocked(self) -> None:
        try:
            self.config = load(self.paths)
            rows = Engine(self.paths, self.config).panel()
            self.panel.setRowCount(len(rows))
            active = False
            for row, record in enumerate(rows):
                last = record["last"]
                running = last.get("status") == "running"
                active |= running
                success = record["last_success"]
                error = last.get("category") or ""
                values = [
                    record["label"],
                    "Sim" if record["enabled"] else "Não",
                    last.get("stage") if running else STATUS.get(last.get("status"), "Pronta"),
                    last.get("started", "Nunca"),
                    success["at"] if success else "Nunca",
                    record["freshness"]
                    + ("\n" + record["data_updated"] if record["data_updated"] else ""),
                    record["next"],
                    last.get("duration") or "",
                    last.get("attempt", ""),
                    error,
                    last.get("id", ""),
                ]
                for column, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    if column == 0:
                        item.setData(Qt.ItemDataRole.UserRole, record["id"])
                    self.panel.setItem(row, column, item)
            self.progress.setRange(0, 0 if active else 1)
            self.timezone.setText(
                f"Fuso local: {local_now().tzinfo} • Agendamento {'pausado' if self.config.scheduling_paused else 'ativo'} • Execuções serializadas no perfil compartilhado"
            )
            self.routines.setRowCount(len(self.config.routines))
            for row, job in enumerate(self.config.routines):
                for column, value in enumerate(
                    (
                        job.label,
                        job.schedule.frequency,
                        ", ".join(job.schedule.times),
                        str(job.schedule.days),
                        str(job.order),
                        job.origin,
                    )
                ):
                    self.routines.setItem(row, column, QTableWidgetItem(value))
            self.refresh_history()
            self.refresh_backups()
            self.deliver_notifications()
            row = self.panel.currentRow()
            if row >= 0:
                log_item = self.panel.item(row, 10)
                log_path = (
                    Path(self.config.logs) / (log_item.text() + ".process.log")
                    if log_item and log_item.text()
                    else None
                )
                if log_path and log_path.is_file():
                    with log_path.open("rb") as stream:
                        stream.seek(max(0, log_path.stat().st_size - 12000))
                        self.log.setPlainText(stream.read().decode("utf-8", errors="replace"))
        except Exception as exc:
            self.status_label.setText(str(exc))

    def deliver_notifications(self) -> None:
        with self.store.connect() as db:
            rows = list(
                db.execute("SELECT * FROM notifications WHERE delivered=0 ORDER BY at LIMIT 2")
            )
            for row in rows:
                claimed = db.execute(
                    "UPDATE notifications SET delivered=1 WHERE id=? AND delivered=0", (row["id"],)
                )
                if not claimed.rowcount:
                    continue
                self.last_notification_run = row["run"] or ""
                self.tray.showMessage(
                    "Orquestrador", row["message"], QSystemTrayIcon.MessageIcon.Information, 15000
                )
                if row["kind"] == "vpn":
                    QApplication.alert(self, 15000)
                    self.vpn_notices.append(VpnNotice(self.store, row["run"], row["message"], self))

    def notification_detail(self) -> None:
        self.showNormal()
        if self.last_notification_run:
            show_detail(self, "Detalhe da execução", self.store.details(self.last_notification_run))

    def explicit_exit(self) -> None:
        if (
            (self.task and self.task.isRunning())
            or (self.update_task and self.update_task.isRunning())
            or (self.dev_panel.task and self.dev_panel.task.isRunning())
            or any(r["status"] == "running" for r in self.store.history())
        ):
            QMessageBox.information(
                self,
                "Execução em andamento",
                "Use Cancelar e aguarde o encerramento controlado, ou minimize para manter a execução.",
            )
            self.hide()
            return
        self.exit_requested = True
        self.close()

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.exit_requested:
            self.timer.stop()
            self.dev_panel.shutdown()
            self.tray.hide()
            event.accept()
            QApplication.quit()
            return
        self.hide()
        self.tray.showMessage(
            "Orquestrador",
            "Interface minimizada. A execução e o monitor continuam ativos. Use Sair da interface para encerrar.",
        )
        event.ignore()


def launch(paths: Paths, run_detail: str = "") -> int:
    existing_app = QApplication.instance()
    if existing_app is not None and not isinstance(existing_app, QApplication):
        raise RuntimeError("A interface exige uma instância QApplication.")
    app = existing_app if existing_app is not None else QApplication(sys.argv[:1])
    app.setApplicationName("Orquestrador")
    app.setOrganizationName("Orquestrador")
    app.setStyle("Fusion")
    app.setStyleSheet("""
        QMainWindow, QWizard, QDialog { background: #F3F6FA; }
        QLabel { color: #243746; }
        QTabWidget::pane { border: 1px solid #D8E1EC; background: white; }
        QTabBar::tab { padding: 11px 18px; background: #E6EDF6; color: #00338D; }
        QTabBar::tab:selected { background: #FFFFFF; font-weight: 600; }
        QPushButton { padding: 8px 13px; background: #005EB8; color: white; border: none; border-radius: 3px; }
        QPushButton:hover { background: #00338D; }
        QPushButton:disabled { background: #A5B6C9; }
        QLineEdit, QPlainTextEdit, QComboBox, QSpinBox { background: white; padding: 5px; border: 1px solid #C6D1DE; }
        QTableWidget { background: white; alternate-background-color: #F3F6FA; gridline-color: #E2E8F0; }
        QHeaderView::section { background: #EDF2F8; padding: 7px; border: none; color: #00338D; font-weight: 600; }
    """)
    paths.ensure()
    from .native_updates import is_native

    native = is_native(paths)
    installer = Installer(paths)
    recovery = "" if native else installer.recover()
    if recovery:
        QMessageBox.information(None, "Recuperação de instalação", recovery)
    current = read_json(installer.pointer) if installer.pointer.is_file() else None
    if not paths.config.is_file() or (
        not native
        and getattr(sys, "frozen", False)
        and (not current or current.get("version") != VERSION)
    ):
        wizard = InstallWizard(paths, load(paths) if paths.config.is_file() else None)
        if not wizard.exec():
            return 3
        paths = wizard.paths
        from .__main__ import configure_logging

        logging_root = paths.root / "logs"
        logging_root.mkdir(parents=True, exist_ok=True)
        configure_logging(paths)
        from .runtime import capture_windowed_streams

        capture_windowed_streams(logging_root)
    window = MainWindow(paths)
    if window.config.test_mode:
        window.tabs.setCurrentWidget(window.dev_panel)
    window.show()
    if run_detail:
        show_detail(window, "Detalhe da execução", Store(paths.database).details(run_detail))
    return app.exec()

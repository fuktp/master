from __future__ import annotations

import hashlib
import os
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from .paths import Paths

NS = "http://schemas.microsoft.com/windows/2004/02/mit/task"
ET.register_namespace("", NS)


def task_name(paths: Paths) -> str:
    key = hashlib.sha256(str(paths.root.resolve()).encode()).hexdigest()[:12]
    if (paths.root / "instalacao-teste.json").is_file():
        return rf"\Orquestrador-Teste-{key}"
    return rf"\Orquestrador-{key}"


def xml(executable: Path, paths: Paths, user: str) -> str:
    root = ET.Element(f"{{{NS}}}Task", version="1.2")

    def element(parent: ET.Element, name: str, text: str | None = None, **attrs: str) -> ET.Element:
        node = ET.SubElement(parent, f"{{{NS}}}{name}", attrs)
        node.text = text
        return node

    registration = element(root, "RegistrationInfo")
    element(registration, "Author", "Orquestrador")
    element(registration, "URI", task_name(paths))
    element(
        registration,
        "Description",
        "Monitor do Orquestrador; horários próprios e notificações na sessão do usuário.",
    )
    triggers = element(root, "Triggers")
    logon = element(triggers, "LogonTrigger")
    element(logon, "Enabled", "true")
    element(logon, "UserId", user)
    calendar = element(triggers, "CalendarTrigger")
    repetition = element(calendar, "Repetition")
    element(repetition, "Interval", "PT1M")
    element(repetition, "Duration", "P1D")
    element(repetition, "StopAtDurationEnd", "false")
    element(calendar, "StartBoundary", "2026-01-01T00:00:00")
    element(calendar, "Enabled", "true")
    days = element(calendar, "ScheduleByDay")
    element(days, "DaysInterval", "1")
    principals = element(root, "Principals")
    principal = element(principals, "Principal", id="Author")
    element(principal, "UserId", user)
    element(principal, "LogonType", "InteractiveToken")
    element(principal, "RunLevel", "LeastPrivilege")
    settings = element(root, "Settings")
    for key, value in {
        "MultipleInstancesPolicy": "IgnoreNew",
        "DisallowStartIfOnBatteries": "false",
        "StopIfGoingOnBatteries": "false",
        "StartWhenAvailable": "true",
        "RunOnlyIfNetworkAvailable": "false",
        "Enabled": "true",
        "ExecutionTimeLimit": "PT0S",
        "Priority": "7",
    }.items():
        element(settings, key, value)
    actions = element(root, "Actions", Context="Author")
    action = element(actions, "Exec")
    native = executable.suffix.casefold() == ".vbs"
    native_host = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32/wscript.exe")
    element(action, "Command", native_host if native else str(executable))
    element(
        action,
        "Arguments",
        subprocess.list2cmdline(
            ["//B", "//Nologo", str(executable), "--agent"]
            if native
            else ["--data-root", str(paths.root), "--agent"]
        ),
    )
    element(action, "WorkingDirectory", str(executable.parent))
    return '<?xml version="1.0" encoding="UTF-16"?>\n' + ET.tostring(root, encoding="unicode")


class WindowsTasks:
    def __init__(self, paths: Paths):
        self.paths = paths

    def _call(self, *arguments: str, check: bool = True) -> subprocess.CompletedProcess[str]:
        if os.name != "nt":
            raise RuntimeError("Agendador real disponível somente no Windows.")
        result = subprocess.run(
            ["schtasks.exe", *arguments],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=30,
            creationflags=0x08000000,
        )
        if check and result.returncode:
            raise RuntimeError("Falha no Agendador do Windows: " + result.stdout + result.stderr)
        return result

    def export(self, name: str | None = None) -> str | None:
        result = self._call("/Query", "/TN", name or task_name(self.paths), "/XML", check=False)
        if result.returncode:
            return None
        return result.stdout

    def owned(self, value: str) -> bool:
        root = ET.fromstring(value)
        return root.findtext(f"{{{NS}}}RegistrationInfo/{{{NS}}}URI") == task_name(self.paths)

    def register_xml(self, value: str, name: str | None = None) -> None:
        if name is None and not self.owned(value):
            raise ValueError("XML não pertence a este produto/instalação.")
        path = self.paths.root / "cache/task.xml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding="utf-16")
        try:
            self._call("/Create", "/TN", name or task_name(self.paths), "/XML", str(path), "/F")
        finally:
            path.unlink(missing_ok=True)

    def install(self, executable: Path, user: str) -> None:
        current = self.export()
        if current and not self.owned(current):
            raise ValueError("Nome de tarefa em conflito; tarefa externa preservada.")
        value = xml(executable, self.paths, user)
        if current != value:
            self.register_xml(value)

    def remove(self) -> None:
        current = self.export()
        if current:
            if not self.owned(current):
                raise ValueError("Recusa de remover tarefa externa.")
            self._call("/Delete", "/TN", task_name(self.paths), "/F")

    def start(self) -> None:
        self._call("/Run", "/TN", task_name(self.paths))

    def legacy(self, config_path: str) -> dict[str, str]:
        if not config_path:
            return {}
        if os.name != "nt":
            raise RuntimeError("Inventário de tarefas legadas requer Windows.")
        import win32com.client

        service = win32com.client.Dispatch("Schedule.Service")
        service.Connect()
        folder = service.GetFolder("\\")
        matches = {}
        for task in folder.GetTasks(1):
            value = str(task.Xml)
            tree = ET.fromstring(value)
            arguments = tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Arguments") or ""
            if (
                str(task.Name).startswith("Pipefy_Orquestrador-")
                and config_path.casefold() in arguments.casefold()
                and "pipefy_orchestrator.py" in arguments.casefold()
            ):
                matches[str(task.Path)] = value
        return matches

    def disable_legacy(self, name: str, original: str) -> None:
        if (
            not name.startswith("\\Pipefy_Orquestrador-")
            or "pipefy_orchestrator.py" not in original
        ):
            raise ValueError("Tarefa não reconhecida como legado revisado.")
        self._call("/Change", "/TN", name, "/Disable")

    def differences(self, executable: Path, user: str) -> dict[str, Any]:
        actual = self.export()
        expected = xml(executable, self.paths, user)
        if not actual:
            return {"installed": False, "matches": False}
        tree = ET.fromstring(actual)
        command = tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Command")
        arguments = tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Arguments")
        expected_tree = ET.fromstring(expected)
        matches = (
            self.owned(actual)
            and command == expected_tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Command")
            and arguments
            == expected_tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Arguments")
        )
        return {"installed": True, "matches": matches, "actual": actual, "expected": expected}

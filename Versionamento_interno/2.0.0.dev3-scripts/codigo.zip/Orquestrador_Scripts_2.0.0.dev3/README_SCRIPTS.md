# Orquestrador 2.0.0.dev3 — instalação por scripts nativos

Edição de teste isolada, com distribuição offline em ZIP, wizard PowerShell/WinForms e aplicativo operacional PySide6. O painel **Dev • Internos** e os cinco extratores (Clientes, Eventos, Procedimentos, KWMS e ATMS) foram preservados.

## Abrir e instalar

1. Extraia **todo** o ZIP para uma pasta local.
2. Abra **Instalar.vbs** para iniciar o wizard sem console, quando o Windows Script Host estiver disponível e autorizado. **Instalar.bat** é uma alternativa; o CMD pode aparecer brevemente antes de iniciar o PowerShell oculto.
3. Escolha uma pasta vazia exclusiva do teste, confira os destinos e horários e aplique a instalação. Ao concluir, abra o aplicativo pelo wizard ou pelo atalho **Orquestrador - Teste** na Área de Trabalho ou no Menu Iniciar.

Não abra scripts diretamente dentro da visualização de pasta compactada. Não é necessário instalar Python, pip ou executar comandos. Não se solicita elevação administrativa. A escrita e o registro de tarefas continuam dependendo das permissões efetivas do usuário.

O wizard tem oito etapas: diagnóstico; local; identidade/OneDrive; destinos; rotinas e horários; validação offline; revisão; aplicação e verificação final. Campos inválidos são recusados pelo mesmo núcleo de configuração do aplicativo. Dependências, retries, perfil do Edge e opções avançadas continuam disponíveis na interface operacional. ATMS permanece desabilitado até habilitação explícita. Novas instalações começam com o agendamento pausado; em atualizações preserva-se o estado anterior.

## Runtime privado e segurança do Windows

O pacote não contém **Orquestrador.exe** nem um instalador compilado do produto. Inclui **python.exe/pythonw.exe oficiais e DLLs internas** do runtime CPython, além dos componentes necessários à automação. Eliminar também esses executáveis exigiria substituir o núcleo Python, o que não foi feito.

O runtime privado é CPython 3.13.16, com bibliotecas fixadas e hashes registrados em build_inputs/windows-x64.json. A distribuição embutida é instalada junto do aplicativo; não utiliza o Python global nem cria um venv a partir de um Python inexistente. A Python Software Foundation recomenda empacotar dependências junto dessa distribuição, em vez de tratá-la como uma instalação Python convencional administrada por pip.

`-ExecutionPolicy Bypass` é usado somente no processo do lançador, conforme solicitado. Não se altera política persistente, não se executa Unblock-File e não se modifica Defender, SmartScreen, AppLocker ou App Control. **Scripts também podem ser bloqueados. Trocar o EXE por scripts não garante liberação do SmartScreen ou de políticas corporativas.** Se a máquina exigir assinatura, os scripts também precisam de assinatura e/ou autorização da TI. Não há certificado de assinatura próprio nesta entrega.

VBScript é um recurso em descontinuação no Windows. O lançador depende de Windows Script Host/VBScript habilitados. Nenhum recurso do Windows é habilitado automaticamente. A alternativa BAT pode exibir uma janela transitória; não há evidência de ausência visual de console em Windows nesta sessão.

Hashes verificam integridade do pacote e dos backups; eles não autenticam, por si sós, a identidade de quem publicou o ZIP.

## Dados e preservação

Tudo do ambiente operacional permanece na pasta escolhida: config.json; state; logs; downloads; cache; profiles; relatorios; extras; backups; app/versions; launch; versionamento. Apenas o localizador da última instalação de teste e os logs do bootstrap ficam em LOCALAPPDATA/Orquestrador-Teste. Atalhos usam as pastas conhecidas do Windows, incluindo Área de Trabalho redirecionada para OneDrive.

A instalação recusa diretórios não vazios de outra origem. Uma instalação de teste anterior reconhecida pode ser atualizada, com backup. A configuração e o último sucesso são preservados; os scripts adicionais ficam em extras e não são substituídos pelo pacote. Os extratores originais foram preservados byte a byte. Caminhos legados existentes dentro desses scripts são substituídos pelos argumentos gerenciados do adaptador; a instalação nativa não adota os caminhos pessoais do JSON legado. Publicação e histórico continuam usando validação, locks e backups do núcleo anterior.

## Atualização, reparo e rollback

Em **Configurações > Instalação e atualização**, há acesso ao wizard, ao ZIP local e ao feed opcional. A aplicação fecha antes da manutenção. Update.ps1 recebe PID e instante de criação do processo, espera seu encerramento e abre a interface de atualização. Não encerra processos alheios nem força o fechamento do aplicativo em caso de timeout.

Cada revisão é copiada para outra pasta em app/versions. Antes da ativação, o núcleo cria backup verificável da versão anterior, configuração, banco SQLite, scripts adicionais, tarefa e atalhos. Executa health checks offline antes e depois de ativar o ponteiro installation.json. Falhas internas acionam restauração automática. Falhas externas de VPN/SSO/servidor não são usadas para reprovar uma atualização. O atalho volta a abrir a versão indicada pelo ponteiro.

O diário state/native-transaction.json permite detectar interrupções. O lançador tenta recuperar a transação antes de abrir o aplicativo. O payload original deve permanecer disponível até concluir a instalação; se houver dano ao próprio runtime de recuperação, extraia novamente um ZIP íntegro e execute o wizard. Rollback incompleto é mostrado como erro e o backup é mantido; não há repetição automática em ciclo.

Reparo revalida e instala uma cópia da versão em outro diretório. Cancelar durante a aplicação solicita cancelamento cooperativo em checkpoints; aguarde a reversão terminar. Backup de aplicação e backup de relatório são recursos distintos. Desinstalação remove tarefa, atalhos e ativação próprios, preservando os dados e as versões para recuperação por padrão.

## Feed opcional de atualização

Nenhum servidor foi inventado ou pré-configurado. O feed começa desativado. Informe na interface um endereço HTTPS interno com acesso de leitura adequado, sem credenciais na URL. A interface pode verificar e baixar a cada quatro horas; pede confirmação para fechar e atualizar. A verificação do feed opera enquanto a interface está aberta. O monitor de horários continua independente dela.

Contrato do documento JSON servido no endereço escolhido:

```json
{
  "owner": "orquestrador-native-package-v1",
  "version": "2.0.0.dev4",
  "package_url": "<endereço HTTPS real do ZIP completo no mesmo servidor>",
  "sha256": "<SHA-256 real do ZIP publicado>"
}
```

O exemplo define o contrato novo; não representa um servidor existente nem uma versão distribuída. O servidor deve oferecer o ZIP completo desta distribuição. Não são seguidos redirecionamentos; não se desabilita verificação TLS. Downloads incompletos e hashes divergentes são recusados. O pacote passa por limites de tamanho, validação de caminhos, versão e manifesto antes da execução de seus scripts internos. A confiança da origem depende do servidor HTTPS configurado e das políticas da organização. Não foi implementado login interativo para o feed.

## Evidências e limites desta revisão

Consulte MATRIZ_SCRIPTS.md e docs/evidencias/native-* na entrega técnica. Testes Python usam diretórios temporários, rede bloqueada e adaptadores falsos para tarefas e atalhos. A sintaxe PowerShell e as funções portáveis foram exercitadas com PowerShell 7 em Linux.

**Não homologado em Windows real:** wizard WinForms, scripts por duplo clique, atalhos/ícone, ausência visual de console, Windows sem Python global, Agendador, atualização e rollback completos pelo ZIP, SmartScreen, SSO/MFA, VPN, Excel e downloads corporativos. Nenhum desses resultados é inferido dos testes Linux. Não há benchmark Windows desta revisão.

Referências: https://learn.microsoft.com/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-5.1 ; https://docs.python.org/3.13/using/windows.html#the-embeddable-package ; https://techcommunity.microsoft.com/blog/windows-itpro-blog/vbscript-deprecation-timelines-and-next-steps/4148301 .

## Build técnico

Esta seção é destinada ao desenvolvimento, não ao usuário final.

```text
uv sync --frozen
uv run python tools/prepare_windows_payload.py --output build/runtime-windows --cache build/downloads
uv run python tools/build_native_zip.py --runtime build/runtime-windows --output build/native-distribution
uv run pytest
uv run ruff check orquestrador_app desktop_tests tools desktop_entry.py
uv run ruff format --check orquestrador_app desktop_tests tools desktop_entry.py
uv run mypy --platform win32
pwsh -NoProfile -File tools/test_native_powershell.ps1
```

O build lê dependências PE do Qt sem executar binários Windows e inclui os módulos/plugins necessários à interface. Também exclui ferramentas de build e testes das dependências distribuídas. A montagem é realizada em Python e gera um ZIP; o produto não passa por compilação em um executável personalizado. Nenhum comando Git é necessário. O versionamento desta revisão usa snapshots e SHA-256.

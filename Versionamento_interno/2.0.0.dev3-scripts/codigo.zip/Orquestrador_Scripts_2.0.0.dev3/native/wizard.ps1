﻿param(
    [string]$PackageRoot = '',
    [string]$DataRoot = '',
    [int]$OwnerPid = 0,
    [double]$OwnerStarted = 0,
    [string]$Backup = '',
    [switch]$AutoUpdate
)
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    . (Join-Path $PSScriptRoot 'Native.Common.ps1')
    Wait-OwnedParent $OwnerPid $OwnerStarted
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Este pacote exige Windows x64.' }
    if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') { throw 'A política deste computador restringe WinForms/PowerShell. Solicite avaliação da TI.' }
    $script:payload = Get-NativePayload $PackageRoot $PSScriptRoot
    $script:release = Read-NativeJson (Join-Path $script:payload 'release.json')
    if ($script:release.owner -ne 'orquestrador-native-package-v1') { throw 'Pacote não reconhecido.' }
    if (-not $DataRoot) {
        $DataRoot = Join-Path $env:LOCALAPPDATA 'Orquestrador-Teste\Ambiente-Scripts'
        $locator = Join-Path $env:LOCALAPPDATA 'Orquestrador-Teste\ultima-instalacao.json'
        if (Test-Path -LiteralPath $locator) {
            $remembered = Read-NativeJson $locator
            if ((Test-Path -LiteralPath (Join-Path $remembered.root 'instalacao-teste.json'))) { $DataRoot = $remembered.root }
        }
    }
    $script:job = $null
    $script:jobAction = ''
    $script:config = $null
    $script:pageIndex = 0
    $script:completed = $false
    $script:exitCode = 3
    $script:cancelPending = $false
    $script:pages = New-Object 'Collections.Generic.List[System.Windows.Forms.Panel]'
    $script:titles = @('Diagnóstico prévio', 'Local da instalação de teste', 'Usuário, computador e OneDrive', 'Destinos dos relatórios', 'Rotinas e horários próprios', 'Validação das dependências', 'Revisão das alterações', 'Instalação e verificação final')

    [Windows.Forms.Application]::EnableVisualStyles()
    $script:form = New-Object Windows.Forms.Form
    $form.Text = 'Orquestrador • Instalação e atualização'
    $form.Size = New-Object Drawing.Size(980, 760)
    $form.MinimumSize = New-Object Drawing.Size(980, 760)
    $form.StartPosition = 'CenterScreen'
    $form.Font = New-Object Drawing.Font('Segoe UI', 10)
    $form.BackColor = [Drawing.Color]::FromArgb(243, 246, 250)
    $icon = Join-Path $script:payload 'assets\orquestrador.ico'
    if (Test-Path -LiteralPath $icon) { $form.Icon = New-Object Drawing.Icon($icon) }
    $script:title = New-Object Windows.Forms.Label
    $title.Location = New-Object Drawing.Point(28, 24)
    $title.Size = New-Object Drawing.Size(900, 38)
    $title.Font = New-Object Drawing.Font('Segoe UI', 19, [Drawing.FontStyle]::Bold)
    $title.ForeColor = [Drawing.Color]::FromArgb(0, 51, 141)
    $form.Controls.Add($title)
    $script:subtitle = New-Object Windows.Forms.Label
    $subtitle.Location = New-Object Drawing.Point(30, 68)
    $subtitle.Size = New-Object Drawing.Size(900, 34)
    $subtitle.Text = "TESTE ISOLADO • Versão $($script:release.version) • Runtime privado • Versionamento interno"
    $form.Controls.Add($subtitle)

    function New-Page {
        $panel = New-Object Windows.Forms.Panel
        $panel.Location = New-Object Drawing.Point(30, 112)
        $panel.Size = New-Object Drawing.Size(900, 510)
        $panel.AutoScroll = $true
        $panel.Visible = $false
        $form.Controls.Add($panel)
        $script:pages.Add($panel)
        return $panel
    }
    function New-Label($Parent, [string]$Text, [int]$Top, [int]$Height = 55) {
        $label = New-Object Windows.Forms.Label
        $label.Text = $Text
        $label.Location = New-Object Drawing.Point(0, $Top)
        $label.Size = New-Object Drawing.Size(870, $Height)
        $Parent.Controls.Add($label)
        return $label
    }
    function New-Grid($Parent, [int]$Top, [int]$Height) {
        $grid = New-Object Windows.Forms.DataGridView
        $grid.Location = New-Object Drawing.Point(0, $Top)
        $grid.Size = New-Object Drawing.Size(890, $Height)
        $grid.AllowUserToAddRows = $false
        $grid.AllowUserToDeleteRows = $false
        $grid.RowHeadersVisible = $false
        $grid.AutoSizeColumnsMode = 'Fill'
        $grid.BackgroundColor = [Drawing.Color]::White
        $Parent.Controls.Add($grid)
        return ,$grid
    }
    function New-TextArea($Parent, [int]$Top, [int]$Height) {
        $text = New-Object Windows.Forms.TextBox
        $text.Location = New-Object Drawing.Point(0, $Top)
        $text.Size = New-Object Drawing.Size(890, $Height)
        $text.Multiline = $true
        $text.ReadOnly = $true
        $text.ScrollBars = 'Both'
        $Parent.Controls.Add($text)
        return $text
    }
    $page = New-Page
    New-Label $page "Este assistente instala somente na pasta de teste escolhida. Aplicativo, configuração, perfil do Edge e relatórios permanecem isolados. É possível voltar e cancelar antes de aplicar." 0 75 | Out-Null
    $script:operation = New-Object Windows.Forms.ComboBox
    $operation.DropDownStyle = 'DropDownList'
    $operation.Location = New-Object Drawing.Point(0, 85)
    $operation.Width = 600
    $operation.Items.AddRange(@('Instalar / atualizar', 'Reparar instalação', 'Abrir versão instalada'))
    $operation.SelectedIndex = 0
    $page.Controls.Add($operation)
    $diagnostic = New-TextArea $page 135 350
    $diagnostic.Text = "Usuário: $env:USERNAME`r`nComputador: $env:COMPUTERNAME`r`nPowerShell: $($PSVersionTable.PSVersion)`r`nIdioma de execução: $($ExecutionContext.SessionState.LanguageMode)`r`nPolíticas efetivas:`r`n$(Get-ExecutionPolicy -List | Out-String)`r`nO parâmetro Bypass afeta apenas este processo. Políticas da organização, Smart App Control, antivírus e Windows Script Host continuam aplicáveis. Nenhuma política do computador será alterada."

    $page = New-Page
    New-Label $page 'Escolha uma pasta vazia ou uma instalação de teste reconhecida. Os arquivos originais de outra instalação serão recusados e preservados.' 0 70 | Out-Null
    $script:rootBox = New-Object Windows.Forms.TextBox
    $rootBox.Location = New-Object Drawing.Point(0, 85)
    $rootBox.Width = 730
    $rootBox.Text = $DataRoot
    $page.Controls.Add($rootBox)
    $browse = New-Object Windows.Forms.Button
    $browse.Text = 'Escolher…'
    $browse.Location = New-Object Drawing.Point(745, 82)
    $browse.Width = 140
    $browse.Add_Click({
        $picker = New-Object Windows.Forms.FolderBrowserDialog
        $picker.Description = 'Selecione ou crie uma pasta exclusiva para o teste'
        $picker.SelectedPath = $rootBox.Text
        if ($picker.ShowDialog() -eq 'OK') { $rootBox.Text = $picker.SelectedPath }
        $picker.Dispose()
    })
    $page.Controls.Add($browse)
    $script:locationStatus = New-Label $page 'O diretório será validado ao avançar. Não é necessário instalar Python nem executar comandos.' 145 140

    $page = New-Page
    $script:identityText = New-TextArea $page 0 280
    New-Label $page 'E-mail usado pelos extratores; não informe senha.' 300 28 | Out-Null
    $script:email = New-Object Windows.Forms.TextBox
    $email.Location = New-Object Drawing.Point(0, 335)
    $email.Width = 700
    $page.Controls.Add($email)
    New-Label $page 'Contas OneDrive são exibidas para identificação. Esta edição mantém os relatórios dentro da pasta de teste; publicação local não comprova sincronização.' 385 80 | Out-Null

    $page = New-Page
    New-Label $page 'Selecione uma rotina e use o botão para escolher sua pasta de destino. Nomes finais e contratos dos extratores são preservados.' 0 60 | Out-Null
    $script:destinations = New-Grid $page 70 350
    $destinations.Columns.Add('routine', 'Rotina') | Out-Null
    $destinations.Columns.Add('target', 'Arquivo de destino') | Out-Null
    $destinations.Columns[0].ReadOnly = $true
    $destinations.Columns[1].FillWeight = 220
    $destinationButton = New-Object Windows.Forms.Button
    $destinationButton.Text = 'Escolher pasta da rotina…'
    $destinationButton.Location = New-Object Drawing.Point(0, 440)
    $destinationButton.Width = 270
    $destinationButton.Add_Click({
        if ($null -eq $destinations.CurrentRow) { return }
        $row = $destinations.CurrentRow
        $picker = New-Object Windows.Forms.FolderBrowserDialog
        $picker.SelectedPath = Split-Path -Parent ([string]$row.Cells[1].Value)
        if ($picker.ShowDialog() -eq 'OK') {
            $name = Split-Path -Leaf ([string]$row.Cells[1].Value)
            $row.Cells[1].Value = Join-Path $picker.SelectedPath $name
        }
        $picker.Dispose()
    })
    $page.Controls.Add($destinationButton)

    $page = New-Page
    New-Label $page 'daily: um sucesso por data; horários extras recuperam pendências. every_run: atualiza em cada ocorrência. weekly: um sucesso por semana. Dias: 0=Seg … 6=Dom; sem exclusão automática de feriados.' 0 75 | Out-Null
    $script:routines = New-Grid $page 85 320
    $enabledColumn = New-Object Windows.Forms.DataGridViewCheckBoxColumn
    $enabledColumn.Name = 'enabled'; $enabledColumn.HeaderText = 'Ativa'
    $routines.Columns.Add($enabledColumn) | Out-Null
    $routines.Columns.Add('label', 'Rotina') | Out-Null
    $routines.Columns[1].ReadOnly = $true
    $frequencyColumn = New-Object Windows.Forms.DataGridViewComboBoxColumn
    $frequencyColumn.Name = 'frequency'; $frequencyColumn.HeaderText = 'Frequência'
    $frequencyColumn.Items.AddRange(@('daily', 'weekly', 'every_run'))
    $routines.Columns.Add($frequencyColumn) | Out-Null
    $routines.Columns.Add('times', 'Horários HH:MM') | Out-Null
    $routines.Columns.Add('days', 'Dias 0–6') | Out-Null
    $routines.Columns.Add('weekday', 'Dia semanal 0–6') | Out-Null
    $routines.Columns.Add('order', 'Ordem') | Out-Null
    $script:schedules = New-Object Windows.Forms.CheckBox
    $schedules.Location = New-Object Drawing.Point(0, 425)
    $schedules.Size = New-Object Drawing.Size(880, 55)
    $schedules.Text = 'Instalar monitor próprio no Agendador (sessão interativa; agendamento do teste começa pausado)'
    $page.Controls.Add($schedules)

    $page = New-Page
    New-Label $page 'O pacote já inclui Python e dependências privados. O teste valida imports, SQLite, interface e contratos sem login, VPN ou extrações corporativas.' 0 70 | Out-Null
    $verifyButton = New-Object Windows.Forms.Button
    $verifyButton.Text = 'Verificar dependências offline'
    $verifyButton.Location = New-Object Drawing.Point(0, 80)
    $verifyButton.Width = 320
    $verifyButton.Add_Click({ Start-Operation 'health' })
    $page.Controls.Add($verifyButton)
    $script:dependenciesText = New-TextArea $page 135 345
    $dependenciesText.Text = 'O mesmo health check será obrigatório antes e depois da ativação. Falha externa de autenticação/VPN não é usada como critério de rollback.'

    $page = New-Page
    $script:review = New-TextArea $page 0 390
    $script:approve = New-Object Windows.Forms.CheckBox
    $approve.Location = New-Object Drawing.Point(0, 410)
    $approve.Size = New-Object Drawing.Size(870, 65)
    $approve.Text = 'Aplicar nesta pasta, criar backup verificável e registrar somente atalhos/tarefas próprios.'
    $page.Controls.Add($approve)

    $page = New-Page
    $script:progress = New-Object Windows.Forms.ProgressBar
    $progress.Location = New-Object Drawing.Point(0, 0)
    $progress.Size = New-Object Drawing.Size(890, 22)
    $progress.Style = 'Marquee'
    $page.Controls.Add($progress)
    $script:log = New-TextArea $page 40 440

    $script:status = New-Object Windows.Forms.Label
    $status.Location = New-Object Drawing.Point(30, 635)
    $status.Size = New-Object Drawing.Size(900, 28)
    $form.Controls.Add($status)
    $script:back = New-Object Windows.Forms.Button
    $back.Text = 'Voltar'; $back.Location = New-Object Drawing.Point(590, 672)
    $script:next = New-Object Windows.Forms.Button
    $next.Text = 'Avançar'; $next.Location = New-Object Drawing.Point(705, 672)
    $script:cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Cancelar'; $cancel.Location = New-Object Drawing.Point(820, 672)
    foreach ($control in @($back, $next, $cancel)) { $control.Size = New-Object Drawing.Size(105, 32); $form.Controls.Add($control) }

    function Show-Page([int]$Index) {
        foreach ($panel in $script:pages) { $panel.Visible = $false }
        $script:pageIndex = $Index
        $script:pages[$Index].Visible = $true
        $title.Text = "$($Index + 1). $($script:titles[$Index])"
        $back.Enabled = $Index -gt 0 -and $Index -lt 7
        $next.Text = if ($Index -eq 6) { 'Instalar' } elseif ($Index -eq 7) { 'Abrir aplicativo' } else { 'Avançar' }
        $next.Enabled = $Index -lt 7 -or $script:completed
    }
    function Collect-Configuration {
        $destinations.EndEdit() | Out-Null
        $routines.EndEdit() | Out-Null
        $script:config.email = $email.Text.Trim()
        $script:config.install_schedules = $schedules.Checked
        for ($index = 0; $index -lt $routines.Rows.Count; $index++) {
            $row = $routines.Rows[$index]
            $routine = $script:config.routines[$index]
            $routine.enabled = [bool]$row.Cells[0].Value
            $routine.schedule.frequency = [string]$row.Cells[2].Value
            $routine.schedule.times = @(([string]$row.Cells[3].Value -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
            $routine.schedule.days = @(([string]$row.Cells[4].Value -split ',') | ForEach-Object { [int]$_.Trim() })
            $routine.schedule.weekday = [int]$row.Cells[5].Value
            $routine.order = [int]$row.Cells[6].Value
            $routine.target = [string]$destinations.Rows[$index].Cells[1].Value
        }
    }
    function Fill-Configuration($Value) {
        $script:config = $Value.config
        $identityText.Text = ($Value.identity | ConvertTo-Json) + "`r`n`r`nOneDrive:`r`n" + ($Value.onedrives | ConvertTo-Json -Depth 5)
        $email.Text = [string]$config.email
        $schedules.Checked = [bool]$config.install_schedules
        $destinations.Rows.Clear(); $routines.Rows.Clear()
        foreach ($routine in $config.routines) {
            $destinations.Rows.Add([object[]]@([string]$routine.label, [string]$routine.target)) | Out-Null
            $routines.Rows.Add([object[]]@([bool]$routine.enabled, [string]$routine.label, [string]$routine.schedule.frequency, ($routine.schedule.times -join ', '), ($routine.schedule.days -join ', '), [int]$routine.schedule.weekday, [int]$routine.order)) | Out-Null
        }
        $current = if ($null -eq $Value.current) { 'não instalada' } else { [string]$Value.current.version }
        $locationStatus.Text = "Versão atual: $current`r`nNova versão: $($release.version)`r`nDestino: $($rootBox.Text)`r`nDados, configurações, scripts adicionais e último sucesso são preservados nas atualizações."
    }
    function Start-Operation([string]$Action) {
        if ($null -ne $script:job) { return }
        $script:jobAction = $Action
        $request = @{ action = $Action; data_root = $rootBox.Text.Trim(); payload = $script:payload }
        if ($Action -in @('install', 'repair', 'update')) { $request.config = $script:config }
        if ($Action -eq 'rollback') { $request.backup = $Backup }
        $script:job = Start-NativeBridge $script:payload $request
        $back.Enabled = $false; $next.Enabled = $false; $verifyButton.Enabled = $false
        $status.Text = 'Operação em andamento; acompanhe as etapas reais. Cancelamento ocorre em checkpoints seguros.'
    }

    $back.Add_Click({ Show-Page ($script:pageIndex - 1) })
    $next.Add_Click({
        try {
            if ($script:pageIndex -eq 7) { Open-NativeApplication $rootBox.Text; $script:exitCode = 0; $form.Close(); return }
            if ($script:pageIndex -eq 1) { Start-Operation 'preview'; return }
            if ($script:pageIndex -eq 5) {
                Collect-Configuration
                $review.Text = "Versão nova: $($release.version)`r`nPasta: $($rootBox.Text)`r`nBackup: backups\app (verificação SHA-256 obrigatória)`r`nHealth check offline antes/depois; ativação por ponteiro; rollback automático em falha interna.`r`n`r`n" + ($script:config | ConvertTo-Json -Depth 64)
            }
            if ($script:pageIndex -eq 6) {
                if (-not $approve.Checked) { throw 'Revise e marque a aplicação das alterações.' }
                Show-Page 7
                $action = if ($operation.SelectedIndex -eq 1) { 'repair' } else { 'install' }
                Start-Operation $action
                return
            }
            Show-Page ($script:pageIndex + 1)
        } catch { Show-NativeError $_.Exception.Message }
    })
    $cancel.Add_Click({
        if ($null -ne $script:job) {
            [IO.File]::WriteAllText($script:job.Cancel, 'cancel')
            $script:cancelPending = $true
            $status.Text = 'Cancelamento solicitado; aguardando checkpoint e reversão segura.'
            $cancel.Enabled = $false
        } else { $form.Close() }
    })
    $form.Add_FormClosing({
        param($sender, $eventArgs)
        if ($null -ne $script:job) {
            [IO.File]::WriteAllText($script:job.Cancel, 'cancel')
            $script:cancelPending = $true
            $eventArgs.Cancel = $true
        }
    })
    $script:timer = New-Object Windows.Forms.Timer
    $timer.Interval = 400
    $timer.Add_Tick({
        if ($null -eq $script:job) { return }
        try {
            if (Test-Path -LiteralPath $script:job.Events) {
                $lines = @(Get-Content -LiteralPath $script:job.Events -Encoding UTF8 | Select-Object -Last 200)
                $messages = foreach ($line in $lines) { try { (ConvertFrom-Json $line).stage } catch { } }
                $log.Text = $messages -join "`r`n"
            }
            if (-not $script:job.Process.HasExited) { return }
            $ended = $script:job
            $script:job = $null
            $value = Get-NativeBridgeResult $ended
            $ended.Process.Dispose()
            $verifyButton.Enabled = $true
            $cancel.Enabled = $true
            $status.Text = 'Operação concluída.'
            if ($script:jobAction -eq 'preview') {
                Fill-Configuration $value
                if ($script:cancelPending) { $form.Close(); return }
                if ($operation.SelectedIndex -eq 2) { Open-NativeApplication $rootBox.Text; $script:exitCode = 0; $form.Close(); return }
                if ($AutoUpdate) {
                    Show-Page 7
                    $action = if ($Backup) { 'rollback' } else { 'update' }
                    Start-Operation $action
                } else { Show-Page 2 }
            } elseif ($script:jobAction -eq 'health') {
                $dependenciesText.Text = $value | ConvertTo-Json -Depth 10
                Show-Page 5
            } else {
                $script:completed = $true
                $script:exitCode = 0
                $progress.Style = 'Continuous'; $progress.Value = 100
                $cancel.Text = 'Fechar'
                $next.Enabled = $true
                if ($AutoUpdate) { Open-NativeApplication $rootBox.Text; $form.Close() }
            }
        } catch {
            $script:job = $null
            $script:exitCode = 2
            $status.Text = $_.Exception.Message
            $log.AppendText("`r`n" + $_.Exception.Message)
            $verifyButton.Enabled = $true; $cancel.Enabled = $true
            $back.Enabled = $script:pageIndex -gt 0 -and $script:pageIndex -lt 7
            if ($script:pageIndex -lt 7) { $next.Enabled = $true }
            $progress.Style = 'Continuous'; $progress.Value = 0
            Show-NativeError $_.Exception.Message
            if ($AutoUpdate -and (Test-Path -LiteralPath (Join-Path $rootBox.Text 'installation.json'))) { Open-NativeApplication $rootBox.Text; $form.Close() }
        }
    })
    $form.Add_Shown({ if ($AutoUpdate) { Show-Page 1; Start-Operation 'preview' } })
    Show-Page 0
    $timer.Start()
    [void]$form.ShowDialog()
    $timer.Stop(); $timer.Dispose(); $form.Dispose()
    exit $script:exitCode
} catch {
    [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Orquestrador • instalação não iniciada') | Out-Null
    exit 2
}

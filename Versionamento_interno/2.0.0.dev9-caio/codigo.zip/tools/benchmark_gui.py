from __future__ import annotations

import json
import os
import platform
import re
import statistics
import sys
import tempfile
import time
from pathlib import Path


def main() -> None:
    started = time.perf_counter()
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    import psutil
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication

    from orquestrador_app.config import defaults, save
    from orquestrador_app.gui import MainWindow
    from orquestrador_app.paths import Paths
    from orquestrador_app.resources import source_root

    app = QApplication([])
    with tempfile.TemporaryDirectory(prefix="orquestrador-benchmark-") as temporary:
        paths = Paths.user(temporary)
        paths.ensure()
        save(paths, defaults(paths, source_root()))
        window = MainWindow(paths)
        window.show()
        app.processEvents()
        ready = time.perf_counter() - started
        if sys.platform == "linux":
            match = re.search(r"^VmRSS:\s+(\d+) kB", Path("/proc/self/status").read_text(), re.M)
            if not match:
                raise RuntimeError("Medição de RSS indisponível; benchmark não inventa consumo.")
            memory = int(match.group(1)) * 1024
            memory_method = "/proc/self/status VmRSS (namespace-aware)"
        else:
            memory = psutil.Process().memory_info().rss
            memory_method = "psutil.Process().memory_info().rss"
        samples: list[float] = []
        previous = time.perf_counter()

        def sample() -> None:
            nonlocal previous
            current = time.perf_counter()
            samples.append(current - previous)
            previous = current

        timer = QTimer()
        timer.timeout.connect(sample)
        timer.start(10)
        end = time.monotonic() + 2
        while time.monotonic() < end:
            app.processEvents()
            time.sleep(0.001)
        timer.stop()
        record = {
            "environment": platform.platform(),
            "python": sys.version,
            "platform_plugin": os.environ["QT_QPA_PLATFORM"],
            "mode": "source, Linux; NOT Windows executable",
            "method": "one process; import + construct + show + processEvents; 10ms QTimer, 2s idle panel; OS page cache not reset",
            "opening_seconds": ready,
            "rss_bytes_ready": memory,
            "memory_method": memory_method,
            "timer_samples": len(samples),
            "median_timer_interval_seconds": statistics.median(samples),
            "max_timer_interval_seconds": max(samples),
            "windows_benchmark": "NOT_EXECUTED",
        }
        target = Path("docs/evidencias/desktop-benchmark-linux.json")
        target.write_text(json.dumps(record, indent=2), encoding="utf-8")
        print(json.dumps(record, indent=2))
        window.timer.stop()
        window.tray.hide()
        window.exit_requested = True
        window.close()


if __name__ == "__main__":
    main()

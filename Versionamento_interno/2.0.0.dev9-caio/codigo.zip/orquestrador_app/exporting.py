"""Sanitized JSON/XLSX output, without loading pandas into the UI."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from .io import atomic_json, sanitize


def export_data(target: Path, value: Any) -> dict[str, str]:
    value = sanitize(value, export=True)
    if target.suffix.casefold() != ".xlsx":
        atomic_json(target, value)
    else:
        from openpyxl import Workbook

        workbook = Workbook(write_only=True)
        groups = value if isinstance(value, dict) else {"history": value}
        for index, (name, content) in enumerate(groups.items()):
            sheet = workbook.create_sheet(f"{index + 1}-{name}"[:31].replace("/", "-"))
            rows = content if isinstance(content, list) else [content]
            records = [r if isinstance(r, dict) else {"value": r} for r in rows]
            keys = list(dict.fromkeys(k for record in records for k in record)) or ["value"]
            sheet.append(keys)
            for record in records:
                cells = []
                for key in keys:
                    cell = record.get(key)
                    if isinstance(cell, (dict, list)):
                        cell = json.dumps(cell, ensure_ascii=False)
                    if isinstance(cell, str):
                        cell = "".join(c for c in cell if c in "\t\r\n" or ord(c) >= 32)[:32700]
                        if cell.startswith(("=", "+", "-", "@")):
                            cell = "'" + cell
                    cells.append(cell)
                sheet.append(cells)
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(suffix=".xlsx", dir=target.parent)
        os.close(fd)
        try:
            workbook.save(name)
            os.replace(name, target)
        finally:
            Path(name).unlink(missing_ok=True)
            workbook.close()
    return {"file": str(target), "status": "exported"}

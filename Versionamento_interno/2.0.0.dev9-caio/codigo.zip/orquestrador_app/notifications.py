from __future__ import annotations

import datetime as dt
import uuid
from typing import Any

from .config import Config
from .store import Store, utcnow


def show(tray: Any, message: str, title: str = "CAIO") -> None:
    from .i18n import tr
    from .ui import icon

    tray.showMessage(title, tr(message), icon(), 15000)


def enqueue(store: Store, config: Config, kind: str, job: str, run: str, message: str) -> bool:
    if not config.notifications.get("enabled", True) or not config.job(job).notifications:
        return False
    now = utcnow()
    cooldown = now - dt.timedelta(minutes=int(config.notifications["cooldown_minutes"]))
    hourly = now - dt.timedelta(hours=1)
    with store.connect() as db:
        if db.execute(
            "SELECT 1 FROM notifications WHERE kind=? AND job=? AND at>?",
            (kind, job, cooldown.isoformat()),
        ).fetchone():
            return False
        count = db.execute(
            "SELECT COUNT(*) FROM notifications WHERE at>?", (hourly.isoformat(),)
        ).fetchone()[0]
        if count >= int(config.notifications["max_per_hour"]):
            return False
        db.execute(
            "INSERT INTO notifications(id,at,kind,job,run,message) VALUES(?,?,?,?,?,?)",
            (str(uuid.uuid4()), now.isoformat(), kind, job, run, message),
        )
    return True

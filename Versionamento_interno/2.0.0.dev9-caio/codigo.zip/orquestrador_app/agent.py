from __future__ import annotations

import os
import sys
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon

from .clock import local_now
from .config import load, save
from .engine import Engine
from .gui import Task, VpnNotice
from .io import BusyError, Lock, read_json
from .paths import Paths
from .processes import command, spawn
from .schedule import eligible
from .store import Store


def run_agent(paths: Paths) -> int:
    paths.ensure()
    try:
        ownership = Lock(paths.root / "state/monitor.lock")
        ownership.__enter__()
    except BusyError:
        return 0
    try:
        existing_app = QApplication.instance()
        if existing_app is not None and not isinstance(existing_app, QApplication):
            raise RuntimeError("O monitor exige uma instância QApplication.")
        app = existing_app if existing_app is not None else QApplication(sys.argv[:1])
        app.setQuitOnLastWindowClosed(False)
        from .notifications import show
        from .ui import icon
        from .windows_identity import set_process_identity

        set_process_identity(paths)
        tray = QSystemTrayIcon(icon())
        tray.setToolTip("Orquestrador • monitor de horários e atualização")
        menu = QMenu()
        open_action = QAction("Abrir Orquestrador", menu)
        open_action.triggered.connect(lambda: spawn(command("--data-root", str(paths.root))))
        menu.addAction(open_action)
        pause_action = QAction("Pausar/retomar agendamento", menu)

        def pause() -> None:
            try:
                with Lock(paths.maintenance_lock), Lock(paths.root / "state/config.lock"):
                    config = load(paths)
                    config.scheduling_paused = not config.scheduling_paused
                    save(paths, config)
            except BusyError:
                show(
                    tray, "Atualização/manutenção em andamento; aguarde para alterar o agendamento."
                )

        pause_action.triggered.connect(pause)
        menu.addAction(pause_action)
        tray.setContextMenu(menu)
        tray.show()
        store = Store(paths.database)
        engine = Engine(paths)
        from .i18n import install_translation
        from .ui import apply_theme, icon

        apply_theme(app)
        install_translation(app, load(paths).language)
        tray.setIcon(icon())
        current: dict[str, str] = {}
        task: Task | None = None
        last_monitor = 0.0
        notices: list[VpnNotice] = []

        def open_detail() -> None:
            spawn(command("--data-root", str(paths.root), "--run-detail", current.get("run", "")))

        tray.messageClicked.connect(open_detail)

        def notifications() -> None:
            with store.connect() as db:
                rows = list(
                    db.execute("SELECT * FROM notifications WHERE delivered=0 ORDER BY at LIMIT 1")
                )
                for row in rows:
                    claimed = db.execute(
                        "UPDATE notifications SET delivered=1 WHERE id=? AND delivered=0",
                        (row["id"],),
                    )
                    if not claimed.rowcount:
                        continue
                    current["run"] = row["run"] or ""
                    show(tray, row["message"])
                    if row["kind"] == "vpn":
                        notices.append(VpnNotice(store, row["run"], row["message"]))

        def tick() -> None:
            nonlocal task, last_monitor
            try:
                pointer = paths.root / "installation.json"
                if pointer.is_file() and read_json(pointer).get("distribution") == "native-scripts":
                    active_release = Path(read_json(pointer)["release"]).resolve()
                    from .resources import source_root

                    if source_root().parent.resolve() != active_release:
                        if not task or not task.isRunning():
                            tray.hide()
                            app.quit()
                        return
                if getattr(sys, "frozen", False) and pointer.is_file():
                    active = read_json(pointer)["executable"]
                    if os.path.normcase(active) != os.path.normcase(sys.executable):
                        if not task or not task.isRunning():
                            app.quit()  # The owned repeating task restarts the activated version.
                        return
                config = load(paths)
                engine.config = config
                now = local_now()
                if now.timestamp() - last_monitor >= 60:
                    engine.monitor()
                    last_monitor = now.timestamp()
                if (not task or not task.isRunning()) and any(
                    eligible(j, store.state(j.id), now, paused=config.scheduling_paused).due
                    for j in config.routines
                ):
                    task = Task(lambda: Engine(paths).run(scheduled=True))
                    task.failed.connect(lambda error: store.event(None, "monitor_error", error))
                    task.start()
                notifications()
            except Exception as exc:
                store.event(None, "monitor_error", str(exc))

        def protected_tick() -> None:
            try:
                with Lock(paths.maintenance_lock):
                    tick()
            except BusyError:
                return

        timer = QTimer()
        timer.timeout.connect(protected_tick)
        timer.start(1000)
        QTimer.singleShot(0, protected_tick)
        result = app.exec()
        if task and task.isRunning():
            # Agent shutdown must not kill a live extraction without a recorded cooperative cancellation.
            for row in store.history():
                if row["status"] == "running":
                    store.control(row["id"], "cancel")
            task.wait(15000)
        return result
    finally:
        ownership.__exit__()

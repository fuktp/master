"""Local, content-addressed script snapshots. Hashes identify versions, never grant permission."""

from __future__ import annotations

import datetime as dt
import shutil
from typing import Any

from .config import Config, Routine, save
from .io import Lock, atomic_json, digest, read_json
from .paths import Paths
from .resources import script_path


def capture(paths: Paths, job: Routine) -> dict[str, Any]:
    source = script_path(job.script)
    if source.suffix.casefold() != ".py" or not source.is_file():
        raise ValueError("O script precisa ser um arquivo Python existente.")
    checksum = digest(source)
    folder = paths.root / "extras/versions" / job.id / checksum
    with Lock(paths.root / "state/scripts.lock"):
        folder.mkdir(parents=True, exist_ok=True)
        file = folder / "script.py"
        if not file.is_file():
            temporary = folder / "script.tmp"
            shutil.copy2(source, temporary)
            if digest(temporary) != checksum:
                temporary.unlink(missing_ok=True)
                raise ValueError("O script mudou durante o snapshot; tente novamente.")
            temporary.replace(file)
        elif digest(file) != checksum:
            raise ValueError("Snapshot de script corrompido; versão anterior preservada.")
        metadata = folder / "version.json"
        if not metadata.is_file():
            atomic_json(
                metadata,
                {
                    "sha256": checksum,
                    "version": job.script_version or checksum[:12],
                    "at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
                    "source": str(source),
                    "size": file.stat().st_size,
                },
            )
        return dict(read_json(metadata))


def versions(paths: Paths, job: Routine) -> list[dict[str, Any]]:
    root = paths.root / "extras/versions" / job.id
    return sorted(
        (dict(read_json(p)) for p in root.glob("*/version.json")),
        key=lambda x: x["at"],
        reverse=True,
    )


def restore(paths: Paths, config: Config, job: Routine, checksum: str) -> None:
    if len(checksum) != 64 or any(c not in "0123456789abcdef" for c in checksum):
        raise ValueError("Identificador de versão inválido.")
    with Lock(paths.maintenance_lock), Lock(paths.lock), Lock(paths.root / "state/config.lock"):
        capture(paths, job)
        source = paths.root / "extras/versions" / job.id / checksum / "script.py"
        if digest(source) != checksum:
            raise ValueError("Snapshot de script inválido.")
        # A rollback never overwrites an external production source.
        target = paths.root / "extras/active" / job.id / "script.py"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target.with_suffix(".tmp"))
        target.with_suffix(".tmp").replace(target)
        job.script = str(target)
        job.script_version = read_json(source.parent / "version.json")["version"]
        save(paths, config)


def remove(paths: Paths, config: Config, identifier: str, purge: bool = False) -> None:
    if any(d.job == identifier for j in config.routines for d in j.dependencies):
        raise ValueError("Remova primeiro as dependências que apontam para esta rotina.")
    with Lock(paths.maintenance_lock), Lock(paths.lock), Lock(paths.root / "state/config.lock"):
        job = config.job(identifier)
        if script_path(job.script).is_file():
            capture(paths, job)
        config.routines.remove(job)
        save(paths, config)
        if purge:
            # Only application-managed copies; never delete a source file or report.
            for category in ("versions", "active"):
                folder = paths.root / "extras" / category / identifier
                if folder.is_symlink():
                    raise ValueError("Link inesperado na área de scripts.")
                if folder.is_dir():
                    shutil.rmtree(folder)

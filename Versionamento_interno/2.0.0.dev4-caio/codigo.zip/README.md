# Orquestrador Pipefy + KWMS

Versão **1.3.0**. Acrescenta o download do KWMS, aviso de VPN e frequência por automação. Os scripts de Clientes, Eventos e Procedimentos mantêm o comportamento da versão 1.2.4, incluindo a correção de `Ticket KDSC / Audit Tech`.

## Atualizar a instalação existente

1. Extraia este ZIP em uma pasta separada da instalação atual.
2. Na pasta extraída `pipefy-orchestrator`, execute **Atualizar_Instalacao.cmd**. O destino padrão é:

   ```text
   C:\Users\chailer\OneDrive - KPMG\BR - CAIO 2-1 Gestão - Dashboard\Testes - PBi\extraction
   ```

3. Na pasta de destino `extraction`, execute **Instalar_Automacao_Pipefy.cmd**. O formulário abre antes do login e da instalação das tarefas. Confira as frequências e clique em **Salvar**.

O atualizador preserva os caminhos, os horários e as opções existentes no JSON, adiciona a rotina KWMS e faz backup dos arquivos que substituir. Scripts adicionais, como `pipefy_status_atms_tool_edge.py`, permanecem na instalação e continuam sujeitos à descoberta configurada. Este ZIP contém os três extratores do pacote 1.2.4 e o novo extrator KWMS; não contém uma cópia do extrator ATMS adicional.

O atualizador não apaga histórico, arquivos finais, tarefas ou estado de frequências. Os backups ficam em `.pipefy_orchestrator\package_backups`. Execute a atualização com o lote anterior encerrado; um lote em andamento impede a atualização pelo mesmo lock.

Se o destino da instalação for outro:

```powershell
py .\update_installation.py --target "D:\MinhaPasta\extraction"
```

Para uma instalação nova, copie o conteúdo de `pipefy-orchestrator` para `extraction`, confira os caminhos do JSON e execute `Instalar_Automacao_Pipefy.cmd`. O instalador usa o perfil do usuário conectado e instala as dependências de `requirements.txt` caso estejam ausentes.

## Formulário e frequências

**Configurar_Automacoes.cmd** permite alterar as escolhas a qualquer momento. **Executar_Pipefy.cmd** abre o formulário se a configuração inicial ainda estiver pendente; depois executa o lote. Cancelar o formulário impede o início do lote pelo iniciador.

Cada linha permite ativar/desativar a rotina e escolher:

| Opção | Regra |
|---|---|
| Diária | Uma conclusão com sucesso por data local, a partir do horário escolhido. |
| Semanal | Uma conclusão com sucesso por semana de segunda a domingo, a partir do dia e horário escolhidos. |
| Todos os horários | Executa em cada disparo do lote, preservando a frequência intradiária anterior. |
| Só dias úteis | Restringe a segunda a sexta; não consulta calendário de feriados. |

As sugestões iniciais são:

| Automação | Frequência | Quando |
|---|---|---|
| Clientes | Diária | A partir de 08:30, segunda a sexta |
| Eventos | Diária | A partir de 08:30, segunda a sexta |
| Procedimentos | Diária | A partir de 08:30, segunda a sexta |
| KWMS — alocações | Semanal | A partir de segunda-feira, 08:30 |

A escolha final é feita pelo formulário ou pelo JSON. Uma rotina adicional descoberta, como ATMS, também aparece no formulário; sem preferência específica, usa `schedule_defaults`.

Os horários `schedules` continuam sendo os disparos do lote: `08:30`, `10:30`, `12:30`, `14:30` e `16:30`. Eles representam oportunidades de execução. Por exemplo, uma rotina diária que terminar às 08:40 será ignorada às 10:30, 12:30, 14:30 e 16:30. Uma rotina semanal concluída na segunda será ignorada até a próxima semana.

Se a máquina estiver desligada na segunda e o KWMS ainda não tiver sido atualizado naquela semana, ele poderá rodar na terça ou nos demais dias úteis. Se uma rotina falhar ou for ignorada por VPN, ela permanece pendente para os próximos disparos. São permitidas várias tentativas na semana até ocorrer uma atualização bem-sucedida; depois disso, não há outra atualização automática naquela semana.

O horário por rotina é um limite inicial. A execução ocorre no primeiro disparo disponível igual ou posterior a ele, podendo começar depois por causa das rotinas anteriores. Não é um agendamento independente. Para usar 18:00, por exemplo, adicione um horário compatível em `schedules` e reinstale as tarefas.

As tarefas agendadas chamam diretamente `run` e não abrem o formulário. O aviso de VPN do KWMS pode aparecer durante essas execuções. As tarefas executam somente com o usuário conectado ao Windows.

## Editar diretamente o JSON

O bloco `job_schedules` identifica cada rotina pelo nome do script sem `.py`:

```json
"job_schedules": {
  "pipefy_eventos_tool_edge": {
    "enabled": true,
    "frequency": "daily",
    "time": "08:30",
    "weekday": "Monday",
    "weekdays_only": true
  },
  "kwms_alocacoes_tool_edge": {
    "enabled": true,
    "frequency": "weekly",
    "time": "08:30",
    "weekday": "Monday",
    "weekdays_only": true
  }
}
```

Valores aceitos para `frequency`: `daily`, `weekly`, `every_run`. `weekday` só controla o dia inicial quando a frequência é `weekly`. Dias aceitos: `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`, `Sunday`. Para sábado ou domingo, use `weekdays_only: false`; nos extratores Pipefy, retire também `--weekdays-only` dos argumentos caso queira execução no fim de semana.

Após definir as opções diretamente no JSON, use `"schedule_setup_completed": true` para dispensar o formulário inicial. Para exibi-lo novamente automaticamente, use `false`, ou abra `Configurar_Automacoes.cmd`.

Alterar somente `job_schedules` não exige reinstalar as tarefas. Alterar os horários globais `schedules` exige executar novamente `install_tasks.ps1` ou `Instalar_Automacao_Pipefy.cmd`.

A execução usa o fuso local do Windows. No computador informado, configure o fuso de Brasília. O estado fica em `.pipefy_orchestrator\job_schedule_state.json`; somente uma extração concluída com sucesso é registrada. Encerrar e abrir o programa novamente preserva esse controle.

## KWMS: login, VPN e download

O script `scripts\kwms_alocacoes_tool_edge.py`:

1. Abre `https://kwms.br.kworld.kpmg.com/wms/login` no Edge.
2. Preenche `input[type='email']` com `chailer@kpmg.com.br` e clica em `button[type='submit'][aria-label='Login with email']` quando o formulário é exibido. Uma sessão já autenticada é aproveitada.
3. Aguarda a conclusão do login e abre `https://kwms.br.kworld.kpmg.com/wms/reporting`.
4. Aguarda e clica no botão visível `button[title='Baixar arquivo']`.
5. Aguarda o XLSX terminar de baixar, confere o prefixo do nome e valida o conteúdo da planilha.
6. Substitui o arquivo final por uma cópia completa, usando troca atômica no mesmo diretório.

O arquivo com timestamp, por exemplo:

```text
Detalhes de Alocação_- Planos Aprovados e Baixados - 1792430784969.xlsx
```

é publicado como:

```text
C:\Users\chailer\OneDrive - KPMG\BR - CAIO 2-1 Gestão - Dashboard\Planilhas de Apoio\KWMS\Detalhes de Alocação_- Planos Aprovados e Baixados.xlsx
```

A extensão `.xlsx` é mantida. Apenas esse arquivo é substituído; outros arquivos da pasta permanecem.

Se aparecer **ERR_EMPTY_RESPONSE**, seja na exceção do EdgeDriver ou no texto da página, abre-se um aviso **Ative a VPN da KPMG**, com contagem regressiva. A janela do aviso e, quando disponível, a janela de console recebem o sinal de piscar do Windows. O programa espera **30 segundos** e faz a **segunda e última tentativa**. Minimizar o aviso não reduz a espera.

Se a segunda tentativa retornar o mesmo erro, o KWMS sai com código `20`. O orquestrador registra `skipped`, passa imediatamente à próxima rotina e não aplica novas tentativas externas ao KWMS, mesmo com `continue_on_error: false`. O lote termina com aviso, sem acionar o reinício automático de tarefa por falha. O KWMS permanece pendente para o próximo disparo.

Outras falhas, como arquivo inválido, download incompleto ou Excel bloqueando o destino, são registradas como falha normal e respeitam a política `continue_on_error`. O arquivo anterior é preservado nesses casos. O login implementa o fluxo por e-mail informado; se o ambiente passar a exigir outra etapa, a rotina encerra com diagnóstico de autenticação.

A rotina KWMS abre uma janela visível por padrão. O perfil utilizado é `C:\SeleniumEdgeProfile`, compartilhado com os extratores. O novo script reutiliza a abertura e a proteção do perfil presentes em `pipefy_clientes_tool_edge.py`; mantenha os dois scripts na pasta `scripts`.

As configurações do e-mail e destino estão no job KWMS:

```json
"environment": {
  "KWMS_EMAIL": "chailer@kpmg.com.br",
  "KWMS_OUTPUT_DIR": "C:\\Users\\chailer\\OneDrive - KPMG\\BR - CAIO 2-1 Gestão - Dashboard\\Planilhas de Apoio\\KWMS"
}
```

`KWMS_EDGE_PROFILE` pode ser acrescentado ao mesmo bloco para usar outro perfil dedicado. `retries: 0` evita repetir a sequência completa por falhas comuns. `skip_exit_codes: [20]` define o tratamento de VPN pelo orquestrador. As duas tentativas de VPN são internas ao extrator, com espera fixa de 30 segundos.

Downloads temporários ficam em `.pipefy_orchestrator\downloads\kwms`; arquivos de diagnóstico são mantidos quando há falha. Uma exportação vazia ou apenas com cabeçalho não substitui o arquivo atual. Sem o schema completo do KWMS, a validação verifica a integridade da planilha e a presença de conteúdo, sem impor cabeçalhos não informados. Caso a tela apresente vários botões de download visíveis, a rotina informa a ambiguidade para permitir identificar o relatório correto.

## Comandos úteis

Na pasta `extraction`, com PowerShell:

```powershell
# Abrir o formulário, sem executar extrações
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json configure-schedules

# Conferir as rotinas e suas frequências
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json list-jobs

# Mostrar o que está pendente, sem abrir navegador ou baixar arquivos
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json run --dry-run

# Executar somente KWMS respeitando a frequência
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json run --job kwms_alocacoes_tool_edge

# Testar KWMS mesmo se já tiver sido atualizado na semana
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json run --job kwms_alocacoes_tool_edge --force

# Validar e reparar EdgeDriver
py .\pipefy_orchestrator.py --config .\pipefy_orchestrator.config.json doctor --repair

# Reinstalar as tarefas nos horários de schedules
powershell -NoProfile -ExecutionPolicy Bypass -File .\install_tasks.ps1

# Remover somente as tarefas deste pacote
powershell -NoProfile -ExecutionPolicy Bypass -File .\install_tasks.ps1 -Remove
```

`--force` dispensa o controle de frequência somente naquela execução e mantém rotinas desativadas fora do lote. Se terminar com sucesso, também atualiza o estado da rotina. O subcomando `login` não consome a frequência da extração.

## Arquivos e diagnóstico

| Local | Conteúdo |
|---|---|
| `logs\pipefy_orchestrator.log` | Log consolidado do lote |
| `logs\kwms_alocacoes_tool_edge.log` | Login, VPN e download KWMS |
| `.pipefy_orchestrator\job_schedule_state.json` | Último sucesso de cada rotina |
| `.pipefy_orchestrator\last_run.json` | Resultado do último lote: success, failed, skipped ou not_due |
| `.pipefy_orchestrator\run_history.jsonl` | Histórico dos lotes |
| `.pipefy_orchestrator\package_backups` | Backups da atualização |
| `.pipefy_orchestrator\selenium-cache` | Cache do EdgeDriver |

Um lote sem rotina pendente termina sem iniciar o Edge. O bloqueio existente impede lotes simultâneos. Clientes continua gerando `clientes\Clientes.xlsx`, Procedimentos continua gerando `procedimentos\Procedimentos.xlsx` e Eventos continua acrescentando registros em `historico\historico_reports.csv`, sob `output_dir`.

A proteção existente do EdgeDriver permanece: comparação dos três primeiros componentes de versão, assinatura Authenticode, sessão de diagnóstico, reparo pelo Selenium Manager ou mirror oficial e adaptação dos caminhos de driver dos extratores com backup. Não são gravadas senhas no JSON ou nos relatórios de execução.

## Validação do pacote

```powershell
py -m compileall -q .\pipefy_orchestrator.py .\automation_schedule.py .\update_installation.py .\scripts
py -m unittest discover -s .\tests -v
```

Os testes locais verificam frequências, retomada após reinício, continuação do lote após VPN, duas tentativas com intervalo solicitado de 30 segundos, substituição do XLSX, proteção contra conteúdo inválido e preservação da instalação durante a atualização. Os testes não acessam o KWMS real. A conexão à VPN, o login corporativo e o efeito visual de piscar precisam ser conferidos na primeira execução no Windows.

Referências técnicas: [Selenium Edge](https://www.selenium.dev/documentation/webdriver/browsers/edge/), [esperas do Selenium](https://www.selenium.dev/documentation/webdriver/waits/) e [FlashWindowEx do Windows](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-flashwindowex).

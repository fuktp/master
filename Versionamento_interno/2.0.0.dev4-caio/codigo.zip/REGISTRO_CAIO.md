# Registro técnico — CAIO 2.0.0.dev4

Base: pacote técnico e runtime oficiais recebidos na entrega 2.0.0.dev3. SHA-256 original do código ZIP: `2dbfa546f9fa7c0c66f7be502d76f258473aaaa2f55b929c3079b6642bb9679a`; do produto ZIP: `498786ae2c8275a946892318c5cbc51e310f3638efe6b072cd36d1d31bf57f6a`. Os dois foram conferidos antes da cópia de trabalho. Versionamento interno; branch/commit Git não se aplicam por instrução do usuário.

A mudança de distribuição EXE para scripts segue a decisão da dev3; esta revisão não volta a distribuir um executável próprio. Não alteramos extratores, schemas ou URLs corporativas. O controle por hash de autorização foi substituído a pedido do usuário por cadastro/habilitação e snapshots de versão. Hashes de integridade do pacote e backup continuam obrigatórios. A instalação nova do wizard nativo deixa a próxima execução calculada; atualização preserva pausa existente. O feed HTTPS continua disponível apenas no núcleo técnico antigo, mas não é consultado por esta interface/monitor.

## Implementação e limites

- Arquivos novos: `ui.py`, `i18n.py`, `locales.json`, `script_versions.py`, `exporting.py`, `native/Native.Routines.ps1`, `assets/caio.*`, testes e ferramentas de marca/benchmark. Arquivos alterados e hashes estão no manifesto interno.
- Não adicionamos dependência de runtime. `pefile==2023.2.7` foi fixado no grupo de desenvolvimento para inspecionar as dependências PE durante o build a partir do runtime anterior; antes o build dependia de encontrá-lo no pacote Windows completo.
- A interface usa o mesmo Python/Qt, configurações, worker, locks e SQLite. A consulta do painel reaproveita Engine; tabelas fora da aba visível não são reprocessadas a cada tick, células/logs inalterados não são reconstruídos; Task é compartilhado com Dev.
- QtTest, documentação CHM, stubs/cabeçalhos e exemplos de bibliotecas não entram no pacote operacional. Licenças e bibliotecas utilizadas são preservadas. O builder resolve o fechamento das DLLs Qt antes de podar arquivos.
- A busca de driver é deliberadamente limitada, configurável por raízes adicionais e não lê discos de rede em busca indiscriminada. A versão instalada do Edge ainda precisa existir. Uma falha de assinatura é erro; não é ignorada.
- Idiomas traduzem controles e guias. Nomes definidos pelo usuário, código, JSON e registros técnicos externos não são reescritos. Capturas Qt são artefatos de teste, sem dados corporativos.
- Restaurar versão de script preserva o arquivo externo e aponta a rotina para uma cópia gerenciada; scripts que importam arquivos vizinhos devem manter seus auxiliares disponíveis ou ajustar seu caminho de trabalho. Não há instalação automática de dependências arbitrárias de scripts futuros.
- A tabela de backups não era uma lista de diagnósticos: ela lista versões de relatórios. Uma instalação sem substituições válidas naturalmente não tem entradas. A interface agora explica esse estado.

## Validação reproduzível

Na raiz técnica, com ambiente de desenvolvimento isolado:

```text
uv sync --frozen
uv run ruff check .
uv run ruff format --check .
uv run mypy --platform win32
QT_QPA_PLATFORM=offscreen uv run python -m pytest -q --junitxml=docs/evidencias/dev4-tests.xml
uv run pip-audit --disable-pip --no-deps -r docs/evidencias/native-audit-windows-inputs.txt --format json -o docs/evidencias/dev4-dependency-audit.json
pwsh -NoProfile -File tools/test_native_powershell.ps1
QT_QPA_PLATFORM=offscreen uv run python -m orquestrador_app --health-check --health-output docs/evidencias/dev4-health.json
uv run python tools/build_native_zip.py --runtime <runtime-Windows-verificado> --output <area-nova>
uv run python tools/verify_native_artifact.py --archive <ZIP> --scratch <pasta-teste> --output <relatorio.json>
```

O build reutilizou os bytes do CPython privado e wheels Windows já verificados da dev3; a nova poda e todo arquivo empacotado foram verificados. `uv.lock` permanece reproduzível. Os comandos são técnicos, não passos do usuário final.

As primeiras verificações apontaram chamadas de teste fora da raiz de trabalho e expectativas antigas sobre autorização por hash/seletor de horários. As chamadas foram refeitas na raiz correta; as expectativas foram atualizadas para os comportamentos exigidos. O teste de feed usa uma versão futura de fixture (dev99), em vez da versão atual dev4. Não foram suprimidas falhas para declarar sucesso.

Evidências efetivas em `docs/evidencias/dev4-*`: JUnit, tipos/lint, PowerShell, saúde local, auditoria de dependências, comparação de benchmark e integridade final do ZIP. Consulte os arquivos finais para contagens e hashes. As simulações de Agendador, EdgeDriver, browser e atualização têm identificação explícita nos testes.

## Benchmark

Comparação em três processos por versão, Linux 6.18.55 x64, CPython 3.12.14, Qt offscreen, cache do sistema não limpo, janela principal com cinco rotinas, timer de 10ms observado durante quatro segundos. Resultado bruto em `dev4-benchmark-comparison.json`.

No ensaio registrado, a abertura mediana foi aproximadamente 0,189 s na dev3 e 0,299 s na dev4; RSS pronto, aproximadamente 78,6 MiB e 85,1 MiB. O maior intervalo observado entre ticks caiu de cerca de 26 ms para 16 ms. São medidas de um cenário local, não garantia de desempenho: a revisão adiciona controles/tema e ficou um pouco maior em RAM, embora elimine redesenhos e consultas desnecessários e reduza o pacote. Não se afirma redução de memória nem benchmark de Windows.

## Não executado

Windows real sem Python, duplo clique VBS/BAT, WinForms, atalhos, task scheduler/schtasks, assinatura Authenticode real, Edge corporativo, VPN, SSO/MFA, Excel bloqueando arquivo, cancelamento/atualização/rollback do produto instalado. O PowerShell 7 em Linux verifica sintaxe e auxiliares portáveis; não homologa Windows PowerShell 5.1. Não há certificado de assinatura e não se promete aceitação por SmartScreen/Defender.

Referências técnicas usadas para a reparação mantida: https://learn.microsoft.com/en-us/microsoft-edge/webdriver/ e https://www.selenium.dev/documentation/selenium_manager/ . O driver precisa corresponder aos três primeiros componentes da versão do Edge; a resolução usa os mecanismos oficiais existentes. PowerShell de teste: versão 7.4.13 oficial, SHA-256 `59e5df675dacbfe45374c32c1bf2480168a33243423c9b19252d0476fd1b748c`.

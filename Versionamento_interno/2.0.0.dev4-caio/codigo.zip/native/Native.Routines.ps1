# Guided editor for the same Python configuration used by the application and agent.
function Edit-Routine([int]$Index) {
    if ($Index -lt 0 -or $null -eq $script:config) { return }
    $routine = $script:config.routines[$Index]
    $dialog = New-Object Windows.Forms.Form
    $dialog.Text = (T 'Editar rotina') + ' - ' + $routine.label
    $dialog.Size = New-Object Drawing.Size(760, 680)
    $dialog.StartPosition = 'CenterParent'
    $dialog.Font = $form.Font
    $dialog.BackColor = [Drawing.Color]::FromArgb(243,246,250)
    $dialog.ForeColor = [Drawing.Color]::FromArgb(51,51,51)
    $tip = New-Object Windows.Forms.ToolTip
    $labels = @('Frequência','Dias da semana','Horários próprios','Ordem na fila','Script Python','Versão do script','Subcomando do script')
    $tops = @(20,90,160,290,340,390,440)
    for ($i=0;$i -lt $labels.Count;$i++) {
        $label = New-Object Windows.Forms.Label
        $label.Text = T $labels[$i]
        $label.SetBounds(20,$tops[$i],680,24)
        $dialog.Controls.Add($label)
    }
    $frequency = New-Object Windows.Forms.ComboBox
    $frequency.DropDownStyle = 'DropDownList'
    $frequency.SetBounds(20,48,690,30)
    $frequency.Items.AddRange(@((T 'Diária: um sucesso por data'),(T 'Semanal: um sucesso por semana'),(T 'Todos os horários: um sucesso por ocorrência'),(T 'Somente dias úteis: um sucesso por dia de segunda a sexta')))
    $codes = @('daily','weekly','every_run','weekdays')
    $frequency.SelectedIndex = [Array]::IndexOf($codes,[string]$routine.schedule.frequency)
    $dialog.Controls.Add($frequency)
    $days = @()
    $names = @('Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado','Domingo')
    for ($i=0;$i -lt 7;$i++) {
        $day = New-Object Windows.Forms.CheckBox
        $day.Appearance = 'Button'
        $day.TextAlign = 'MiddleCenter'
        $name = T $names[$i]
        $day.Text = $name.Substring(0,1)
        $day.AccessibleName = $name
        $tip.SetToolTip($day,$name)
        $day.SetBounds((20+$i*60),120,50,32)
        $day.Checked = $routine.schedule.days -contains $i
        $dialog.Controls.Add($day)
        $days += $day
    }
    $frequency.Add_SelectedIndexChanged({
        for ($i=0;$i -lt 7;$i++) {
            $days[$i].Checked = if ($frequency.SelectedIndex -eq 3) { $i -lt 5 } elseif ($frequency.SelectedIndex -eq 1) { $i -eq 0 } else { $true }
        }
    })
    $times = New-Object Windows.Forms.ListBox
    $times.SetBounds(20,188,250,90)
    $times.Items.AddRange([object[]]$routine.schedule.times)
    $times.Sorted = $true
    $dialog.Controls.Add($times)
    $clock = New-Object Windows.Forms.DateTimePicker
    $clock.Format = 'Custom'; $clock.CustomFormat = 'HH:mm'; $clock.ShowUpDown = $true
    $clock.SetBounds(290,188,100,30)
    $dialog.Controls.Add($clock)
    $add = New-Object Windows.Forms.Button
    $add.Text = T 'Adicionar horário'; $add.SetBounds(410,186,240,32)
    $add.Add_Click({ $value=$clock.Value.ToString('HH:mm'); if (-not $times.Items.Contains($value)) { $times.Items.Add($value) | Out-Null } })
    $dialog.Controls.Add($add)
    $remove = New-Object Windows.Forms.Button
    $remove.Text = T 'Retirar horário'; $remove.SetBounds(410,228,240,32)
    $remove.Add_Click({ if ($times.SelectedIndex -ge 0) { $times.Items.RemoveAt($times.SelectedIndex) } })
    $dialog.Controls.Add($remove)
    $order = New-Object Windows.Forms.ComboBox
    $order.DropDownStyle='DropDownList'; $order.SetBounds(210,285,120,30)
    for ($i=1;$i -le $script:config.routines.Count;$i++) { $order.Items.Add([string]$i) | Out-Null }
    $ordered = @($script:config.routines | Sort-Object order,id)
    $order.SelectedIndex = [Array]::IndexOf($ordered,$routine)
    $dialog.Controls.Add($order)
    $scriptPath = New-Object Windows.Forms.TextBox
    $scriptPath.Text = $routine.script; $scriptPath.SetBounds(210,336,500,30)
    $dialog.Controls.Add($scriptPath)
    $version = New-Object Windows.Forms.TextBox
    $version.Text = $routine.script_version; $version.SetBounds(210,386,500,30)
    $dialog.Controls.Add($version)
    $commandBox = New-Object Windows.Forms.TextBox
    $commandBox.Text = $routine.command; $commandBox.SetBounds(210,436,500,30)
    $dialog.Controls.Add($commandBox)
    $enabled = New-Object Windows.Forms.CheckBox
    $enabled.Text = T 'Habilitar esta rotina'; $enabled.Checked = $routine.enabled; $enabled.SetBounds(20,480,290,28)
    $dialog.Controls.Add($enabled)
    $browser = New-Object Windows.Forms.CheckBox
    $browser.Text=T 'Este script utiliza o navegador Edge'; $browser.Checked=$routine.requires_browser; $browser.SetBounds(330,480,390,28)
    $dialog.Controls.Add($browser)
    $help = New-Object Windows.Forms.Label
    $help.Text=T 'Semanal começa no primeiro dia selecionado. Dias extras recuperam pendências. Alterar a ordem reorganiza as demais posições automaticamente.'
    $help.SetBounds(20,518,690,50); $dialog.Controls.Add($help)
    $ok=New-Object Windows.Forms.Button
    $ok.Text=T 'Salvar'; $ok.SetBounds(470,580,110,34)
    $ok.Add_Click({
        $chosen=@(for ($i=0;$i -lt 7;$i++) { if($days[$i].Checked){$i} })
        if ($chosen.Count -eq 0 -or $times.Items.Count -eq 0) { Show-NativeError (T 'Selecione ao menos um dia e um horário.'); return }
        $routine.schedule.frequency=$codes[$frequency.SelectedIndex]
        $routine.schedule.days=$chosen
        $routine.schedule.weekday=$chosen[0]
        $routine.schedule.times=@($times.Items | ForEach-Object {[string]$_})
        $routine.script=$scriptPath.Text.Trim()
        $routine.script_version=$version.Text.Trim()
        $routine.command=$commandBox.Text.Trim()
        $routine.requires_browser=$browser.Checked
        $routine.enabled=$enabled.Checked
        $others=New-Object 'Collections.Generic.List[object]'
        foreach($r in $ordered){if($r.id -ne $routine.id){$others.Add($r)}}
        $others.Insert($order.SelectedIndex,$routine)
        for($i=0;$i -lt $others.Count;$i++){$others[$i].order=$i}
        $dialog.DialogResult='OK'; $dialog.Close()
    })
    $dialog.Controls.Add($ok)
    $cancelEdit=New-Object Windows.Forms.Button
    $cancelEdit.Text=T 'Cancelar'; $cancelEdit.SetBounds(600,580,110,34); $cancelEdit.DialogResult='Cancel'
    $dialog.Controls.Add($cancelEdit)
    [void]$dialog.ShowDialog($form)
    $tip.Dispose(); $dialog.Dispose()
    Refresh-RoutineRows
}

function Refresh-RoutineRows {
    $routines.Rows.Clear()
    $destinations.Rows.Clear()
    foreach ($routine in $script:config.routines) {
        $dayNames = @('Seg','Ter','Qua','Qui','Sex','Sáb','Dom')
        $daysText = @($routine.schedule.days | ForEach-Object { T $dayNames[[int]$_] }) -join ', '
        $routines.Rows.Add([object[]]@([bool]$routine.enabled, [string]$routine.label, [string]$routine.schedule.frequency, ($routine.schedule.times -join ', '), $daysText, ([int]$routine.order+1))) | Out-Null
        $destinations.Rows.Add([object[]]@([string]$routine.label,[string]$routine.target)) | Out-Null
    }
}

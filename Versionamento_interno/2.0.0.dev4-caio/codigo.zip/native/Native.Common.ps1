﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-NativeJson([string]$Path) {
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Write-NativeJson([string]$Path, $Value) {
    $parent = Split-Path -Parent $Path
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $temporary = $Path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($temporary, ($Value | ConvertTo-Json -Depth 64), (New-Object Text.UTF8Encoding($false)))
    if ([IO.File]::Exists($Path)) {
        $previous = $temporary + '.previous'
        [IO.File]::Replace($temporary, $Path, $previous)
        [IO.File]::Delete($previous)
    } else {
        [IO.File]::Move($temporary, $Path)
    }
}

function Quote-NativeArgument([string]$Value) {
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}

function Start-HiddenProcess([string]$File, [string[]]$Arguments, [string]$WorkingDirectory) {
    if (-not [IO.File]::Exists($File)) { throw "Componente ausente: $File" }
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $File
    $info.Arguments = (($Arguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' ')
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    $info.WorkingDirectory = $WorkingDirectory
    return [Diagnostics.Process]::Start($info)
}

function Start-NativeBridge([string]$Payload, $Request) {
    $work = Join-Path $env:LOCALAPPDATA ('Orquestrador-Teste\bootstrap\' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($work) | Out-Null
    $requestPath = Join-Path $work 'request.json'
    $resultPath = Join-Path $work 'result.json'
    $eventsPath = Join-Path $work 'events.jsonl'
    $cancelPath = Join-Path $work 'cancel.request'
    Write-NativeJson $requestPath $Request
    $runtime = Join-Path $Payload 'runtime\pythonw.exe'
    $arguments = @('-B', '-m', 'orquestrador_app.native_bridge', '--request', $requestPath, '--result', $resultPath, '--events', $eventsPath, '--cancel', $cancelPath)
    $process = Start-HiddenProcess $runtime $arguments (Join-Path $Payload 'src')
    return [pscustomobject]@{ Process = $process; Result = $resultPath; Events = $eventsPath; Cancel = $cancelPath; Work = $work; Started = [DateTime]::UtcNow }
}

function Get-NativeBridgeResult($Job) {
    if (-not $Job.Process.HasExited) { throw 'A operação ainda está em execução.' }
    if (-not [IO.File]::Exists($Job.Result)) {
        throw "O runtime não retornou diagnóstico (código $($Job.Process.ExitCode)). Verifique bloqueios de execução e dependências. Registro: $($Job.Work)"
    }
    $result = Read-NativeJson $Job.Result
    if (-not $result.ok) { throw $result.error }
    if ($Job.Process.ExitCode -ne 0) { throw "Processo terminou com código $($Job.Process.ExitCode)." }
    return $result.result
}

function Wait-OwnedParent([int]$OwnerPid, [double]$OwnerStarted, [int]$TimeoutSeconds = 120) {
    if ($OwnerPid -le 0) { return }
    $process = Get-Process -Id $OwnerPid -ErrorAction SilentlyContinue
    if ($null -eq $process) { return }
    $epoch = [DateTime]::SpecifyKind([DateTime]'1970-01-01', [DateTimeKind]::Utc)
    $actual = ($process.StartTime.ToUniversalTime() - $epoch).TotalSeconds
    if ([Math]::Abs($actual - $OwnerStarted) -gt 1.0) {
        throw 'O identificador do processo foi reutilizado. Nenhum processo foi encerrado.'
    }
    if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
        throw 'O aplicativo não encerrou no prazo. Atualização cancelada; nenhum processo foi forçado a fechar.'
    }
}

function Get-NativePayload([string]$PackageRoot, [string]$ScriptDirectory) {
    if ($PackageRoot) {
        $candidate = Join-Path $PackageRoot 'payload'
    } elseif (Test-Path -LiteralPath (Join-Path $ScriptDirectory 'payload\release.json')) {
        $candidate = Join-Path $ScriptDirectory 'payload'
    } else {
        $candidate = Split-Path -Parent $ScriptDirectory
    }
    if (-not (Test-Path -LiteralPath (Join-Path $candidate 'release.json'))) {
        throw 'Extraia o ZIP completo antes de abrir o instalador. O payload não foi encontrado.'
    }
    return [IO.Path]::GetFullPath($candidate)
}

function Open-NativeApplication([string]$DataRoot) {
    $current = Read-NativeJson (Join-Path $DataRoot 'installation.json')
    if (($current.PSObject.Properties.Name -contains 'distribution') -and $current.distribution -eq 'native-scripts') {
        $launcher = Join-Path $DataRoot 'launch\Iniciar.vbs'
        $hostPath = Join-Path $env:WINDIR 'System32\wscript.exe'
        Start-HiddenProcess $hostPath @('//Nologo', $launcher) $DataRoot | Out-Null
    } elseif ($current.owner -eq 'orquestrador-app-v1') {
        # A rollback may restore the preceding test edition, distributed as EXE.
        $executable = [IO.Path]::GetFullPath([string]$current.executable)
        $managed = [IO.Path]::GetFullPath((Join-Path $DataRoot 'app')) + [IO.Path]::DirectorySeparatorChar
        if (-not $executable.StartsWith($managed, [StringComparison]::OrdinalIgnoreCase)) { throw 'Versão anterior fora da pasta gerenciada.' }
        Start-HiddenProcess $executable @('--data-root', $DataRoot) $DataRoot | Out-Null
    } else { throw 'Instalação não reconhecida para abertura.' }
}

function Show-NativeError([string]$Message) {
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show($Message, 'Orquestrador', [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Error) | Out-Null
}

# Registro técnico da distribuição por scripts

Versão: **2.0.0.dev3**, teste. Base preservada: **2.0.0.dev2**. Método de versionamento: snapshots internos e SHA-256. Branch/commit/tag novos: não se aplicam; nenhum comando Git foi executado nesta revisão, conforme orientação do usuário.

## Decisões implementadas

- O produto é distribuído como ZIP completo. Instalar.vbs é a entrada gráfica preferida, com Instalar.bat como alternativa. Um BAT não garante ausência absoluta de um flash de CMD.
- Wizard nativo em PowerShell/WinForms; núcleo transacional em Python compartilhado com manutenção. A interface operacional PySide6 e seus seis painéis continuam no mesmo produto.
- CPython Windows embutido e dependências privadas incluídos. Não há instalação manual de Python nem venv dependente do Python global. Há executáveis oficiais de runtime internos; não há Orquestrador.exe personalizado na nova distribuição.
- Update.ps1 é um processo externo. Aguarda encerramento do PID original, valida o instante de criação e não força processos alheios. Ativação usa outra pasta de versão, sem substituir runtime em uso.
- Hashes, backup obrigatório, health check offline com versão explícita, diário e rollback protegem configuração, SQLite, extras, tarefas e atalhos. A recuperação não usa autenticação ou VPN como critério de defeito da versão.
- Não se inventou endereço de atualização. Feed começa desligado; o usuário pode importar um ZIP ou configurar HTTPS. Não se executa alteração persistente de políticas de execução nem exclusão do Defender.
- Extratores, suas URLs, seletores e contratos não foram alterados. Caminhos operacionais são redirecionados pelo modo de teste já existente. O JSON legado com caminhos pessoais não faz parte do payload operacional.

## Comandos principais executados

```text
uv sync --frozen
uv lock
uv export --frozen --no-dev --no-emit-project --no-hashes --output-file requirements-runtime-portable.txt
python tools/prepare_windows_payload.py --output build/runtime-windows --cache build/downloads
python tools/build_native_zip.py --runtime build/runtime-windows --output build/native-release
python -m pytest --junitxml=docs/evidencias/native-tests.xml -q
ruff check orquestrador_app desktop_tests tools desktop_entry.py
ruff format --check orquestrador_app desktop_tests tools desktop_entry.py
mypy --platform win32
python -m orquestrador_app --health-check --health-output docs/evidencias/native-source-health.json
pip-audit -r docs/evidencias/native-audit-windows-inputs.txt --no-deps --disable-pip --format json -o docs/evidencias/native-audit-windows-full.json
pwsh -NoLogo -NoProfile -File tools/test_native_powershell.ps1
python tools/verify_native_artifact.py --archive <ZIP gerado> --scratch <pasta de validação isolada> --output docs/evidencias/native-artifact-validation.json
```

Os comandos Python, Ruff, mypy e pip-audit utilizaram o ambiente virtual isolado .venv. PowerShell 7.4.13 Linux foi obtido da distribuição oficial e teve o hash conferido; não foi usado como evidência de execução do Windows PowerShell 5.1. Houve uma tentativa de atualização offline do lock sem metadados suficientes no cache; a resolução normal seguinte concluiu. O teste PowerShell identificou uma incompatibilidade no terceiro argumento nulo de File.Replace; a gravação atômica foi corrigida e o teste passou.

## Resultados e limites

150 testes Python passaram, com 7 subtestes. Nove verificações PowerShell passaram. Ruff, formatação e mypy passaram; auditoria das 41 entradas Windows não encontrou vulnerabilidades conhecidas. Os 42 inputs (runtime + wheels) tiveram seus hashes conferidos. O payload tem 4.585 arquivos, todos conferidos na extração do ZIP. Os cinco extratores e os 106 arquivos da baseline preservada tiveram hashes comparados.

Os testes de transação usam runtime de fixture, tarefas/atalhos falsos e health injetado. O health real do código executou em CPython Linux 3.12.14, com cinco extratores e seis abas; não executou os binários Windows CPython 3.13.16. A sintaxe de WinForms foi analisada; a janela WinForms não foi renderizada neste host. A validação PE é estrutural. Não há afirmação de certificado próprio, aprovação pelo SmartScreen, ausência visual de console ou homologação Windows.

Não executados: Windows sem Python global, duplo clique em VBS/BAT, WinForms, atalhos COM reais, Agendador real, atualização/reparo/cancelamento/rollback completos pela interface Windows, SSO/MFA, VPN, interrupção real de downloads e bloqueio por Excel. Nenhum benchmark Windows foi produzido; números de revisões antigas não são apresentados como benchmark desta distribuição.

Consulte MATRIZ_SCRIPTS.md e README_SCRIPTS.md. A nova orientação de ZIP/scripts prevalece sobre referências históricas a entrega exclusiva de EXE em README_TESTE.md, README_DESKTOP.md e no spec PyInstaller, que foram mantidos para preservar histórico e compatibilidade técnica.

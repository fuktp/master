# Comandos executados na inspeção

Executados no workspace isolado desta sessão em 21/10/2026. Os comandos abaixo são evidências técnicas; não são etapas para o usuário final. Não há executável novo disponível.

## Acesso e preservação

- Inventário inicial com `rg --files`, `pathlib` e `platform.platform()`: workspace vazio, sem Git.
- Tentativa de leitura da URL da pasta SharePoint: ferramenta de navegação informou URL inacessível; integração ainda não instalada/conectada.
- Busca e materialização autenticada de `pipefy_orchestrator_v1.3.0.zip`, versão de arquivo 8.
- Leitura de índice, CRC por `zipfile.ZipFile.testzip()` e SHA-256 por `hashlib.sha256`.
- Validação de caminhos do ZIP, extração em `preserved-v1.3.0`, cópia em `orquestrador`, geração do manifesto com tamanho e SHA-256 por arquivo.
- Inspeção de README, Python, JSON, requisitos, testes, PowerShell e CMD com `rg`, `sed`, `cat` e AST. Não foi realizado download dos destinos corporativos dos extratores.
- Inspeção de padrões de chave privada/tokens antes do primeiro commit; nenhum padrão encontrado. Os identificadores e endpoints já presentes no código legado foram preservados no snapshot, sem publicar novas credenciais.

```bash
git init --initial-branch=main
git config user.name Codex
git config user.email codex@localhost
git add .
git commit -m 'Preserve exact v1.3.0 source from Library version 8'
git tag -a v1.3.0 -m 'Preserved original v1.3.0; archive hash in external source manifest'
git switch -c feature/windows-desktop-app
git status --short
git rev-parse 'v1.3.0^{}'
```

## Ambiente e testes

```bash
uv venv .venv --python python3
uv pip install --python .venv/bin/python 'PySide6>=6.8,<7' 'selenium>=4.34.2,<5' 'pandas>=2.2.3,<3' 'openpyxl>=3.1.5,<4' 'requests>=2.32.5,<3' 'tzlocal>=5.3,<6' 'psutil>=7,<8' 'pytest>=8,<10' 'ruff>=0.14,<1' 'mypy>=1.18,<2' 'pip-audit>=2.9,<3' 'pyinstaller>=6.16,<7'
```

O ambiente preparado serviu somente à inspeção. A instalação de PySide6/PyInstaller não constitui implementação ou build. As versões resolvidas estão em `evidencias/ambiente-inspecao.txt`.

Comando efetivamente usado para a suíte, retornando 40 testes aprovados:

```bash
.venv/bin/python - <<'PY'
import socket, unittest, sys
def denied(*args, **kwargs):
    raise RuntimeError('Network disabled for baseline tests')
socket.socket.connect = denied
socket.create_connection = denied
suite = unittest.defaultTestLoader.discover('tests')
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
PY
```

## Análise estática e auditoria

Primeiras verificações: Ruff herdou configuração externa e mypy usou alvo Linux. Foram registradas como diagnósticos iniciais, sem alterar código. As checagens isoladas/dirigidas abaixo distinguem esses fatores:

```bash
.venv/bin/ruff check pipefy_orchestrator.py automation_schedule.py update_installation.py scripts tests --output-format=json
.venv/bin/ruff format --check pipefy_orchestrator.py automation_schedule.py update_installation.py scripts tests
.venv/bin/mypy --follow-imports=skip --ignore-missing-imports pipefy_orchestrator.py automation_schedule.py update_installation.py scripts
.venv/bin/ruff check --isolated --select E4,E7,E9,F,I --output-format=json pipefy_orchestrator.py automation_schedule.py update_installation.py scripts tests
.venv/bin/ruff format --isolated --check pipefy_orchestrator.py automation_schedule.py update_installation.py scripts tests
.venv/bin/mypy --platform win32 --follow-imports=skip --ignore-missing-imports pipefy_orchestrator.py automation_schedule.py update_installation.py scripts
.venv/bin/pip-audit --format=json --progress-spinner=off --timeout=10
uv pip freeze --python .venv/bin/python
```

A primeira chamada de auditoria foi iniciada no diretório pai e falhou antes de executar por `.venv/bin/python` não existir naquele diretório (saída 127). A chamada foi corrigida para o diretório `orquestrador` e a auditoria concluiu com saída 0. Os detalhes desse resultado estão em `evidencias/auditoria.json`.

As verificações foram capturadas por `subprocess.run` com timeout. Saídas de lint foram reduzidas a arquivo, código, localização e mensagem para evitar exportar trechos de configuração com destinos internos. Nenhum formatador foi executado em modo de escrita.

## Registro técnico e backup

Após os checks: manifesto comparado novamente com os 18 arquivos; inclusão exclusiva de `.gitignore` e `docs`; commit de inspeção. O manifesto de entrega contém o commit final e os hashes do relatório e bundle.

```bash
git add .gitignore docs
git commit -m 'Record source inspection, preservation evidence and desktop conversion blockers'
git bundle create ../entrega/Orquestrador_Inspecao_v1.3.0.bundle --all
git bundle verify ../entrega/Orquestrador_Inspecao_v1.3.0.bundle
git clone --branch feature/windows-desktop-app ../entrega/Orquestrador_Inspecao_v1.3.0.bundle ../verificacao-bundle
```

O clone de verificação foi comparado com o manifesto por SHA-256. Backup do código recebido e histórico local são distintos de backup de produção: estado, configurações adicionais e tarefas originais não acessíveis não foram incluídos por inferência.

Não foram executados: build Windows, instalação do produto, criação de atalhos, instalação/remoção de tarefas Windows, login corporativo, conexão VPN, abertura do Excel, extrações reais, benchmark da interface ou teste de rollback do aplicativo novo.

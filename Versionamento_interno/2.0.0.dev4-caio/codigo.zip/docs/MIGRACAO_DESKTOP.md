# Migração, backup, restauração e reversão

**Guia da implementação em desenvolvimento. Ainda não existe executável Windows gerado ou aceite nativo.** As ações abaixo estão implementadas na interface; não representam procedimentos já executados na máquina corporativa.

## Migração pelo wizard

1. No diagnóstico inicial, selecionar a configuração existente da v1.3.0.
2. Revisar os destinos, e-mail, perfil e driver. A migração mantém valores explícitos e mostra destinos indisponíveis. Escolher cada pasta quando houver ambiguidade de OneDrive.
3. Conferir rotinas, dias e horários próprios. Para `every_run` legado, os disparos globais viram horários da rotina; para daily/weekly, o antigo horário mínimo vira horário próprio. Os horários podem então ser editados livremente.
4. Revisar a mudança antes de aplicar. Até essa etapa, é possível voltar/cancelar. Na etapa transacional, os botões de cancelamento/volta são bloqueados; interrupção do processo é tratada pelo journal na próxima abertura.
5. A instalação cria uma versão separada, verifica o hash e executa smoke test privado, salva configuração e importa o último sucesso disponível. Registra tarefa própria e único atalho, desabilitando apenas tarefas legadas reconhecidas e incluídas no backup.

O pacote recebido não tem o estado/tarefas reais. O importador só pode preservar o que estiver presente na instalação selecionada. Scripts adicionais são copiados para `extras`, com hash autorizado. Perfis, cookies e senhas não são copiados para Git ou exportação portátil. O perfil deve ser escolhido/revalidado localmente.

As configurações da máquina ficam sob o perfil local do usuário. Preferências exportadas omitem caminhos, ambiente, argumentos, hashes de autorização, perfil e driver. A importação exibe uma prévia, rejeita parâmetros de execução externos e valida antes de gravar.

## Relatórios

Publicação utiliza staging e substituição no diretório final. O arquivo anterior é copiado, sincronizado e verificado por SHA-256 antes de qualquer substituição. Se esse backup obrigatório falhar, a publicação para. Um bloqueio pelo Excel preserva o anterior; o retry configurado reutiliza o staging.

No catálogo da aba Diagnóstico e manutenção é possível listar, validar e restaurar versões. Restauração adquire lock e faz backup do arquivo atual. O histórico registra operação `restore`; o último sucesso de extração não é alterado.

Retenção por arquivo final: o backup mais recente sempre permanece. Os demais são removidos se excederem quantidade, idade ou orçamento de bytes, sem atingir itens não gerenciados. O backup mais recente pode, sozinho, superar o orçamento; ele permanece preservado. Backup adulterado interrompe a limpeza e gera aviso. Backups do aplicativo são separados e não são apagados por essa política de relatórios.

Eventos valida colunas, ordem e chave, rejeita valores de chave vazios, mantém deduplicação e não regrava o histórico se não houver linha nova. Separador/codificação configurados precisam corresponder ao arquivo já existente; uma divergência deve ser corrigida explicitamente. Não há conversão silenciosa do histórico.

Arquivos locais de Clientes, Procedimentos, Eventos e ATMS passam pelos validadores reais e pela mesma publicação protegida, sem navegador. Publicação local não é registrada como nova extração nem consome frequência.

## Atualização e rollback

Uma atualização fica bloqueada por execução ativa no núcleo desktop. Antes de ativar a versão nova, o snapshot inclui configuração, SQLite consistente, extras, ponteiro de versão, binário anterior quando disponível e XML das tarefas identificadas. O manifesto verifica todos os arquivos copiados.

Falhas internas em cópia, hash, migração, criação de tarefa/atalho ou health check acionam restauração automática. O journal distingue preparação, ativação, commit, rollback e rollback incompleto. Se a recuperação falhar, o erro permanece registrado e não é declarado sucesso. O health check não usa VPN, site externo ou extração; uma indisponibilidade externa não provoca rollback da instalação.

Para rollback manual, a aba de manutenção solicita um backup gerenciado de aplicativo. Antes de restaurar, preserva o estado atual em outro checkpoint. Um backup de relatório não pode ser usado como backup do aplicativo.

Rollback nativo entre versões do executável, tarefas reais e concorrência de processos Windows ainda exige validação. A revisão atual não migra automaticamente tarefas antigas desconhecidas e não remove fisicamente o executável que está em uso durante desinstalação.

## Critérios de liberação Windows ainda necessários

- Build no Windows, revisão do PE GUI e execução do health check do EXE.
- Máquina de teste limpa sem Python: primeira abertura, cancelamento antes de aplicar, instalação, reabertura, reparo, atualização e falhas induzidas com reversão.
- Confirmar único atalho e tarefa executando o mesmo EXE, com usuário conectado, janela principal fechada e horários exclusivos por rotina.
- Ambiente autorizado separado: login real, sessão expirada, VPN, causas inconclusivas, servidor indisponível, interrupção de download e bloqueio real pelo Excel.
- Conferir notificações nativas, clique para detalhe, sinalização da janela e countdown de 30 segundos.
- Verificar processos/Job Object, locks, fuso, retomada, histórico e versões restauradas, inclusive durante atualização e monitor ativo.
- Completar remoção física gerenciada e revisar os limites registrados no README antes de aprovar distribuição final.

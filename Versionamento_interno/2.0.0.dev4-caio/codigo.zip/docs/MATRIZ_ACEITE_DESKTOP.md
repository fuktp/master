> Revisão atual: **2.0.0.dev2, teste isolado, sem Git**. Consulte README_TESTE.md e MATRIZ_TESTE_DEV2.md. O texto abaixo registra a implementação anterior; as evidências Windows continuam pendentes.

# Matriz de implementação e aceite

Data: 21/10/2026. Versão técnica `2.0.0.dev1`. **Resultado global: NÃO ACEITO como entrega final; `Orquestrador.exe` não gerado.**

Os números correspondem à seção 16 do pedido. “Local” significa Linux, arquivos sintéticos e, quando indicado, mocks. Não significa Windows aprovado.

| Requisito | Implementação | Teste/evidência | Resultado | Limitação |
| --- | --- | --- | --- | --- |
| 1. Preservação/branch/backup/isolamento | Tag v1.3.0 mantida, branch existente reutilizado, backup verificável, testes temporários | `desktop-preservation.json`: 18/18 originais idênticos; ATMS separado idêntico | Realizado para a fonte recebida | Não há Git/estado/tarefas originais de produção |
| 2. Horário próprio fora dos globais | `schedule.eligible`, monitor por minuto com avaliação por rotina | `test_own_time_outside_global_schedule`, horário 18:07 | Passou local | Agendador Windows real pendente |
| 3. Daily/every_run múltiplos horários | Ledger de períodos e ocorrências, recovery agrupado | Testes daily, every_run, force, não elegibilidade | Passou local | Não houve extração corporativa |
| 4. Semana/reinício/atraso/fuso | Semana ISO iniciando segunda, SQLite, ZoneInfo/tzlocal, janela de recuperação | Testes weekly, restart, fold de DST, próximo horário, freshness | Passou local | Troca real de fuso/relógio Windows pendente |
| 5. Migração/tarefas/GUI fechada | XML com InteractiveToken/IgnoreNew, tarefa única, agente separado da janela; backup/desativação do legado reconhecido | Teste XML, agente real Linux sem janela principal, rollback com backend fake | Parcial | Tarefas reais não inventariadas; nomes antigos desconhecidos não migrados |
| 6. Grafo/ordem/validade | Detecção de ciclos, same_chain/fresh_success, bloqueio propagado, fila determinística | Falha/cancelamento/disabled/ciclos/janela/fail-fast em `test_engine.py` | Passou local | Perfil e fila reais Windows pendentes |
| 7. Conectividade/inconclusivo | DNS/TCP/HTTP/interfaces explicitamente configuradas; sem VPN inferida de sintoma único | Casos Evidence parametrizados e servidor comprovado | Passou em testes de classificação | Probes reais corporativos não executados |
| 8. KWMS 2 × /30 s/código 20 | Adapter preserva duas tentativas; espera cooperativa; skip sem retry externo e continua lote | Testes legados + adapter novo; espera solicitada 30 ao mock; código 20 no engine | Passou em mocks | Não foi cronometrada VPN real nem sinalização Windows |
| 9. Retry por categoria | Categorias, backoff, timeout total; arquivo bloqueado republica staging | Limites, auth sem loop, código 20, retry sem reextração | Passou local/mocks | Casos HTTP/download reais pendentes |
| 10. SSO/MFA | Extratores preservados, ação login separada, interação exigida em agendamento quando necessário | Login fake não consome frequência; inspeção dos adaptadores | Parcial | Login real não executado |
| 11. Download/invalidade/Excel | Validadores reais, temporário irmão, backup antes do replace | XLSX inválido/vazio/parcial, PermissionError e preservação do anterior | Passou local/mocks | Bloqueio por Excel e interrupção real pendentes |
| 12. Backup/retenção/restauração | Catálogo com hash, backup obrigatório, retenção só de itens próprios, restore sob lock | Cópia, hash, backup negado, adulteração, retenção e restore | Passou com arquivos reais sintéticos | Compartilhamento/OneDrive/Windows não testados |
| 13. Eventos/local sem navegador | Reader/schema original, validação de chaves, merge idempotente, adaptadores locais | Workers reais de Clientes/Procedimentos/Eventos/ATMS; reprocessamento Eventos | Passou local | Dados sintéticos; não certifica dados corporativos |
| 14. Concorrência/perfil/órfãos | Locks OS, execução serial, perfil protegido, processo/grupo/Job Object | Dono ativo, morte de processo e recuperação; processo alheio preservado | Passou no Linux | Job Object e concorrência real GUI/Agendador/update Windows pendentes |
| 15. Pausar/retomar/cancelar | Checkpoints, revalidação na retomada, limite cooperativo de oito segundos, cleanup de subprocessos próprios | Cancelamento no checkpoint; processo próprio encerrado; controle GUI presente | Parcial | Pausa/retomada real de navegador e escrita sob Windows pendentes |
| 16. Painel/notificações/atraso | PySide6 real, threads, fila deduplicada, freshness e agente | Controles construídos, timer responsivo, fila processada por agente Linux sem janela principal | Parcial | Notificação nativa e efeito visual Windows não testados; algumas opções avançadas em JSON |
| 17. OneDrive/máquina/caminhos | Ambiente+registro Windows, contas distintas, seleção explícita, validação e campos de pasta | Duas contas em teste, caminhos com espaços/acentos nos workers | Parcial | Registro e outro usuário real Windows pendentes |
| 18. ATMS/extras | ATMS existente recuperado sem alteração, adapter real; cadastro/descoberta/hash | Publicação ATMS sem navegador; script adicional real e rejeição após alteração | Passou local | Exportação ATMS via browser e scripts desconhecidos não executados |
| 19. Windows limpo/sem console | Spec one-file GUI, runtime privado e gate PE/subsistema | `build_windows.py` recusou Linux corretamente | NÃO EXECUTADO/NÃO ATENDE ENTREGA | EXE inexistente; sem máquina Windows sem Python |
| 20. Atualização e rollback | Journal, staging, backup, ativação, recovery; health sem rede | Falhas induzidas em cópia, health, migração, ativação e pós-check; restauração de config/ponteiro/tarefa fake | Passou em integração com backend fake | Binário usado nos testes é fixture, não aplicativo Windows; concorrência nativa pendente |
| 21. Agendador real | Backend schtasks/COM, usuário interativo, tarefa própria | XML inspecionado/testado | NÃO EXECUTADO | Sem sessão Windows nesta execução |
| 22. Um EXE + wizard completo | Um entry point, oito páginas, detecta estado/versão, atualização/reparo e manutenção no produto | Wizard real construído em Qt; teste de instalação usa fixtures | NÃO ATENDE ENTREGA FINAL | Não há executável gerado ou demonstração ponta a ponta |
| 23. Atalho/interface únicos/mesmo EXE | Atalho único e ação da tarefa no mesmo executável, modos internos | Teste de XML e inspeção do instalador/spec | Implementado em código; NÃO VALIDADO NATIVAMENTE | Nenhum atalho real Windows criado |

## Verificações transversais

| Verificação | Resultado | Escopo |
| --- | --- | --- |
| Pytest | 104 testes e 7 subtestes aprovados | 40 testes legados + 64 novos; sem acesso corporativo |
| Ruff | Aprovado | Camada desktop, testes novos e ferramentas; legado preservado sem reformatar |
| Ruff format | Aprovado | 30 arquivos da camada nova |
| Mypy | Aprovado | 21 arquivos novos, alvo estático win32, mesmo comando do CI; imports com modo silent |
| Dependências | 31 de runtime e 64 no conjunto completo, zero alertas nas consultas finais | Ambiente Linux; dependências exclusivas Windows não instaladas aqui |
| Health check fonte | Aprovado | Cinco parsers, cinco abas, oito páginas, SQLite temporário, sem rede |
| Benchmark | Medição Linux/offscreen registrada | Uma amostra; não representa Windows/EXE |
| Build Windows | Não executado; bloqueio de plataforma confirmado | Nenhum `.exe` produzido |
| Assinatura do produto | Não executada | Certificado não fornecido; nenhuma afirmação de assinatura |

## Pendências adicionais explícitas

Desinstalação física do EXE em uso ainda depende da conclusão de um mecanismo gerenciado; a revisão remove tarefa/atalho e marca a versão para remoção posterior. Não há limpeza de temporários pela interface nem limite individual da captura stdout. Ainda são necessários inventário das tarefas de produção e validação nativa de concorrência durante update/rollback. O método de empacotamento e o workflow não substituem o build nem comprovam um produto instalável.

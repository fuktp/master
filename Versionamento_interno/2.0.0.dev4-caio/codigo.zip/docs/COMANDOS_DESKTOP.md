# Registro de comandos e evidências

Esta execução reutilizou o bundle de inspeção existente, sem apagar arquivos de produção ou recriar tags. Os caminhos abaixo são da cópia isolada de desenvolvimento. Nenhum destes comandos foi exigido do usuário final.

## Preservação e versionamento

```bash
git clone inputs/Orquestrador_Inspecao_v1.3.0.bundle orquestrador
git -C orquestrador status --short --branch
git -C orquestrador log --oneline --all --decorate -5
git -C orquestrador bundle create ../preservation/pre-desktop.bundle --all
git diff --exit-code v1.3.0 -- pipefy_orchestrator.py automation_schedule.py update_installation.py pipefy_orchestrator.config.json requirements.txt README.md install_tasks.ps1 Atualizar_Instalacao.cmd Configurar_Automacoes.cmd Executar_Pipefy.cmd Instalar_Automacao_Pipefy.cmd scripts/kwms_alocacoes_tool_edge.py scripts/pipefy_clientes_tool_edge.py scripts/pipefy_eventos_tool_edge.py scripts/pipefy_procedimentos_tool_edge.py tests/test_extractors_paths.py tests/test_kwms_schedule.py tests/test_pipefy_orchestrator.py
```

Também foram executados scripts Python locais para CRC do ZIP, comparação byte a byte dos 18 arquivos, SHA-256, manifesto de preservação e comparação do ATMS com o artefato adicional recebido. Todos os 18 originais e o ATMS recuperado passaram. Nenhuma tarefa de produção ou perfil foi acessado.

## Ambiente e dependências

```bash
uv venv .venv
uv pip install --python .venv/bin/python PySide6==6.9.3 selenium==4.36.0 pandas==2.3.3 openpyxl==3.1.5 requests==2.32.5 psutil==7.1.0 pytest==8.4.2 ruff==0.14.1 mypy==1.18.2 pip-audit==2.9.0 pyinstaller==6.16.0
uv add --dev types-requests
uv lock
uv sync --frozen
uv export --frozen --no-dev --no-emit-project --no-hashes --format requirements-txt --output-file requirements-resolved.txt
uv export --frozen --no-emit-project --no-hashes --format requirements-txt --output-file requirements-all-resolved.txt
```

As versões finais efetivas estão integralmente fixadas em `pyproject.toml` e `uv.lock`, com hashes no lock. A primeira auditoria de runtime identificou Requests anterior à correção; a auditoria ampliada identificou Pytest anterior à correção. As duas dependências foram atualizadas e os exports/lock regenerados. O bootstrap UV do workflow foi alinhado à versão efetivamente usada: 0.12.23.

## Verificações executadas

```bash
.venv/bin/python -m pytest -q tests
.venv/bin/python -m pytest -q desktop_tests
.venv/bin/python -m pytest -q --junitxml=docs/evidencias/desktop-tests.xml
.venv/bin/ruff check --fix orquestrador_app desktop_tests tools desktop_entry.py
.venv/bin/ruff format orquestrador_app desktop_tests tools desktop_entry.py
.venv/bin/ruff check orquestrador_app desktop_tests tools desktop_entry.py
.venv/bin/ruff format --check orquestrador_app desktop_tests tools desktop_entry.py
.venv/bin/mypy --platform win32 --follow-imports skip orquestrador_app desktop_entry.py
.venv/bin/mypy --platform win32
.venv/bin/pip-audit --disable-pip --no-deps -r requirements-resolved.txt --format json -o docs/evidencias/desktop-dependency-audit.json
.venv/bin/pip-audit --disable-pip --no-deps -r requirements-all-resolved.txt --format json -o docs/evidencias/desktop-audit-all.json
QT_QPA_PLATFORM=offscreen .venv/bin/python -m orquestrador_app --health-check
QT_QPA_PLATFORM=offscreen .venv/bin/python -m tools.benchmark_gui
.venv/bin/python tools/build_windows.py
```

O último comando saiu com código 1 e a mensagem explícita de que o build não foi executado por ausência de Windows. Isso é confirmação do gate de plataforma, não um build aprovado. Nenhum `Orquestrador.exe` foi gerado. Os JSON/XML em `evidencias/` e o relatório final identificam resultados aprovados, diagnósticos iniciais e testes não executados.

O benchmark inicial detectou que o PID no contêiner não correspondia à montagem de `/proc`. O controle de processos recebeu fallback pelo objeto Popen/grupo próprio, e a medição de memória passou a usar `/proc/self/status`. A medição final é real e descreve esse método; não foram preenchidos números estimados.

Os testes automatizados bloqueiam conexão de rede no processo de testes. Subprocessos auxiliares usam apenas publicação local, scripts sintéticos ou agente com rotinas desabilitadas. A versão final não fez login corporativo, exportação real, instalação de tarefa, notificação nativa, alteração de driver ou instalação Windows.

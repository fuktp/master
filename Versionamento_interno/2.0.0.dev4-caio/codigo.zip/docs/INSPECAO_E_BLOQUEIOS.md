# Orquestrador v1.3.0 — inspeção e bloqueios de entrega

**Situação em 21/10/2026: conversão não implementada; Orquestrador.exe não gerado.**

Este documento registra trabalho efetivamente realizado. Não representa uma aplicação desktop, um projeto de interface, uma versão nova do produto nem aprovação de aceite. Nenhuma extração corporativa foi executada. Os 18 arquivos recebidos foram mantidos byte a byte.

## Fonte e limites de acesso

A pasta `extraction` do SharePoint indicada no pedido não ficou acessível nesta sessão. A tentativa de abertura retornou que a URL não é acessível pela ferramenta. Foi localizada uma integração SharePoint disponível, mas não instalada/conectada; disponibilizar sua conexão não equivale a obter acesso aos arquivos.

Foi encontrada e materializada uma cópia independente: `pipefy_orchestrator_v1.3.0.zip`, versão de arquivo 8, tamanho 95.035 bytes. O ZIP passou na verificação de CRC; seu SHA-256 é:

```
2beb586215d3927173dd62cbf8ed4b4d57b8638cb81a2e26cd3c1213fca55049
```

O pacote contém 18 arquivos. Seu README confirma que **ATMS não está incluído** e que extratores adicionais devem ser preservados a partir da instalação existente. Não foram recebidos `.git`, estado real de frequências, tarefas exportadas do Windows, arquivos finais ou scripts adicionais. Os perfis do navegador não foram acessados. Portanto, esta cópia permite inspecionar o núcleo v1.3.0, mas não comprova o conteúdo integral e atual da pasta original nem permite fazer backup do ambiente de produção.

## Preservação e Git

- A inspeção inicial encontrou o workspace vazio, sem repositório. O arquivo recebido também não contém Git.
- A descompactação original foi preservada em diretório separado. O manifesto `evidencias/source-manifest.json` contém os 18 nomes, tamanhos e hashes.
- O versionamento foi inicializado em uma **cópia de trabalho**, sem tocar na pasta corporativa.
- Commit que preserva a fonte recebida: `64d36a36c9c8dec9c31ce8b23c9f1dd8a5bdcbe8`.
- Tag anotada criada sem sobrescrita: `v1.3.0`.
- Branch de trabalho: `feature/windows-desktop-app`.
- Essa tag identifica um commit novo da cópia recebida. **Não é o commit original de produção**, pois o histórico Git original não foi disponibilizado.
- Os testes usaram diretórios temporários próprios. Não houve instalação ou alteração de tarefas reais.
- A comparação posterior confirmou os mesmos hashes dos 18 arquivos. Configuração e scripts originais não foram reescritos.

O bundle técnico contém esse histórico local e as evidências desta inspeção. Ele não é um instalador nem uma distribuição do aplicativo. O hash do bundle está no manifesto de entrega ao lado do arquivo entregue; um bundle não pode conter seu próprio hash.

## Inventário confirmado

| Componente | Entrada e comportamento observado |
| --- | --- |
| `pipefy_orchestrator.py` | `main`, `load_settings`, `Orchestrator`, `DriverGuard`; versão declarada 1.3.0 |
| CLI principal | `doctor`, `run`, `login`, `list-jobs`, `configure-schedules`; `--config`, `--debug`, `--version` |
| Execução | `run --job` repetível, `--delay-seconds`, `--skip-driver-check`, `--dry-run`, `--force` |
| Login | `login --job`, `--skip-driver-check`, `--dry-run`; não consome a frequência |
| Driver | `doctor --repair`, `--no-session-test`; cache, espelho HTTPS, comparação de versão, assinatura, backups e teste de sessão |
| Configuração de horários | `automation_schedule.py`; formulário Tkinter; `daily`, `weekly`, `every_run`; um horário inicial por rotina |
| Clientes | `scripts/pipefy_clientes_tool_edge.py`: `login`, `check-headless`, `run`, `replace`, instalação/remoção de tarefa, `inspect`, `requests` |
| Procedimentos | Interface equivalente a Clientes; conserva alias confirmado `Ticket KDSC` → `Ticket KDSC / Audit Tech` na validação |
| Eventos | `scripts/pipefy_eventos_tool_edge.py`: `run`, `merge`, login, diagnóstico, captura e tarefas; histórico incremental com rejeição de chaves vazias |
| KWMS | `scripts/kwms_alocacoes_tool_edge.py`: `run`, `login`; duas tentativas internas no caso classificado pelo legado como VPN, intervalo solicitado de 30 segundos e código 20 |
| Atualização | `update_installation.py --target`; cópia de arquivos e backup, mesclagem de configuração e preservação de scripts extras; sem transação completa com rollback automático |
| Agendamento | `install_tasks.ps1 -ConfigPath -TaskPrefix -Remove`; tarefas por horários globais, sessão interativa, execução limitada e `IgnoreNew` |
| Entradas Windows | `Atualizar_Instalacao.cmd`, `Configurar_Automacoes.cmd`, `Executar_Pipefy.cmd`, `Instalar_Automacao_Pipefy.cmd`; dependem de Python/launcher e comandos externos |
| Testes recebidos | `test_extractors_paths.py`, `test_kwms_schedule.py`, `test_pipefy_orchestrator.py`: 40 testes |
| Dependências declaradas | Selenium, pandas, openpyxl e requests com intervalos; não existe lockfile de distribuição no legado |
| ATMS | Referenciado pelo README; arquivo ausente do pacote recebido |

Os argumentos específicos dos extratores e as chaves de ambiente estão listados em `evidencias/inventario.json`. URLs, seletores e schemas existentes foram somente lidos; não foram inventados nem substituídos.

## Contratos, persistência e controle

| Área | Contrato observado na v1.3.0 |
| --- | --- |
| Configuração | `pipefy_orchestrator.config.json`, schema 1; descoberta `pipefy_*_tool_edge.py`, exclusões e jobs explícitos com precedência |
| Ambiente por rotina | `Job.environment`; opções e argumentos permitem placeholders de diretório, log e driver |
| Destino Clientes | `clientes/Clientes.xlsx`; publicação local pelo comando `replace`, validação de schema confirmado |
| Destino Procedimentos | `procedimentos/Procedimentos.xlsx`; publicação local por `replace` |
| Destino Eventos | `historico/historico_reports.csv`; chave padrão `Código`, alias de `ID`, aba/cabeçalho/separador/codificação configuráveis no extrator |
| Destino KWMS | Somente `Detalhes de Alocação_- Planos Aprovados e Baixados.xlsx` no destino configurado |
| Estado | `job_schedule_state.json`, último sucesso por rotina; `last_run.json` e `run_history.jsonl` |
| Locks | `RunLock` por lote com arquivo de PID; `FileLock` nos extratores para perfil, escrita, histórico e/ou execução |
| Processos | `Popen` com saída capturada; `CREATE_NO_WINDOW` no subprocesso em Windows; timeout e encerramento da árvore do PID próprio |
| Códigos principais | Orquestrador: 0 conclusão, 1 lote com falha, 2 erro, 3 configuração cancelada, 130 interrupção. KWMS: 0 sucesso, 1 erro, 20 ignorado/pendente, 130 interrupção |
| Estados principais | `success`, `failed`, `skipped`, `not_due`; não há grafo de dependências nem o conjunto completo de estados solicitado |
| Retry principal | `retries + 1`, intervalo por job; skip code 20 termina o retry externo e continua o lote mesmo com `continue_on_error=false` |
| Publicação | Temporário e `os.replace`; não há catálogo completo de versões de relatórios com restauração/retensão da nova especificação |

## Divergências e pontos de migração

1. Os horários do legado são limites de elegibilidade dentro de disparos globais. O README declara isso corretamente. A nova especificação exige outro modelo, com horários independentes e múltiplas ocorrências próprias.
2. A v1.3.0 associa `ERR_EMPTY_RESPONSE` diretamente à necessidade de VPN. A nova especificação exige evidências adicionais e categoria inconclusiva. Os testes legados aprovam a associação anterior; passar nesses testes não resolve a nova exigência.
3. O código mantém caminhos pessoais e e-mail fixo como valores padrão, inclusive no atualizador. Esses padrões precisam ser migrados para locais por usuário/computador e seleção explícita de destinos, preservando os contratos de arquivo.
4. O formulário existente é Tkinter e configura frequências. Não existe interface operacional completa nem wizard unificado PySide6.
5. O instalador atual depende de Python global e pip. Não existe executável distribuível com runtime privado.
6. O atualizador existente faz backups, mas não restaura automaticamente versão, estado e tarefas após falhas de migração/ativação.
7. Não há catálogo de versões de relatórios com backup obrigatório antes de substituição, retenção e restauração pela interface.
8. A verificação de assinatura distingue indisponibilidade de invalidade, mas `signature_status_is_invalid` não bloqueia `Unavailable`. Isso precisa ter tratamento explícito compatível com o requisito 14; não se pode afirmar que a verificação foi bem-sucedida.
9. A instalação de tarefas utiliza repetição do próprio Agendador, além dos retries por job e das duas tentativas KWMS. A migração precisa eliminar multiplicação de tentativas e disparos duplicados, com inventário das tarefas reais.
10. ATMS e outros scripts podem existir na instalação original; não é possível comprovar preservação funcional de arquivos não recebidos.

## Verificações efetivamente realizadas

Ambiente: Linux x86_64, kernel 6.18.55, CPython 3.12.14. Ambiente virtual isolado `.venv`; versões efetivamente instaladas em `evidencias/ambiente-inspecao.txt`. Essa lista é um registro do ambiente de inspeção, não um lockfile aprovado do aplicativo novo.

| Verificação | Resultado observado | Limite |
| --- | --- | --- |
| Integridade ZIP | Aprovada, CRC sem falha | Apenas o pacote recebido |
| Hashes de preservação | 18/18 arquivos iguais ao original | Não inclui produção inacessível |
| Suíte legada | **40 testes, 0 falhas, 0 erros; 0,466 s** reportados pelo unittest | Arquivos sintéticos, mocks, não é teste Windows |
| Rede nos testes | `socket.socket.connect` e `socket.create_connection` bloqueados no processo que executou a suíte | Processos auxiliares dos testes executaram código fake/local; nenhuma extração real |
| Lint explícito e isolado | Reprovado: **18 apontamentos**, saída 1 | Regras `E4,E7,E9,F,I`: 11 I001, 1 F401, 6 E402 |
| Formatação isolada | Reprovada: **10 arquivos** seriam reformatados, saída 1 | Modo check; nenhum arquivo reformatado |
| Tipos com alvo win32 | Reprovado: **18 erros em 3 arquivos**, saída 1 | Análise estática em Linux; inclui divergências de stubs nos ramos POSIX e erros de tipos; não é execução Windows |
| Auditoria de dependências | `pip-audit` retornou 0, “No known vulnerabilities found” | Somente pacotes resolvidos no venv de inspeção e base consultada; não cobre release Windows inexistente |
| Build Orquestrador.exe | **Não executado; arquivo não gerado** | Nenhum ambiente Windows/build Windows disponível |
| Benchmark de abertura/responsividade/memória | **Não executado** | Não existe aplicação nova; nenhum número estimado |

Uma primeira execução de Ruff herdou configuração externa ao projeto e encontrou 88 apontamentos; ela foi substituída, para comparação reproduzível, por uma checagem com regras explícitas e `--isolated`. A primeira análise mypy usou o alvo Linux e reportou 29 erros; a checagem win32 acima foi feita para distinguir limitações de plataforma. Essas execuções iniciais estão identificadas nas evidências; não representam regressões introduzidas por alterações no produto.

## Matriz dos critérios de aceite

“Legado parcial” significa funcionalidade encontrada no código recebido, não implementação nova aprovada. Os números abaixo correspondem aos 23 critérios da seção 16 do pedido.

| Requisito | Implementação encontrada/realizada | Teste/evidência | Resultado | Limitação |
| --- | --- | --- | --- | --- |
| 1. Preservação, branch, backups, isolamento | Cópia original, manifesto, Git em cópia, tag e branch | CRC e hashes 18/18 | Parcial realizado | Git, estado e tarefas reais não recebidos |
| 2. Horário próprio fora do lote | Legado depende dos horários globais | Inspeção de `save_preferences` e `install_tasks.ps1` | Não atende | Nova implementação pendente |
| 3. Daily/every_run e múltiplos horários | Frequências legadas, um horário inicial | `FrequencyTests` | Legado parcial | Sem ocorrências agendadas próprias |
| 4. Semanal, reinício, recuperação e fuso | `due_reason`, estado JSON | `FrequencyTests`, `LocalOrchestrationTests` | Legado parcial | Troca de fuso/DST e recuperação nova não validadas |
| 5. Migração e interface fechada | Tarefas legadas do Windows | Inspeção somente | Não executado | Sem tarefas reais/Windows |
| 6. Dependências e ciclos | Ausente | Inspeção | Não atende | Grafo e validade pendentes |
| 7. Conectividade e inconclusivo | Legado infere VPN por sintoma | `KwmsTests` testa regra antiga | Não atende ao novo diagnóstico | Ausência de sinais independentes |
| 8. VPN KWMS, duas tentativas, 30 s, código 20 | `with_vpn_retry`, skip codes do orquestrador | `KwmsTests`, `LocalOrchestrationTests` | Legado passa em mock | Espera solicitada a mock, sem medir espera real, VPN/flash não testados |
| 9. Retry por categoria sem multiplicação | Retry geral por job e interno KWMS | Teste de ausência de retry externo no 20 | Legado parcial | Categorias e tarefas reais pendentes |
| 10. SSO/MFA | Fluxos existentes de navegador | Inspeção, sem login real | Não executado | Acesso/sessão corporativa indisponíveis |
| 11. Download interrompido, inválido, Excel | Validação e substituição preservada | `KwmsTests` com arquivos sintéticos e PermissionError | Legado parcial | Excel e interrupção real não testados |
| 12. Backup, retenção e restauração de relatórios | Catálogo e política novos ausentes | Inspeção | Não atende | Não confundir backup de app com relatório |
| 13. Eventos e publicação sem navegador | `merge_report`, `replace` | Inspeção; suíte recebida não comprova todos os casos novos | Legado parcial | Nova camada uniforme de backup/locks pendente |
| 14. Concorrência, perfil e lock órfão | Locks existentes, erros de perfil | Testes de perfil e orquestração | Legado parcial | Concorrência real GUI/CLI/tarefa não testada |
| 15. Pausa/retomada/cancelamento | Timeout e interrupção legados | Inspeção | Não atende integralmente | Sem checkpoints/GUI/controle novo |
| 16. Painel, notificações e monitor fechado | Ausente | Inspeção | Não atende | Não foi criado mockup como substituto |
| 17. OneDrive múltiplo e outro usuário | Padrões pessoais fixos | Testes verificam overrides de diretório | Não atende integralmente | Descoberta e validação novas pendentes |
| 18. ATMS e scripts extras | Descoberta e preservação no atualizador | Teste com script adicional sintético | Legado parcial | ATMS real não recebido |
| 19. Windows sem Python, sem console | Instalação legada requer Python | Inspeção de CMD/requirements | Não atende | Executável novo inexistente |
| 20. Update com falha e rollback | Backup/merge de instalação legado | Teste preserva JSON/código/script extra | Não atende rollback | Sem falha induzida/rollback novo |
| 21. Agendador real | Script PowerShell legado | Inspeção somente | Não executado | Sem Windows/sessão compatível |
| 22. Executável único com wizard completo | Ausente | Nenhum artefato gerado | Não atende | Bloqueio de entrega |
| 23. Atalho/interface e modos no mesmo EXE | Ausente | Nenhum artefato gerado | Não atende | Sem atalhos criados ou instalador alternativo |

Os requisitos de arquitetura, interface, configuração, instalação transacional, manutenção, documentação de migração e build da aplicação nova permanecem **não implementados**. A suíte do legado não pode ser usada como evidência desses requisitos.

## Comandos e arquivos

O registro `COMANDOS.md` lista os comandos executados. Foram criados somente `.gitignore` e arquivos de inspeção em `docs/`. O conteúdo operacional dos 18 arquivos originais está inalterado. Nenhuma dependência foi adicionada ao `requirements.txt` recebido e nenhuma versão do aplicativo foi incrementada.

## Condições para retomar a implementação completa

1. Disponibilizar a pasta original por conexão SharePoint com acesso confirmado ou uma cópia integral do código da instalação atual, incluindo ATMS/scripts adicionais e o repositório Git, se existir. Para a migração, também são necessários configuração, estado e inventário/exportação das tarefas a preservar; dados corporativos e perfis não devem entrar no Git.
2. Disponibilizar ambiente Windows isolado para build e testes do executável, inclusive máquina sem Python global. O ambiente atual não tem Windows, Wine, compilador Windows ou runner Windows configurado. Instalar PyInstaller em Linux não produz uma distribuição Windows validada.
3. Disponibilizar sessão corporativa autorizada nesse ambiente para o aceite real de login, VPN, Excel, downloads e Agendador. Falta de acesso externo não deve ser classificada como falha de uma atualização.

A documentação do PyInstaller informa que o pacote inclui o interpretador e que a geração é específica do sistema operacional: [What PyInstaller Does and How It Does It](https://pyinstaller.org/en/stable/operating-mode.html). Nenhum executável de outra plataforma foi renomeado para `.exe`; nenhum resultado Windows foi inferido dos testes Linux.

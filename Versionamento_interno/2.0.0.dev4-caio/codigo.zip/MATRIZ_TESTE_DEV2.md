# Matriz da edição de teste 2.0.0.dev2

| Requisito | Implementação | Teste/evidência | Resultado | Limitação |
| --- | --- | --- | --- | --- |
| Versionamento interno, sem Git | versioning.py; snapshots e manifestos SHA-256 | test_internal_versions_are_immutable_manifests; manifesto da preservação | Aprovado em código | Ativação Windows não executada |
| Preservar originais | Cópia de trabalho separada; snapshot de 84 arquivos; destinos restritos | Comparação SHA-256 dos originais; teste de recusa de pasta não vazia | Zero arquivos originais alterados | Scripts manuais autorizados não têm isolamento por sandbox do SO |
| Pasta escolhida no wizard | InstallWizard.select_location; sandbox.py | Seleção com espaços/acentos e cancelamento antes de gravar | Aprovado em Qt/Linux | Wizard completo pelo EXE Windows não executado |
| Instalação de teste isolada | Configuração, banco, relatórios, perfil e driver na pasta selecionada; atalho/tarefa de teste próprios | Testes de fuga de caminho, symlink, importação e localizador | Aprovado em código | Atalho e Agendador nativos não testados |
| GUI de Dev | dev_gui.py; seis vistas internas, processos com identidade, eventos, logs, locks e versões | Teste Qt com QThread/timer e sanitização; captura da interface | Aprovado em Linux | Processos/API Windows não homologados |
| Autoteste integrado | Botão Dev; mesma CLI interna --health-check | Qt + parsers + SQLite + integridade; controle Linux empacotado | Aprovado em Linux | Autoteste do EXE Windows não executado |
| Sem console para usuário | Bootloader Windows GUI; runtime.install_console_policy; subprocessos ocultos | PE subsystem=2; teste global de Popen e preservação das flags | Aprovado estruturalmente e em testes de código | Ausência visual de console no Windows não observada |
| Um único EXE distribuído | Orquestrador.exe com runtime privado e wizard | CArchive validado arquivo por arquivo, CPython Windows e wheels Windows | Artefato gerado | Instalação em Windows sem Python ainda pendente |
| Backup e rollback | Installer transacional, snapshots e health checks internos | Cinco falhas induzidas, interrupção e locks; adaptadores de tarefas falsos | Aprovado em integração simulada | Rollback real Windows pendente |
| Agendamento e contratos preservados | Núcleo anterior, 5 extratores, horários próprios; teste começa pausado | Suíte completa 121 testes + 7 subtestes; 40 testes legados incluídos | Aprovado em Linux/mocks | Extrações corporativas e Agendador real não executados |
| Dependências e build controlados | uv.lock; manifesto Windows com 42 entradas fixadas | Preparação limpa por hash; auditoria de 41 pacotes; arquivo de build | Aprovado | Sem assinatura digital própria |

Os resultados de mocks, Linux e inspeção estática estão identificados separadamente. A entrega é uma edição de teste técnico, não uma homologação completa da especificação Windows.

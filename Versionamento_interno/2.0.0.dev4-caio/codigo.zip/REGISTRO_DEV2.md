# Registro técnico — Orquestrador 2.0.0.dev2

Arquivo: Orquestrador.exe  
Tamanho: 90,321,899 bytes  
SHA-256: ad87a71f2dd8591810a12ab4bcfab3c20a26113a0bf27ecf32a62b505f641c4a  
Formato: PE Windows x64, subsistema GUI (2), sem assinatura digital própria.

A revisão utiliza somente versionamento interno. A versão 2.0.0.dev1 e o diretório anterior foram preservados em snapshot com manifesto e hashes. Nenhum Git foi utilizado nesta revisão. A pasta de trabalho atual é orquestrador_teste; a anterior, orquestrador, permanece intacta.

Foram adicionados o isolamento da edição de teste, o localizador separado, a política central de console oculto, o painel Dev, os registros internos de versões, testes específicos, os manifestos de entradas Windows e o build por payload explícito. Configuração, wizard, instalação, worker e entrada principal foram adaptados. Os extratores originais e o ATMS permanecem preservados.

Evidências: 121 testes e 7 subtestes aprovados; Ruff/formatação/mypy aprovados; auditoria Windows sem alertas conhecidos; 42 entradas de build verificadas; integridade dos 4.597 arquivos do pacote conferida; controle Linux empacotado e autoteste de interface aprovados.

O EXE Windows não foi executado com sucesso neste ambiente. Não foram homologados instalação Windows sem Python, login/SSO/MFA, VPN real, Excel, downloads corporativos nem tarefas reais. As tentativas Wine tiveram falha de inicialização dos handles do runtime, anterior ao aplicativo. O resultado não deve ser chamado de conversão Windows homologada.

Comandos técnicos efetivamente executados incluem: uv sync; pytest -q --junitxml; ruff check e ruff format; mypy --platform win32; pip-audit --disable-pip --no-deps -r requirements-windows-build.txt; autoteste e benchmark Qt offscreen; prepare_windows_payload.py; pack_windows_payload.py; montagem e execução de pacote de controle Linux. Os detalhes e saídas verificáveis estão em docs/evidencias. Tentativas de preparar Wine e uma VM Linux sem rede ficaram restritas ao ambiente de build, sem dados corporativos.

O usuário recebe somente Orquestrador.exe. O código, testes, documentos, manifesto e scripts de build compõem a entrega técnica interna, sem dependências de comandos manuais para o usuário.

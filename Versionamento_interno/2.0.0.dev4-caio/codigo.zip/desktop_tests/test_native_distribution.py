from __future__ import annotations

import copy
import json
import zipfile
from pathlib import Path
from typing import Any

import pytest

from orquestrador_app.config import load, save
from orquestrador_app.io import BusyError, Lock, atomic_json, digest, read_json
from orquestrador_app.native_bridge import preview
from orquestrador_app.native_install import (
    PACKAGE_OWNER,
    NativeInstaller,
    validate_health_report,
    verify_release,
)
from orquestrador_app.native_updates import check_feed, https_host, prepare_zip
from orquestrador_app.paths import Paths
from orquestrador_app.sandbox import prepare_config
from orquestrador_app.store import Store
from orquestrador_app.tasks import NS, xml


class FakeTasks:
    def __init__(self) -> None:
        self.value: str | None = None

    def export(self) -> str | None:
        return self.value

    def install(self, executable: Path, user: str) -> None:
        self.value = str(executable) + user

    def register_xml(self, value: str) -> None:
        self.value = value

    def remove(self) -> None:
        self.value = None


class FakeLinks:
    def __init__(self) -> None:
        self.value = "old links"

    def snapshot(self, folder: Path) -> None:
        (folder / "fixture-links.txt").write_text(self.value)

    def install(self) -> None:
        self.value = "new links"

    def restore(self, folder: Path) -> None:
        file = folder / "fixture-links.txt"
        self.value = file.read_text() if file.is_file() else ""


def make_payload(folder: Path, version: str = "2.0.0.dev99") -> Path:
    folder.mkdir(parents=True)
    for name in (
        "runtime/pythonw.exe",
        "src/desktop_entry.py",
        "native/wizard.ps1",
        "native/Update.ps1",
        "native/Iniciar.vbs",
        "native/Abrir.ps1",
        "assets/orquestrador.ico",
    ):
        path = folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("fixture only; not a Windows executable: " + name)
    record = {
        "owner": PACKAGE_OWNER,
        "distribution": "native-scripts",
        "version": version,
        "files": {
            p.relative_to(folder).as_posix(): digest(p) for p in folder.rglob("*") if p.is_file()
        },
    }
    atomic_json(folder / "release.json", record)
    return folder


@pytest.fixture
def native(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> tuple[Any, ...]:
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local app data"))
    payload = make_payload(tmp_path / "input/payload")
    paths = Paths.user(tmp_path / "João e Maria/teste separado")
    config = prepare_config(paths)
    tasks, links = FakeTasks(), FakeLinks()
    installer = NativeInstaller(paths, tasks=tasks, links=links, health=lambda _: None)
    return installer, paths, config, payload, tasks, links


def test_install_private_runtime_without_global_python_or_original_replacement(
    native: tuple[Any, ...], tmp_path: Path
) -> None:
    installer, paths, config, payload, _, links = native
    original = tmp_path / "produção/original.xlsx"
    original.parent.mkdir()
    original.write_bytes(b"original report")
    launcher = installer.install(payload, config)
    pointer = read_json(installer.pointer)
    assert pointer["distribution"] == "native-scripts"
    assert Path(pointer["executable"]).is_relative_to(paths.root)
    assert launcher == paths.root / "launch/Iniciar.vbs"
    assert links.value == "new links"
    assert original.read_bytes() == b"original report"
    assert load(paths).scheduling_paused
    assert [j.label for j in load(paths).routines] == [
        "Clientes",
        "Eventos",
        "Procedimentos",
        "KWMS",
        "ATMS",
    ]
    assert verify_release(Path(pointer["release"]))["version"] == "2.0.0.dev99"


@pytest.mark.parametrize("fault", ["copy", "health", "migration", "activation", "post"])
def test_update_failure_restores_runtime_configuration_state_tasks_extras_and_links(
    native: tuple[Any, ...], fault: str
) -> None:
    installer, paths, config, payload, tasks, links = native
    installer.install(payload, config)
    before = read_json(installer.pointer)
    config.email = "anterior@example.invalid"
    save(paths, config)
    extra = paths.root / "extras/adicional.py"
    extra.write_text("print('preservado')")
    with Store(paths.database).connect() as db:
        db.execute("CREATE TABLE native_test(value TEXT)")
        db.execute("INSERT INTO native_test VALUES ('estado anterior')")
    tasks.value, links.value = "tarefa anterior", "atalhos anteriores"
    candidate = copy.deepcopy(config)
    candidate.email = "novo@example.invalid"
    with pytest.raises(RuntimeError, match="induzida"):
        installer.install(payload, candidate, fault=fault)
    assert read_json(installer.pointer) == before
    assert load(paths).email == "anterior@example.invalid"
    assert tasks.value == "tarefa anterior" and links.value == "atalhos anteriores"
    assert extra.read_text() == "print('preservado')"
    with Store(paths.database).connect() as db:
        assert db.execute("SELECT value FROM native_test").fetchone()[0] == "estado anterior"
    assert read_json(installer.journal)["status"] == "rolled_back"
    verify_release(Path(before["release"]))


def test_restart_recovers_interrupted_activation(native: tuple[Any, ...]) -> None:
    installer, paths, config, payload, _, _ = native
    installer.install(payload, config)
    before = read_json(installer.pointer)
    installer.install(payload, config)
    record = read_json(installer.journal)
    record["status"] = "activating"
    atomic_json(installer.journal, record)
    assert "revertida" in installer.recover()
    assert read_json(installer.pointer) == before
    assert installer.recover() == ""


@pytest.mark.parametrize("lock_name", ["execution.lock", "interface.lock", "maintenance.lock"])
def test_active_execution_interface_or_maintenance_prevents_update(
    native: tuple[Any, ...], lock_name: str
) -> None:
    installer, paths, config, payload, _, _ = native
    installer.install(payload, config)
    previous = read_json(installer.pointer)
    with Lock(paths.root / "state" / lock_name), pytest.raises(BusyError):
        installer.install(payload, config)
    assert read_json(installer.pointer) == previous


def test_nonempty_original_folder_is_rejected_before_any_write(
    native: tuple[Any, ...], tmp_path: Path
) -> None:
    _, _, _, payload, tasks, links = native
    original = Paths.user(tmp_path / "produção")
    original.root.mkdir()
    file = original.root / "original.py"
    file.write_bytes(b"original")
    installer = NativeInstaller(original, tasks=tasks, links=links, health=lambda _: None)
    with pytest.raises(ValueError, match="arquivos existentes"):
        installer.install(payload, prepare_config(original))
    assert [p.name for p in original.root.iterdir()] == ["original.py"]
    assert file.read_bytes() == b"original"


def test_backup_failure_blocks_activation(
    native: tuple[Any, ...], monkeypatch: pytest.MonkeyPatch
) -> None:
    installer, _, config, payload, _, links = native
    installer.install(payload, config)
    before = read_json(installer.pointer)

    def fail(_: Path) -> None:
        raise OSError("backup obrigatório indisponível")

    monkeypatch.setattr(links, "snapshot", fail)
    with pytest.raises(OSError, match="obrigatório"):
        installer.install(payload, config)
    assert read_json(installer.pointer) == before


def test_fresh_package_repairs_damaged_release_with_backup_of_damaged_files(
    native: tuple[Any, ...],
) -> None:
    installer, _, config, payload, _, _ = native
    installer.install(payload, config)
    old = Path(read_json(installer.pointer)["release"])
    (old / "src/desktop_entry.py").write_text("damaged previous installation")
    installer.install(payload, config)
    current = Path(read_json(installer.pointer)["release"])
    assert current != old
    verify_release(current)
    backup = Path(read_json(installer.pointer)["backup"])
    assert (backup / "release/src/desktop_entry.py").read_text() == "damaged previous installation"
    installer.verify_snapshot(backup)


def test_cancel_at_safe_checkpoint_restores_previous(native: tuple[Any, ...]) -> None:
    installer, _, config, payload, _, _ = native
    installer.install(payload, config)
    before = read_json(installer.pointer)
    requested = False

    def progress(message: str) -> None:
        nonlocal requested
        if "Registrando atalhos" in message:
            requested = True

    with pytest.raises(RuntimeError, match="cancelada"):
        installer.install(payload, config, progress=progress, cancelled=lambda: requested)
    assert read_json(installer.pointer) == before


@pytest.mark.parametrize("change", ["tampered", "extra", "version", "path"])
def test_manifest_corruption_and_path_traversal_are_rejected(
    native: tuple[Any, ...], change: str
) -> None:
    _, _, _, payload, _, _ = native
    if change == "tampered":
        (payload / "src/desktop_entry.py").write_bytes(b"changed")
    elif change == "extra":
        (payload / "undeclared.py").write_bytes(b"extra")
    else:
        record = read_json(payload / "release.json")
        if change == "version":
            record["version"] = "../../produção"
        else:
            record["files"]["../outside"] = "0" * 64
        atomic_json(payload / "release.json", record)
    with pytest.raises((ValueError, FileNotFoundError)):
        verify_release(payload)


def test_preview_has_no_destination_side_effects_and_retains_test_configuration(
    native: tuple[Any, ...],
) -> None:
    installer, paths, config, payload, _, _ = native
    result = preview(paths.root)
    assert result["config"]["test_mode"]
    assert not paths.root.exists()
    installer.install(payload, config)
    assert preview(paths.root)["current"]["distribution"] == "native-scripts"


def package_zip(payload: Path, archive: Path) -> Path:
    with zipfile.ZipFile(archive, "w") as z:
        for path in payload.rglob("*"):
            if path.is_file():
                z.write(path, "Orquestrador/" + path.relative_to(payload.parent).as_posix())
    return archive


def test_local_zip_uses_verified_payload_without_executing_bootstrap(
    native: tuple[Any, ...], tmp_path: Path
) -> None:
    _, paths, _, payload, _, _ = native
    archive = package_zip(payload, tmp_path / "pacote.zip")
    root = prepare_zip(paths, archive, digest(archive))
    assert verify_release(root / "payload")["version"] == "2.0.0.dev99"


def test_zip_traversal_is_rejected_without_writing_outside(
    native: tuple[Any, ...], tmp_path: Path
) -> None:
    _, paths, _, _, _, _ = native
    archive = tmp_path / "ruim.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("../../outside.py", "bad")
    with pytest.raises(ValueError, match="inseguro"):
        prepare_zip(paths, archive)
    assert not (paths.root / "outside.py").exists()


@pytest.mark.parametrize(
    "url",
    [
        "http://example.invalid/feed",
        "https://user:secret@example.invalid/feed",
        "file:///config.json",
    ],
)
def test_feed_rejects_insecure_urls(url: str) -> None:
    with pytest.raises(ValueError, match="HTTPS"):
        https_host(url)


def test_feed_download_hash_version_and_local_staging(
    native: tuple[Any, ...], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _, paths, _, payload, _, _ = native
    archive = package_zip(payload, tmp_path / "pacote.zip")
    feed = {
        "owner": PACKAGE_OWNER,
        "version": "2.0.0.dev99",
        "package_url": "https://updates.example.invalid/app.zip",
        "sha256": digest(archive),
    }
    responses = [json.dumps(feed).encode(), archive.read_bytes()]
    observed = []

    class Response:
        status_code = 200

        def __enter__(self) -> Response:
            self.data = responses.pop(0)
            return self

        def __exit__(self, *_: Any) -> None:
            pass

        def raise_for_status(self) -> None:
            pass

        def iter_content(self, _: int) -> Any:
            yield self.data

    def get(url: str, **kwargs: Any) -> Response:
        observed.append((url, kwargs))
        return Response()

    monkeypatch.setattr("orquestrador_app.native_updates.requests.get", get)
    result = check_feed(paths, "https://updates.example.invalid/feed.json")
    assert result["available"] and result["version"] == "2.0.0.dev99"
    assert len(observed) == 2
    assert all(call[1]["allow_redirects"] is False for call in observed)
    responses.append(json.dumps(feed).encode())
    repeated = check_feed(paths, "https://updates.example.invalid/feed.json")
    assert repeated["package"] == result["package"]
    assert len(observed) == 3  # Only the feed is fetched again; no duplicate download/staging.


def test_native_task_uses_hidden_script_host_and_current_user(native: tuple[Any, ...]) -> None:
    import xml.etree.ElementTree as ET

    _, paths, _, _, _, _ = native
    executable = paths.root / "launch/Iniciar.vbs"
    tree = ET.fromstring(xml(executable, paths, "DOMAIN\\João"))
    command = tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Command")
    arguments = tree.findtext(f"{{{NS}}}Actions/{{{NS}}}Exec/{{{NS}}}Arguments")
    assert command and command.endswith("wscript.exe")
    assert arguments and "--agent" in arguments and "Iniciar.vbs" in arguments
    assert (
        tree.findtext(f"{{{NS}}}Principals/{{{NS}}}Principal/{{{NS}}}LogonType")
        == "InteractiveToken"
    )


@pytest.mark.parametrize(
    "report",
    [{"health": "ok", "version": "outro"}, {"health": "failed", "version": "2.0.0.dev3"}, {}],
)
def test_health_version_mismatch_prevents_activation(report: dict[str, Any]) -> None:
    with pytest.raises(RuntimeError, match="ativação recusada"):
        validate_health_report(report, "2.0.0.dev3")
    validate_health_report({"health": "ok", "version": "2.0.0.dev3"}, "2.0.0.dev3")

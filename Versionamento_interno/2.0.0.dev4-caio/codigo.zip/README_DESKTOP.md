> Revisão atual: **2.0.0.dev2, teste isolado, sem Git**. Consulte README_TESTE.md e MATRIZ_TESTE_DEV2.md. O texto abaixo registra a implementação anterior; as evidências Windows continuam pendentes.

# Orquestrador desktop — implementação técnica 2.0.0.dev1

**Situação: código implementado e verificado localmente; entrega Windows NÃO concluída. `Orquestrador.exe` NÃO foi gerado. Não é uma release aprovada para produção.**

Esta versão acrescenta aplicação PySide6, wizard integrado, núcleo compartilhado, agendamento por rotina, catálogo de relatórios e atualização com reversão. O README original é documentação preservada da v1.3.0. O documento `docs/INSPECAO_E_BLOQUEIOS.md` registra a inspeção anterior, quando a aplicação ainda não havia sido implementada. Para o estado atual, consulte este README e `docs/MATRIZ_ACEITE_DESKTOP.md`.

## Origem e preservação

- Fonte: `pipefy_orchestrator_v1.3.0.zip`, versão de arquivo 8, SHA-256 `2beb586215d3927173dd62cbf8ed4b4d57b8638cb81a2e26cd3c1213fca55049`.
- Os 18 arquivos originais permanecem byte a byte. A tag existente `v1.3.0` foi preservada, sem sobrescrita, no commit `64d36a36c9c8dec9c31ce8b23c9f1dd8a5bdcbe8`.
- A cópia de trabalho veio do histórico de inspeção, commit `6f8bf293aabdb584308133d0ff52def5327cabea`. O branch existente `feature/windows-desktop-app` foi reutilizado. Não havia alterações locais a descartar.
- Esse histórico preserva a cópia recebida; não é o histórico Git original de produção, que não estava disponível.
- ATMS foi recuperado separadamente do artefato já existente, versão de arquivo 2, e preservado sem alterações. Começa desabilitado em instalações novas e exige habilitação explícita.
- O backup prévio verificável, a cópia original e o bundle anterior foram criados fora da cópia de trabalho. A evidência permanente dos hashes está em `docs/evidencias/desktop-preservation.json`.
- Não foram recebidos estado real, inventário de tarefas, perfis, arquivos finais ou outros scripts desconhecidos da instalação de produção. Não houve extração corporativa nem alteração de tarefas reais.

## Implementação

| Local | Responsabilidade |
| --- | --- |
| `orquestrador_app/gui.py` | Painel, edição de rotinas, wizard de oito etapas, histórico, diagnóstico e manutenção |
| `config.py`, `paths.py`, `clock.py` | Configuração v2, validação, preferências portáveis, descoberta de OneDrive e fuso do sistema |
| `schedule.py` | Daily, weekly, every_run, horários próprios, recuperação agrupada e próxima execução |
| `engine.py`, `worker.py` | Grafo, fila, tentativas, execução isolada, snapshots de configuração e adaptadores dos extratores preservados |
| `io.py`, `store.py` | Locks do sistema operacional, SQLite, eventos correlacionados e diagnóstico sanitizado |
| `files.py` | Validação, publicação atômica, backup obrigatório, catálogo, retenção e restauração |
| `connectivity.py`, `driver.py` | Evidências de conectividade e reaproveitamento do diagnóstico/reparo de EdgeDriver |
| `agent.py`, `notifications.py`, `tasks.py` | Monitor independente da janela, fila de notificações e tarefa própria com sessão interativa |
| `install.py` | Cópias de versão, backup, journal, ativação, recuperação e rollback |
| `resources.py`, `processes.py` | Recursos do pacote, execução sem shell e encerramento de processos próprios |
| `desktop_entry.py`, `Orquestrador.spec`, `tools/build_windows.py` | Um único ponto de entrada e empacotamento gráfico Windows |
| `desktop_tests/` | Testes novos; `tests/` mantém a suíte original |

O código dos extratores continua separado. Os adaptadores interceptam seus pontos de publicação, mantêm os schemas confirmados e acrescentam backup/locks. URLs e seletores vêm dos arquivos existentes. Não foram criados schemas corporativos novos. Os valores pessoais legados permanecem no material preservado; a aplicação passa explicitamente e-mail, perfil, driver e destinos configurados por usuário.

O código permite cadastro de scripts adicionais por hash autorizado, argumentos e ambiente. Scripts que geram arquivo devem usar `{output_dir}` para staging e informar `staged_output` e `target`. O contrato genérico de publicação desses adicionais é XLSX não vazio; formatos adicionais exigem adaptador explícito. Código adicional autorizado não é executado dentro de uma sandbox de segurança.

## Runtime e comandos técnicos

O produto foi configurado para PyInstaller one-file, `console=False`, sem elevação, contendo Python e dependências. O mesmo executável tem modos internos `--worker`, `--agent`, `--scheduled` e `--health-check`. Não há instaladores ou executáveis por extrator. O único atalho aponta para a cópia instalada do produto. O build dessa estratégia ainda não foi executado em Windows.

Estes comandos pertencem ao desenvolvimento/CI, não são passos para o usuário final:

```bash
uv sync --frozen
uv run --frozen python -m orquestrador_app
uv run --frozen python -m orquestrador_app --data-root /caminho/isolado run --dry-run
uv run --frozen pytest --junitxml=docs/evidencias/desktop-tests.xml
uv run --frozen ruff check orquestrador_app desktop_tests tools desktop_entry.py
uv run --frozen ruff format --check orquestrador_app desktop_tests tools desktop_entry.py
uv run --frozen mypy --platform win32
uv run --frozen pip-audit --disable-pip --no-deps -r requirements-all-resolved.txt
uv run --frozen python tools/build_windows.py
```

O último comando recusa Linux e não cria um arquivo com extensão enganosa. O workflow `.github/workflows/windows-desktop.yml` foi escrito, mas não foi enviado a um repositório remoto nem executado. Seu upload de artefato final inclui somente `Orquestrador.exe`; evidências são artefatos técnicos separados.

Os comandos `run`, `login`, `list-jobs`, `doctor`, `--job`, `--force` e `--dry-run` existem no novo ponto de entrada. Os scripts/CMD originais continuam preservados e executam o legado. Eles não são instalados como interface do novo produto. A CLI nova usa `--data-root` e configuração v2; um JSON legado deve ser importado pelo wizard. `configure-schedules` abre a interface do produto. Não foi prometida compatibilidade literal com todos os argumentos do parser legado, como `--config` ou `--delay-seconds`.

## Regras operacionais

- Daily tem um sucesso por data local; weekly tem um sucesso por semana de segunda a domingo. Every_run permite sucesso em cada ocorrência própria e disparos manuais elegíveis.
- Dias padrão: segunda a sexta. Não há calendário de feriados implícito.
- Horários perdidos são agrupados na oportunidade elegível mais recente da janela configurada. O padrão é 24 horas; não há replay de todo o atraso. Uma oportunidade já tentada não é repetida a cada tick. Falha continua pendente para outro horário próprio ou dia elegível.
- Identidades de ocorrências usam data/hora de parede, evitando repetir uma hora na volta do horário de verão. Períodos concluídos também são persistidos. O fuso é relido do sistema por `tzlocal`. Mudanças reais do fuso do Windows ainda precisam ser testadas.
- `--force` não habilita uma rotina desativada. Login e publicação local não consomem frequência de extração. Restauração também não vira novo sucesso de extração.
- `same_chain` exige sucesso no próprio lote. `fresh_success` exige janela explícita. Origens desabilitadas bloqueiam dependentes; ciclos são rejeitados. Falha própria e bloqueio têm estados diferentes.
- Retries são contados por categoria incluindo a primeira tentativa, com backoff, orçamento da categoria e limite total da rotina. Uma falha de arquivo bloqueado repete a publicação do staging, sem baixar novamente. VPN e autenticação não recebem retries externos configuráveis.
- O fluxo compatível de resposta vazia KWMS tem duas tentativas internas, espera solicitada de 30 segundos e código 20/`skipped`, sem retry externo e com continuidade mesmo em fail-fast. Uma resposta vazia isolada é inconclusiva. Evidência HTTP de servidor ou falha de conectividade comprovada segue a categoria própria.
- Headless controla o navegador. Console oculto controla subprocessos. Minimizar mantém a aplicação. SSO/MFA continua na sessão interativa. O agendamento não é um serviço Windows.
- A pausa ocorre em checkpoints, sem suspender uma publicação em andamento. A retomada verifica o hash e a sessão observável. O timeout total inclui o tempo em pausa. Cancelamento tem oito segundos de cooperação antes do encerramento dos subprocessos próprios.
- Em Windows, há código para Job Object com kill-on-close; em POSIX, grupo privado e controle de PIDs. O teste real local verificou encerramento de processo próprio e preservação de processo alheio. A API Windows não foi exercitada.

## Verificações realizadas

Ambiente: Linux x86_64, CPython 3.12.14, venv isolado; lock universal `uv.lock`. `requirements-resolved.txt` é a exportação das dependências de runtime, com markers de plataforma. Não depende do Python global na estratégia de pacote; isso ainda não foi demonstrado por um executável em Windows limpo.

- **104 testes e 7 subtestes aprovados**: 40 testes legados e 64 novos. Os testes novos incluem subprocessos reais locais para publicação, merge, script adicional, lock e agente com janela principal fechada. Downloads, SSO, VPN, Excel e Agendador reais não foram exercitados.
- Lint e formatação da camada nova: aprovados. Tipos da camada nova: 21 arquivos aprovados com alvo estático win32, incluindo o comando usado no CI, sem `--follow-imports skip`. Imports usam a configuração `silent`; não é validação publicada de todos os apontamentos do legado, que permanece preservado.
- Auditoria: zero alertas na consulta final, tanto para as 31 dependências de runtime consideradas quanto para 64 dependências incluindo desenvolvimento/build/teste. Foram corrigidos os alertas encontrados em `requests 2.32.5` (atualizado para `2.33.0`) e `pytest 8.4.2` (atualizado para `9.0.3`). O lock contém também dependências Windows que não foram instaladas/auditadas como presentes neste host Linux.
- Health check em código-fonte: cria configuração e SQLite temporários, importa bibliotecas, carrega os cinco parsers e constrói cinco abas e oito páginas do wizard, sem rede/extrair dados.
- Benchmark real de uma amostra, em código-fonte Linux/offscreen: abertura 0,193 s; RSS 74.108.928 bytes; 198 amostras de timer, mediana 9,845 ms, máximo 21,304 ms. Medição atual de RSS por `/proc/self/status`, necessária devido ao namespace de PID do executor. Cache do sistema não foi limpo. Não estima desempenho do EXE/Windows e não mede extração corporativa.

Evidências: XML do pytest, auditoria JSON, manifesto de preservação, benchmark JSON e resumo dos comandos em `docs/evidencias/desktop-*`.

## Limites e gates de entrega

O aceite do usuário exige o executável gerado e o fluxo completo em Windows sem Python. Esse gate **não foi atendido**. Não há Windows, Wine ou runner Windows configurado nesta sessão. Não foi feito upload/publicação de release, assinatura de código nem demonstração do único atalho real.

Também permanecem pendentes a migração das tarefas reais, sessão corporativa, VPN, SSO/MFA, download interrompido de verdade, Excel bloqueando o destino, notificações nativas, instalação/reparo/atualização e rollback do EXE, testes de corrida entre interfaces/monitor e manutenção no Windows. Os testes do instalador usam backend de tarefas/atalhos e arquivo de executável sintéticos, explicitamente identificados no código. Não são evidência de instalação Windows.

A migração automática de tarefas identifica o prefixo confirmado do instalador v1.3.0 e verifica seus argumentos. Tarefas independentes de versões antigas de cada extrator ou nomes desconhecidos precisam de inventário/revisão antes da migração real; não são apagadas por aproximação. A desinstalação remove tarefa/atalho próprios e preserva dados, mas atualmente marca a cópia executável em uso para remoção posterior; a remoção física completa ainda não foi concluída. Notificações usam QSystemTrayIcon; envio para a fila/Qt não comprova exibição pelo Windows.

Algumas configurações avançadas continuam em editor JSON validado dentro da interface. Os logs dos extratores e o consolidado têm rotação, mas o arquivo de captura stdout por execução ainda não tem limite próprio de tamanho. Temporários são preservados para diagnóstico; `cleanup_partials` existe, mas não tem ação própria na interface nesta revisão.

O repositório técnico permite revisão e continuidade. Ele não substitui `Orquestrador.exe` e não deve ser distribuído ao usuário final como se fosse a aplicação pronta.

Referências primárias: [PyInstaller](https://pyinstaller.org/en/stable/operating-mode.html), [QWizard](https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QWizard.html), [notificações Qt](https://doc.qt.io/qtforpython-6/PySide6/QtWidgets/QSystemTrayIcon.html), [StartWhenAvailable](https://learn.microsoft.com/en-us/windows/win32/taskschd/tasksettings-startwhenavailable).

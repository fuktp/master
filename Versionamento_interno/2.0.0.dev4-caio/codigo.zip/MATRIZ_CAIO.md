# Matriz de alterações CAIO — 2.0.0.dev4

Legenda: “passou” refere-se aos testes locais executados (Python/Qt Linux ou PowerShell 7 Linux). Não implica homologação do Windows. A matriz original completa da dev3 continua em MATRIZ_SCRIPTS.md; esta matriz registra os novos requisitos e as mudanças de precedência.

| Requisito | Implementação | Teste/evidência | Resultado e limite |
|---|---|---|---|
| Preservar originais, sem Git | Cópia da dev3, snapshots e hashes internos | dev4-preservation.json | Fontes recebidos preservados; nenhum comando Git |
| ZIP com sequência clara | 00 Read Me, 01 Instalar.vbs, 01 Instalar(alt).bat; detalhes em payload | verify_native_artifact.py verifica nomes e referências | ZIP gerado; duplo clique Windows não executado |
| App leve, sem novo framework | Qt/WinForms existentes; remover ReadTask duplicado; reutilizar Engine; atualizar só abas visíveis; itens estáveis | benchmark_revision.py, dev4-benchmark-comparison.json | Tamanho ZIP reduzido; timer regular. RAM local aumentou; dados completos registrados |
| Fácil cadastro e troca de scripts | Seletor .py, subcomando, navegador, versão; argumentos/ambiente existentes | test_translated_visible_controls_selection_and_new_script_path | Passou; bibliotecas adicionais não são instaladas automaticamente |
| Versionamento dos scripts | Snapshots por conteúdo; lista e restauração; identidade SHA sem autorização repetida | test_script_versions_no_reauthorization_restore_and_remove | Passou; snapshot de arquivo único, não de dependências auxiliares |
| Eliminar autorização repetida por hash | Cadastro/habilitação explícita + integridade de snapshots | Worker real executa script alterado e registra falha real dele | Passou; pacote/backup continuam verificando integridade |
| Logo CAIO e ICO | SVG/PNG, ICO 16–256px; janela, painel, wizard, atalhos | create_caio_logo.py; inspeção visual Qt; verificador do pacote | Criada; aparência do atalho Windows não executada |
| Português, inglês e espanhol | Catálogo local compartilhado, seleção no wizard/configuração | Testes parametrizados das três línguas e capturas Qt | Controles e guias traduzidos; scripts, chaves JSON e logs externos permanecem originais |
| Tema e contraste global | QPalette explícita + stylesheet; cabeçalhos azuis/letras brancas, células escuras | Palette assert + inspeção de tabelas, campos e caixas | Passou Qt offscreen; WinForms somente inspeção de código/sintaxe |
| Driver fora da pasta, reparação automática | Descoberta limitada em PATH/cache/pastas do usuário/raízes configuráveis; validação e resolução oficial existentes | test_driver_search…, test_driver_auto_repair…; regressão legado | Passou com doubles; Edge/Authenticode/download real Windows não executados |
| Wizard opções explicadas e políticas organizadas | Descrição por ação; tabela Scope/ExecutionPolicy/significado | Parser PowerShell + revisão de UI | Sintaxe passou; execução WinForms não homologada |
| Botão Escolher com largura do campo | Qt stretch igual; WinForms mesma largura e segunda linha | Inspeção visual Qt, geometria no código | Qt inspecionado; DPI Windows não medido |
| Etapa anterior concluída | Texto substituído nas operações/wizard | Catálogos e fluxo de conclusão | Implementado; erros mantêm mensagem de falha |
| Adicionar/retirar rotinas no wizard | Controles nos destinos/rotinas, ponte add_script com validação | Bridge usa modelo Config compartilhado; parser PS | Implementado; fluxo WinForms não executado |
| Dias em botões, tooltip e horários múltiplos | DaysPicker/TimesPicker Qt; editor WinForms nativo | Testes Qt reais dos dias/seletores e validação de horários | Passou Qt; WinForms não executado |
| Ordem sem repetição | Dropdown com reposicionamento dos demais itens | Teste de edição verifica ordens 0…N−1 | Passou; JSON legado com empates conserva desempate determinístico |
| Frequência preenche dias; weekdays only | Frequências daily/weekly/every_run/weekdays; seleções guiadas | test_weekdays_daily_success_and_weekend + regressão de frequência | Passou |
| Explicar monitor e seleção opcional | Explicações por etapa, pausa explícita, revisão obrigatória | README e texto do wizard | Implementado; tarefa por sessão interativa, não serviço |
| Verificação automática, log e barra | Auto health ao entrar; QThread/processo separado; status real | Regressão health, timer Qt e parser PS | Passou local; instalação Windows não executada |
| Próxima execução após instalar | Native preview novo começa ativo; preserva pausa anterior | test_native_preview_schedules_start_active_but_preserves_pause | Passou; execução automática requer selecionar/instalar monitor |
| Seleção controla botões | Sem seleção: todas + individuais; uma: rotina; várias: lote selecionado | Teste Qt seleciona linhas e verifica ações/legendas | Passou |
| Logs centrais, falhas e barra sob demanda | Logs por alteração, etapa, handlers QThread, alertas/status | Qt visibilidade de barra; regressão real de worker | Passou local; notificações Windows não homologadas |
| Intervalo entre rotinas simultâneas | Config queue_delay_seconds, padrão30, cooperativo após término anterior | test_queue_delay_is_after_previous_finish_and_cancellable | Ordem/30s testados com relógio controlado; regressão de cancelamento mantida |
| Exclusão com confirmação e preservação opcional | Remover cadastro; opção apagar apenas cópias gerenciadas | Teste versões/remoção/reinclusão | Passou; relatórios, original e histórico não apagados |
| Explicar Publicar local | Descrição junto ao botão; rotina selecionada na própria tabela | Workers reais de Clientes/Eventos/Procedimentos/ATMS, sem rede | Passou |
| Opções rotinas explicadas e limitadas | Tooltip, textos, habilitação de navegador/URL; nome final adicional | Testes Qt e captura do editor | Passou; dependências/argumentos avançados permanecem JSON explicado |
| Salvar caminho não quebra execução | Retirar hash antigo como bloqueio; snapshot e caminho validado | Testes de troca de caminho + worker adicional real | Passou; extrator conhecido precisa manter contrato de adaptação |
| Preferências exportar/importar | Whitelist portátil corrigida para idioma/intervalo, sem script_version local | test_portable_round_trip… | Passou, preserva parâmetros de máquina |
| Atualização sem HTTPS | Botão renomeado; feed inativo/explicado; sem Verificar feed agora; ZIP local | native_gui.py; regressão prepare_zip e rollback | Implementado; alimentação HTTPS retirada do fluxo desta edição |
| Escolher onde salvar preferências de atualização | Save dialog; exportação JSON e persistência interna | Caminho de escrita existente e inspeção do callback | Implementado; diálogo Windows não executado |
| Exportação Histórico/Dev XLSX e JSON | exporting.py, sanitização compartilhada e neutralização de fórmulas | test_json_xlsx_sanitization_and_formula_cells | Passou com leitura real do XLSX |
| Conectividade como KWMS | Mesma sonda e is_empty_response; sessão temporária de navegador somente leitura quando necessário | test_kwms_diagnostic… simula browser; classificação de rede regressiva | Passou mock; VPN/SSO corporativos não executados |
| Tarefas organizadas e sem null | Relatório legível, resultados install/remove, drift de triggers/sessão | test_task_install_remove…, test_task_drift… | Passou com tarefa fake; schtasks Windows não executado |
| Tabela de manutenção vazia | Explicação: backups só existem após substituir relatório válido | Regressão Publisher; carregamento na aba visível | Não fabrica registros de backup |
| Dev leitura em segundos e caixa com label | ISO seconds, textos de legenda, paleta clara; Task reaproveitada | Capturas Qt e coleta de estado | Passou local |
| Sem console persistente | VBS, pythonw, CREATE_NO_WINDOW existentes mantidos | PE GUI e políticas de processo; parser/inspeção dos wrappers | Não medido visualmente no Windows; BAT pode piscar CMD |
| Atualização/rollback e dados preservados | Transação original mantida, scripts novos inclusos no backup | Suíte falhas induzidas e verificação real ZIP | Passou com OS fake; ciclo real Windows não executado |

"""Shared native controls and explicit light palette; no extra UI framework."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTime
from PySide6.QtGui import QColor, QIcon, QPalette
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
    QTimeEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .i18n import tr

DAYS = (
    "Segunda-feira",
    "Terça-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "Sábado",
    "Domingo",
)


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    palette = QPalette()
    for role, color in {
        QPalette.ColorRole.Window: "#F3F6FA",
        QPalette.ColorRole.WindowText: "#333333",
        QPalette.ColorRole.Base: "#FFFFFF",
        QPalette.ColorRole.AlternateBase: "#F7F9FC",
        QPalette.ColorRole.Text: "#333333",
        QPalette.ColorRole.Button: "#E6EDF5",
        QPalette.ColorRole.ButtonText: "#00338D",
        QPalette.ColorRole.Highlight: "#005EB8",
        QPalette.ColorRole.HighlightedText: "#FFFFFF",
        QPalette.ColorRole.ToolTipBase: "#FFFFFF",
        QPalette.ColorRole.ToolTipText: "#1F2937",
        QPalette.ColorRole.PlaceholderText: "#5B6770",
    }.items():
        palette.setColor(role, QColor(color))
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor("#6B7280"))
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor("#6B7280"))
    app.setPalette(palette)
    app.setStyleSheet("""
        QWidget { font-family: "Segoe UI"; font-size: 10pt; color: #333333; }
        QMainWindow, QDialog, QWizard { background: #F3F6FA; }
        QLabel { background: transparent; color: #333333; }
        QTabWidget::pane { border: 1px solid #D7E0EA; background: #FFFFFF; }
        QTabBar::tab { padding: 10px 12px; background: #E6EDF5; color: #00338D; }
        QTabBar::tab:selected { background: #FFFFFF; border-top: 3px solid #00A3E0; }
        QPushButton { padding: 7px 12px; min-height: 20px; background: #005EB8; color: #FFFFFF; border: 1px solid #005EB8; border-radius: 5px; }
        QPushButton:hover { background: #00338D; }
        QPushButton:disabled { background: #E6EDF5; color: #5B6770; border-color: #D7E0EA; }
        QToolButton { padding: 7px; background: #FFFFFF; color: #00338D; border: 1px solid #D7E0EA; border-radius: 5px; }
        QToolButton:checked { background: #005EB8; color: #FFFFFF; }
        QCheckBox, QRadioButton { color: #333333; spacing: 8px; }
        QCheckBox::indicator { width: 18px; height: 18px; }
        QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QAbstractSpinBox, QListWidget { background: #FFFFFF; color: #333333; padding: 5px; border: 1px solid #D7E0EA; selection-background-color: #005EB8; selection-color: #FFFFFF; }
        QComboBox QAbstractItemView { background: #FFFFFF; color: #333333; selection-background-color: #005EB8; selection-color: #FFFFFF; }
        QTableWidget { background: #FFFFFF; color: #333333; alternate-background-color: #F7F9FC; gridline-color: #E4EAF1; selection-background-color: #005EB8; selection-color: #FFFFFF; }
        QTableWidget::item { padding: 5px; color: #333333; }
        QTableWidget::item:selected { background: #005EB8; color: #FFFFFF; }
        QHeaderView::section { background: #00338D; color: #FFFFFF; padding: 9px; border: 1px solid #005EB8; font-weight: 600; }
        QProgressBar { color: #00338D; border: 1px solid #D7E0EA; min-height: 8px; }
        QProgressBar::chunk { background: #00A3E0; }
        QToolTip { background: #FFFFFF; color: #1F2937; border: 1px solid #D7E0EA; }
    """)
    app.setApplicationName("CAIO")
    app.setWindowIcon(icon())


def icon() -> QIcon:
    root = Path(__file__).resolve().parents[1]
    for path in (root / "assets/caio.ico", root.parent / "assets/orquestrador.ico"):
        if path.is_file():
            return QIcon(str(path))
    return QIcon()


class DaysPicker(QWidget):
    def __init__(self, days: list[int], parent: QWidget | None = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.buttons = []
        for index, name in enumerate(DAYS):
            button = QToolButton()
            button.setText(tr(name)[:1])
            button.setToolTip(tr(name))
            button.setAccessibleName(tr(name))
            button.setCheckable(True)
            button.setChecked(index in days)
            button.setMinimumSize(38, 36)
            self.buttons.append(button)
            layout.addWidget(button)
        layout.addStretch()

    def values(self) -> list[int]:
        return [i for i, button in enumerate(self.buttons) if button.isChecked()]

    def set_days(self, days: list[int]) -> None:
        for i, button in enumerate(self.buttons):
            button.setChecked(i in days)


class TimesPicker(QWidget):
    def __init__(self, times: list[str], parent: QWidget | None = None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.list = QListWidget()
        self.list.addItems(sorted(times))
        self.list.setMaximumHeight(90)
        layout.addWidget(self.list)
        tools = QVBoxLayout()
        self.clock = QTimeEdit(QTime(8, 30))
        self.clock.setDisplayFormat("HH:mm")
        self.clock.setToolTip(
            tr("Escolha a hora e os minutos; depois clique em Adicionar horário.")
        )
        tools.addWidget(self.clock)
        add = QPushButton(tr("Adicionar horário"))
        add.clicked.connect(self.add)
        tools.addWidget(add)
        remove = QPushButton(tr("Retirar horário"))
        remove.clicked.connect(lambda: self.list.takeItem(self.list.currentRow()))
        tools.addWidget(remove)
        layout.addLayout(tools)

    def add(self) -> None:
        value = self.clock.time().toString("HH:mm")
        if value not in self.values():
            self.list.addItem(value)
            self.list.sortItems()

    def values(self) -> list[str]:
        return [self.list.item(i).text() for i in range(self.list.count())]


def explain(text: str) -> QLabel:
    label = QLabel(tr(text))
    label.setWordWrap(True)
    label.setStyleSheet("color: #5B6770; padding: 3px 0;")
    return label


def set_cell(table: Any, row: int, column: int, value: Any, role: Any = None) -> None:
    from PySide6.QtWidgets import QTableWidgetItem

    text = str(value if value is not None else "")
    if len(text) > 19 and text[4:5] == "-" and text[10:11] == "T":
        import datetime as dt

        try:
            text = dt.datetime.fromisoformat(text).astimezone().strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    text = tr(text)
    item = table.item(row, column)
    if item is None:
        item = QTableWidgetItem(text)
        table.setItem(row, column, item)
    elif item.text() != text:
        item.setText(text)
    if role is not None:
        item.setData(Qt.ItemDataRole.UserRole, role)

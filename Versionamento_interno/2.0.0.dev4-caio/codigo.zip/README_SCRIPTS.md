# CAIO — edição de teste 2.0.0.dev4

## Caminho de uso

1. Extraia **todo** o ZIP em uma pasta local.
2. Leia **00 - Read Me.md** (este arquivo).
3. Abra **01 - Instalar.vbs**. **01 - Instalar(alt).bat** é a alternativa; o BAT pode exibir brevemente o CMD.
4. Escolha Português (Brasil), English ou Español e uma pasta de teste vazia. Uma instalação de teste reconhecida também permite atualização ou reparo. Não escolha a pasta de produção.
5. Revise destinos e rotinas. Use **Editar rotina** para frequência, dias, horários, script e ordem. O monitor opcional executa os horários com a interface fechada enquanto o usuário estiver conectado ao Windows.
6. A validação inicia automaticamente. A janela central mostra as etapas reais. Revise, confirme e instale. Use os atalhos criados na Área de Trabalho ou no Menu Iniciar para abrir o aplicativo.

O ZIP contém somente três entradas de orientação no primeiro nível e a pasta interna `payload`. Não execute os scripts dentro de `payload` manualmente. Python 3.13.16 e bibliotecas estão incluídos; não há instalação manual de Python ou pip. O aplicativo continua sendo Windows, sem um `CAIO.exe` ou `Orquestrador.exe` próprio. Os executáveis internos do runtime e do navegador continuam necessários. Scripts não têm certificado; as políticas da organização continuam aplicáveis. O parâmetro Bypass afeta apenas o processo do instalador e não supera políticas corporativas.

## Instalação, atualização e reversão

- A pasta escolhida guarda aplicativo, configuração, perfil Edge, downloads, relatórios, logs, histórico e backups. Os originais de produção não são substituídos.
- Uma instalação nova exibe as próximas execuções e começa com o agendamento ativo. O monitor **não é instalado sem seleção explícita**. A opção “Pausar agendamentos após instalar” permite adiar as execuções.
- Uma atualização preserva a pausa existente: use “Pausar/retomar agendamento” no painel quando quiser retomar. A versão dev3 começava pausada; atualizar não autoriza silenciosamente os disparos.
- **Configurações > Atualização… > Atualizar por ZIP local…** aceita o novo pacote completo. O aplicativo fecha após confirmação, um processo separado espera seu encerramento e prepara a nova versão em outra pasta.
- Não há verificação HTTPS nesta edição. O campo Feed fica indisponível com explicação; nenhum servidor foi inventado. Salvar preferências de atualização permite escolher o arquivo JSON de exportação e também salva as preferências internas.
- O instalador verifica hashes, cria backup de versão, configuração, SQLite, scripts adicionais, atalhos e tarefa e faz health checks locais antes/depois da ativação. Falhas internas induzem rollback. VPN/login/servidor não são health checks de atualização.
- Cancelar antes da instalação não altera o destino. Durante cópia, o cancelamento é cooperativo e reverte a transação. Após interrupção abrupta, a próxima abertura recupera o journal.
- Em manutenção, “Reverter atualização” restaura um backup gerenciado, guardando antes a versão atual. A desinstalação remove somente ativação, tarefa e atalhos próprios; dados ficam preservados.

## Rotinas e versões de scripts

**Cadastrar script** abre um `.py`, inicialmente desabilitado. Informe um nome de versão opcional e revise as opções. Scripts comuns sem CLI usam subcomando vazio; marque “Este script utiliza o navegador Edge” somente quando aplicável. Em opções avançadas, `arguments` e `options` são listas JSON, sem shell, e `environment` não aceita segredos. Exemplos de substituições: `{output_dir}`, `{log_file}`, `{driver_path}`. Dependências Python devem estar no runtime; instalar bibliotecas arbitrárias não faz parte deste fluxo.

Uma alteração ou troca do arquivo **não pede autorização por hash**. Habilitar/cadastrar é a decisão explícita de executar código local confiável. O hash permanece como identidade de versão e integridade de backup. Snapshots são feitos ao salvar e executar, em `extras/versions/<id>/<sha256>`. **Versões do script** lista, identifica e restaura as cópias. Não utiliza Git. Restaurar cria uma cópia em `extras/active`, sem sobrescrever o arquivo externo original. Arquivos auxiliares e dependências não são embutidos automaticamente no snapshot de um único script.

**Excluir rotina** pede confirmação. Por padrão remove só o cadastro, guardando histórico e versões. A opção adicional apaga as cópias/versões gerenciadas, sem apagar o script original nem relatórios. Remova antes dependências que apontem para a rotina excluída.

Os cinco extratores existentes (Clientes, Eventos, Procedimentos, KWMS e ATMS) permanecem byte a byte iguais à dev3. Novos códigos podem usar argumentos próprios; substituir um extrator conhecido requer manter seu contrato ou cadastrá-lo como rotina adicional. Não se inferem seletores, schemas ou URLs de scripts futuros.

## Frequência e fila

- **Diária**: um sucesso por data; outros horários recuperam pendências.
- **Somente dias úteis / weekdays only**: diária de segunda a sexta. Feriados não são excluídos.
- **Semanal**: um sucesso por semana; o primeiro dia selecionado é o início; os demais dias permitem recuperação.
- **Todos os horários**: um sucesso por ocorrência própria, inclusive após sucesso no mesmo dia.
- Os botões dos dias têm nomes completos no tooltip. O seletor de hora permite adicionar vários horários. Horários repetidos e dias vazios são recusados.
- Escolher uma nova ordem reposiciona as demais rotinas, evitando duplicações no editor. Dependências continuam prevalecendo sobre a prioridade visual.
- O intervalo configurável entre rotinas agendadas começa **após o término da anterior**: padrão 30 s. A fila usa o mesmo lock de execução e nunca concorre no perfil compartilhado. Execução manual não inclui essa espera extra.
- O fuso vem do Windows. Pausa, frequência e sucesso são preservados. Nenhum sucesso é registrado por login, restauração ou diagnóstico.

## Painel e manutenção

Selecione uma rotina para os botões individuais; selecione duas ou mais para executar/forçar o lote selecionado. Sem seleção, “Executar todas” fica separado das ações individuais. O log central mostra subprocessos e operações; a barra aparece apenas enquanto há trabalho. Pendências/falhas aparecem no estado e no log.

O tema claro usa a paleta fornecida: azul #00338D, ação #005EB8, destaque #00A3E0, fundos #FFFFFF/#F3F6FA, texto #333333. Uma paleta explícita evita branco sobre branco quando o Windows usa tema escuro. A marca CAIO tem fonte vetorial SVG, PNG e ICO de 16 a 256 px. Não adicionamos um framework visual novo.

**EdgeDriver:** antes de extrações, verifica compatibilidade; ao reparar procura primeiro o caminho gerenciado, variáveis de ambiente, PATH, caches Selenium e pastas comuns do usuário. `driver_options.search_paths` aceita locais adicionais. A busca é limitada a 3.000 diretórios e quatro níveis por raiz; não varre discos de rede nem todo o computador. Se não achar driver compatível, reutiliza Selenium Manager e o download oficial existentes. Valida assinatura e versão; só substitui a cópia gerenciada, com backup. Reparação pela tela usa o lock de execução. Não é necessário copiar manualmente o driver para a pasta do aplicativo.

**Conectividade KWMS:** usa a mesma sonda de destino/internet/interfaces VPN e, quando necessário, a mesma identificação de resposta vazia do extrator em uma sessão temporária de Edge. Não envia formulários, não consome frequência e fecha somente seu próprio navegador. Resposta vazia sem evidência suficiente permanece “inconclusiva”; servidor indisponível não é rotulado VPN.

**Tarefas:** os resultados mostram ação, instalação e correspondência verificada; não retornam `null`. Conferir tarefas organiza executável, argumentos, sessão, usuário e intervalo. Monitor por sessão interativa, sem elevar privilégios.

**Publicar arquivo local:** para os contratos conhecidos, valida um Excel já baixado e publica com backups; Eventos mescla o histórico de forma idempotente. Não abre navegador e não marca uma extração nova. Restauração de relatórios também não consome frequência. A lista de backups fica vazia antes da primeira substituição de um arquivo válido e agora explica esse estado.

**Exportações:** Histórico e Dev aceitam JSON e XLSX sanitizados. O XLSX neutraliza fórmulas em textos exportados. Preferências JSON exportadas podem ser reimportadas com prévia, preservando caminhos e parâmetros de máquina. Idioma e intervalo da fila são portáveis. Conteúdo de scripts, chaves JSON, logs externos e evidências técnicas ficam no idioma original; os controles/guias da interface têm os três idiomas.

## Validação desta entrega

Consulte `MATRIZ_CAIO.md`, `REGISTRO_CAIO.md` e `docs/evidencias/dev4-*` no pacote técnico. Os testes padrão usam arquivos sintéticos e bloqueiam rede corporativa. **Não houve execução real em Windows** neste ambiente: WinForms, WSH, Agendador, Edge/assinatura, SSO/MFA, VPN e bloqueio pelo Excel ainda exigem homologação autorizada. Capturas e benchmarks disponíveis são do código Qt em Linux/offscreen, não de Windows. Não há garantia de liberação por SmartScreen, Defender ou política corporativa.

# Orquestrador 2.0.0.dev2 — edição de teste

O arquivo entregue ao usuário é **Orquestrador.exe**. Ele contém o runtime Windows privado, a aplicação PySide6, o wizard e os cinco extratores preservados. Esta revisão utiliza versionamento interno por snapshots e SHA-256. Nenhum comando Git foi executado nesta revisão.

**Situação de validação:** PE Windows x64 gráfico gerado e conteúdo verificado. Os testes de código e um pacote de controle Linux passaram. A instalação e a operação do EXE em Windows real ainda não foram executadas neste ambiente. A edição deve ser tratada como teste técnico, sem homologação de produção.

## Uso pelo usuário

1. Abra Orquestrador.exe e avance no wizard.
2. Escolha uma pasta vazia exclusiva do teste, ou uma instalação de teste já reconhecida. É possível criar uma subpasta pelo seletor. Pastas com arquivos de outra instalação são recusadas.
3. Revise identificação, caminhos e rotinas. O e-mail pode ficar vazio para simulação ou publicação local; o login precisa do e-mail correto. Perfil e relatórios do teste ficam dentro da pasta escolhida.
4. Revise as alterações e marque a aplicação. O wizard copia o executável para uma versão interna separada, verifica o pacote e cria um único atalho **Orquestrador - Teste**.
5. Ao abrir o aplicativo, use **Dev • Internos** para acompanhar runtime, locks, processos de execução, eventos correlacionados, logs e manifestos de versões. O botão de autoteste abre um subprocesso interno oculto e realiza verificações sem extração nem rede.

O agendamento começa pausado. A instalação do monitor de teste no Agendador é opcional no wizard. O aplicativo também permite gerenciá-lo em Diagnóstico e manutenção. O monitor usa o mesmo executável e uma tarefa com nome próprio desta instalação. As tarefas legadas de produção não são migradas ou desabilitadas nesta edição.

Não é necessário executar Python, pip, CMD ou PowerShell. O executável usa o subsistema gráfico do Windows. O núcleo aplica CREATE_NO_WINDOW aos subprocessos, inclusive os invocados pelos extratores preservados. Essa política não altera a escolha de navegador visível/headless para SSO/MFA.

## Isolamento

| Local na pasta escolhida | Conteúdo |
| --- | --- |
| instalacao-teste.json | Identificação da instalação de teste |
| app/versions | Executáveis de cada instalação/reparo, em pastas distintas |
| config.json e state | Configuração, histórico SQLite e locks exclusivos |
| relatorios | Destinos de Clientes, Eventos, Procedimentos, KWMS e ATMS |
| downloads e cache | Arquivos temporários gerenciados e driver privado |
| profiles/Edge-Teste | Perfil do navegador exclusivo do teste |
| logs | Logs do aplicativo, runtime e execuções |
| backups/app | Snapshots verificáveis do aplicativo, configuração, estado e tarefa própria |
| backups | Backups de relatórios publicados |
| versionamento | Manifestos internos de versões, datas, tamanhos e hashes |

O lançador mantém apenas a referência à instalação de teste em LOCALAPPDATA/Orquestrador-Teste. O runtime de um executável de arquivo único usa também temporários gerenciados do sistema.

Os destinos gerenciados, o perfil, os logs e o driver não podem escapar da pasta de teste, inclusive por links de diretório. Argumentos que substituam os caminhos gerenciados dos extratores conhecidos são recusados. As contas OneDrive aparecem para identificação; esta edição não redireciona relatórios para produção. A importação da v1.3.0 copia preferências compatíveis e redireciona caminhos; não transfere o estado de sucesso nem as tarefas originais para o ambiente de teste. Scripts adicionais importados ficam desabilitados para revisão. Scripts manuais continuam exigindo autorização explícita do seu hash; o aplicativo não é um sandbox do sistema operacional para código arbitrário.

Fechar a janela minimiza a interface. Use Sair da interface para encerrar. Uma execução ativa deve ser cancelada cooperativamente ou mantida em segundo plano. A restauração de relatórios preserva a versão atual e não conta como nova extração.

## Versões, reparo e reversão

Configurações > Instalação e atualização reabre o wizard. O EXE recebido de uma versão posterior detecta a instalação de teste pelo identificador próprio. A instalação faz snapshot e prepara outra pasta antes de ativar a nova versão. Falhas internas acionam a restauração do snapshot. Os testes induziram falhas nas etapas de cópia, health check, migração, ativação e verificação final; os testes de tarefa e atalho usam adaptadores falsos, sem alterar o Windows.

A instalação original, seus arquivos e o diretório de código anterior foram preservados. O snapshot anterior contém 84 arquivos com hashes conferidos, sem alterações. Os registros desta revisão estão em docs/evidencias/test-edition-* e no manifesto interno da entrega técnica.

## Build técnico reproduzível

Esta seção destina-se ao desenvolvimento. O usuário final recebe somente Orquestrador.exe.

As dependências estão em pyproject.toml e uv.lock. build_inputs/windows-x64.json fixa 42 entradas por URL e SHA-256: CPython Windows 3.13.16 e 41 wheels. O caminho alternativo efetivamente usado nesta entrega monta o bootloader Windows oficial do PyInstaller 6.16.0 com runtime e bibliotecas Windows explícitos. Ele não realiza Analysis de Windows em Linux. A montagem verifica cada entrada do CArchive. Um pacote Linux independente exercitou o mesmo bootstrap e construiu a interface e o wizard; isso não substitui testes Windows.

```text
uv sync --frozen --python 3.13.16
uv run python tools/prepare_windows_payload.py --output build/runtime-windows --cache build/downloads
uv run python tools/pack_windows_payload.py --runtime build/runtime-windows --wheels build/downloads --input-manifest build/runtime-windows/wheels-sha256.json --output dist/Orquestrador.exe
```

Em um ambiente de desenvolvimento Windows, tools/build_windows.py e Orquestrador.spec oferecem também o build convencional PyInstaller, com smoke test do EXE. Esse caminho convencional não foi executado com sucesso nesta sessão. A aplicação distribuída não tem assinatura digital própria; não foi fornecido certificado.

## Evidências e pendências

- 121 testes passaram, mais 7 subtestes, com rede bloqueada na suíte padrão.
- Ruff, formatação e mypy no alvo win32: aprovados.
- Auditoria dos pacotes Windows fixados: nenhuma vulnerabilidade conhecida encontrada.
- Preparação limpa: 42 entradas verificadas por hash.
- Pacote Windows: PE x64, subsistema gráfico, 4.597 arquivos verificados.
- Controle empacotado Linux: autoteste aprovado, cinco extratores, seis abas principais e oito páginas do wizard, sem rede.
- GUI de Dev: leitura em segundo plano, teste Qt responsivo e exportação sanitizada verificados em Linux.
- Benchmark registrado somente para interface em código Linux; não há benchmark Windows/EXE.
- Não executados: Windows sem Python global, instalação inicial/reabertura/reparo/rollback pelo EXE em Windows, login corporativo, SSO/MFA, VPN real, bloqueio real por Excel, download corporativo interrompido e Agendador real. As tentativas com Wine não ultrapassaram problemas de inicialização dos handles de entrada/saída do runtime Windows. Não há evidência de execução Windows desta entrega.

Consulte MATRIZ_TESTE_DEV2.md para a matriz desta revisão e docs/MATRIZ_ACEITE_DESKTOP.md para os requisitos amplos da conversão anterior.

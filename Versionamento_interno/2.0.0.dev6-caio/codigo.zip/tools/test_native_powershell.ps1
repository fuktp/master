﻿param([string]$Root = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$files = @(Get-ChildItem -LiteralPath (Join-Path $Root 'native') -Filter '*.ps1')
$count = 0
foreach ($file in $files) {
    $tokens = $null; $parseErrors = $null
    [Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$parseErrors) | Out-Null
    if ($parseErrors.Count -gt 0) { throw ($file.Name + ': ' + ($parseErrors.Message -join '; ')) }
    $count++
}
. (Join-Path $Root 'native/Native.Common.ps1')
$catalog = Read-NativeJson (Join-Path $Root 'orquestrador_app/locales.json')
foreach ($property in $catalog.PSObject.Properties) {
    if ($property.Value.Count -ne 2 -or -not $property.Value[0] -or -not $property.Value[1]) {
        throw "Traduções incompletas: $($property.Name)"
    }
}
foreach ($key in @('Desabilitada', 'desabilitada')) {
    $entry = $catalog.PSObject.Properties[$key]
    if ($null -eq $entry -or $entry.Value[0] -cne 'Disabled' -or $entry.Value[1] -cne 'Deshabilitada') {
        throw "Catálogo incompatível com a consulta do wizard: $key"
    }
}
$count++
$temporary = Join-Path ([IO.Path]::GetTempPath()) ('orquestrador-powershell-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($temporary) | Out-Null
try {
    $file = Join-Path $temporary 'config.json'
    Write-NativeJson $file @{ value = 'João com espaços'; version = 1 }
    Write-NativeJson $file @{ value = 'configuração preservada'; version = 2 }
    $value = Read-NativeJson $file
    if ($value.version -ne 2 -or $value.value -ne 'configuração preservada') { throw 'Escrita JSON atômica falhou.' }
    $count++
    if ((Quote-NativeArgument 'C:\uma pasta\') -ne '"C:\uma pasta\\"') { throw 'Escape de caminho com espaços/barra final falhou.' }
    $count++
    $reuseRejected = $false
    try { Wait-OwnedParent ([Diagnostics.Process]::GetCurrentProcess().Id) 0 1 } catch { $reuseRejected = $true }
    if (-not $reuseRejected) { throw 'Reutilização de PID não foi rejeitada.' }
    $count++
    Wait-OwnedParent 2147483000 0 1
    $count++
    foreach ($script in $files) {
        $content = Get-Content -LiteralPath $script.FullName -Raw
        if ($content -match '(?im)^\s*(Set-ExecutionPolicy|Unblock-File|Add-MpPreference|Set-MpPreference)\b') { throw 'Alteração de política de segurança não autorizada.' }
    }
    $count++
    @{ checks = $count; result = 'passed'; environment = [Environment]::OSVersion.ToString(); powershell = $PSVersionTable.PSVersion.ToString(); winforms_executed = $false; scheduled_tasks_executed = $false } | ConvertTo-Json
} finally {
    Remove-Item -LiteralPath $temporary -Recurse -Force
}
